<?php
/**
 * diag_cachewebp3.php — финальная комплексная диагностика (OpenCart 3 / Простор / cachewebp).
 * Ключ в $_GET['key']. ПОСЛЕ ИСПОЛЬЗОВАНИЯ УДАЛИТЬ ФАЙЛ С СЕРВЕРА.
 */
$KEY = 'SECRET123';
if (!isset($_GET['key']) || $_GET['key'] !== $KEY) { http_response_code(404); exit; }
header('Content-Type: text/plain; charset=utf-8');
set_time_limit(300);
echo "=== DIAG3 " . date('Y-m-d H:i:s') . " ===\n";

// ---------- 1. Comprehensive 'webp' scan (case-insensitive) over ALL code dirs ----------
echo "== 1. FILES WITH 'webp' (php/twig/xml) ==\n";
$dirs = array('catalog', 'system', 'vqmod', 'admin', 'cli-php');
$hits = array();
foreach ($dirs as $d) {
    if (!is_dir($d)) { echo "  (dir missing: $d)\n"; continue; }
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile() && in_array(strtolower($f->getExtension()), array('php', 'twig', 'xml'))) {
            $c = @file_get_contents($f->getPathname());
            if ($c === false) continue;
            $n = preg_match_all('~webp~i', $c);
            if ($n) $hits[$f->getPathname()] = $n;
        }
    }
}
foreach (glob('*.php') as $f) {
    $c = @file_get_contents($f);
    $n = preg_match_all('~webp~i', $c);
    if ($n) $hits[$f] = $n;
}
arsort($hits);
foreach ($hits as $p => $n) echo "  $n  $p\n";
echo "\n";

// ---------- 2. Lines with 'cachewebp' OR cache+webp concat OR DIR_*WEBP constants ----------
echo "== 2. GENERATOR LINES (cachewebp / concat / const) ==\n";
foreach ($hits as $p => $n) {
    $lines = @file($p);
    if (!$lines) continue;
    $out = array();
    foreach ($lines as $i => $l) {
        if (stripos($l, 'cachewebp') !== false
            || preg_match("~['\"]cache['\"]?\s*\.\s*\\$?['\"]?w?webp~i", $l)
            || preg_match("~DIR_[A-Z_]*WEBP~i", $l)
            || preg_match("~\\\$\w*webp\w*\s*=~i", $l)) {
            $out[] = '  L' . ($i + 1) . ': ' . rtrim(substr($l, 0, 150));
        }
    }
    if ($out) {
        echo "--- $p\n" . implode("\n", array_slice($out, 0, 25)) . "\n";
    }
}
echo "\n";

// ---------- 3. config.php: constants ----------
echo "== 3. ROOT config.php CONSTANTS ==\n";
if (is_file('config.php')) {
    $lines = file('config.php');
    foreach ($lines as $i => $l) {
        if (stripos($l, 'define') !== false && (stripos($l, 'webp') !== false || stripos($l, 'image') !== false || stripos($l, 'cache') !== false)) {
            echo '  L' . ($i + 1) . ': ' . rtrim($l) . "\n";
        }
    }
}
echo "\n";

// ---------- 4. vqmod state ----------
echo "== 4. VQMOD ==\n";
echo '  vqmod/vqmod.php: ' . (is_file('vqmod/vqmod.php') ? 'exists' : 'absent') . "\n";
$xmls = glob('vqmod/xml/*.xml');
echo "  vqmod/xml (" . count($xmls) . "):\n";
foreach ($xmls as $x) echo '    ' . basename($x) . "\n";
$vc = glob('vqmod/vqcache/*.php');
echo '  vqmod/vqcache files: ' . count($vc) . "\n";
foreach (array_slice($vc, 0, 10) as $x) echo '    ' . basename($x) . "\n";
if (is_file('vqmod/vqmod.log')) {
    $l = @file('vqmod/vqmod.log');
    echo "  vqmod.log lines: " . count($l) . " (last 10):\n";
    echo '    ' . implode("\n    ", array_slice(array_map('rtrim', $l ? $l : array()), -10)) . "\n";
}
echo "\n";

// ---------- 5. DB: settings with webp / cachewebp ----------
echo "== 5. DB SETTINGS (webp) ==\n";
require('config.php');
$link = @mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($link) {
    mysqli_set_charset($link, 'utf8');
    $q = mysqli_query($link, 'SELECT `key`, LEFT(`value`, 150) v FROM `' . DB_PREFIX . 'setting` WHERE `key` LIKE "%webp%" OR `value` LIKE "%cachewebp%" OR `value` LIKE "%webp%"');
    if ($q) {
        $n = 0;
        while ($r = mysqli_fetch_assoc($q)) { echo '  ' . $r['key'] . ' = ' . $r['v'] . "\n"; $n++; }
        if (!$n) echo "  (none)\n";
    } else echo '  err ' . mysqli_error($link) . "\n";
    mysqli_close($link);
} else echo "  connect failed\n";
echo "\n";

// ---------- 6. Who throws 'unknown image format' ----------
echo "== 6. 'unknown image format' SOURCES ==\n";
foreach ($hits as $p => $n) {} // reuse list dirs
$all = array_merge(array_keys($hits), glob('*.php'));
foreach (array('catalog', 'system', 'admin', 'vqmod') as $d) {
    if (!is_dir($d)) continue;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile() && in_array(strtolower($f->getExtension()), array('php', 'twig'))) {
            $c = @file_get_contents($f->getPathname());
            if ($c && stripos($c, 'unknown image format') !== false) {
                echo '  ' . $f->getPathname() . "\n";
                $lines = file($f->getPathname());
                foreach ($lines as $i => $l) {
                    if (stripos($l, 'unknown image format') !== false) {
                        for ($j = max(0, $i - 6); $j <= min(count($lines) - 1, $i + 2); $j++) {
                            echo '    L' . ($j + 1) . ': ' . rtrim(substr($lines[$j], 0, 150)) . "\n";
                        }
                    }
                }
            }
        }
    }
}
echo "\n=== END ===\n";
