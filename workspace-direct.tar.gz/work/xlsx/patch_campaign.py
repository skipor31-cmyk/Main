# -*- coding: utf-8 -*-
"""
Точечная правка выгрузки кампании 40732207 (формат Директ Коммандера).

Правит ТОЛЬКО содержимое конкретных ячеек в xl/worksheets/sheet1.xml,
остальные части архива копируются байт-в-байт -> формулы, стили,
валидации выпадающих списков и листы «Регионы»/«Словарь» не страдают.

  python3 patch_campaign.py            # собрать оба файла
"""
import re, os, sys, json, zipfile, shutil, warnings, datetime
warnings.filterwarnings('ignore')
import openpyxl
from openpyxl.utils import get_column_letter as CL

WS   = os.environ.get('ARENA_WORKSPACE', '"$ARENA_WORKSPACE"')
SRC  = os.path.join(WS, 'uploads/40732207.xlsx')
OUT  = os.path.join(WS, 'work/xlsx')
UTM  = ('?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}'
        '&utm_content={ad_id}&utm_term={keyword}')
B    = 'https://flowerpoetry.ru'

# минус-слова кампании, убивающие СОБСТВЕННЫЕ ЖИВЫЕ фразы (проверено по 496 строкам файла
# и по keywords.get: 5 слов -> 10 фраз в статусе «Работает везде»).
# ВНИМАНИЕ: «цены» и «расчет» конфликтными НЕ являются (живых фраз не задевают) — их не трогаем.
BAD_NEGATIVES = ['онлайн', '101', 'срочно', 'подмосковье', 'сайт']
NEG_CELL = 'E9'

# НОВЫЕ минус-фразы кампании (майнинг 18.10 по 103 реальным запросам + 11 категориям сайта).
# Каждая проверена на конфликт со всеми 260 живыми ключами — конфликтов нет (verify_negatives.py).
ADD_NEGATIVES = ['flowwow', 'maxflora', 'ultraflowers', 'версаль', 'диния',
                 'букетная', 'линия розы', 'гладиолусы', 'гардины', 'шипами',
                 # 18.10: по ответам владельца — не продаём / не рекламируем
                 'сухоцветы', 'лилии', 'лилия', 'гладиолус']
# Групповые минус-фразы: маршрутизация бренд-трафика в Б1 (CPC 45 ₽ против 105–431 ₽).
# НА УРОВЕНЬ КАМПАНИИ ИХ НЕЛЬЗЯ — убьют ключи самой группы Б1.
BRAND_GROUP_NEG = '-поэзия -flowerpoetry'
BRAND_GROUP = '5806224429'   # Б1. Бренд
# ГЕО Б1. Бренд: РЕШЕНО НЕ МЕНЯТЬ (была правка на «Россия», откачена 17.10).
# Причина: весь трафик Б1 (216 показов / 15 кликов / 682 ₽ за 90 дней) даёт ключ ---autotargeting,
# а 5 бренд-ключей не дали НИ ОДНОГО показа. Расширение гео на «Россия» расширило бы по стране
# именно автотаргетинг, а не брендовые запросы. Для удалённых покупателей достаточно того, что
# с 31.08.2026 алгоритмы Яндекса показывают объявление пользователю из другого города, если в его
# запросе назван целевой город (официальный «Пример 3»), а ключ «цветочная поэзия раменское» есть.
BRAND_NEW_GEO = None

# М2 «По видам — остаток»: лилий на сайте нет (0 URL из 5 119) -> убираем из объявления
M2REST_GROUP = '5806224427'
M2REST_NEW = {'O': 'Букеты орхидей и альстромерий',              # 29/56
              'P': 'Экзотика. Доставка за 2 часа',                # 28/30
              'V': 'Редкие цветы в наличии и под заказ. Доставка за 2 часа. От 2500 руб.',  # 68/81
              'AV': 'Орхидеи-альстромерии'}                        # 20/20
LILY_PHRASE = 'букет лилий купить'   # единственный ключ про лилии -> на паузу

# ------------------------------------------------------------------ правила
# AU «Ссылка»: старый путь -> новый (проверено HTTP-обходом 17.10: 200 без редиректа)
HREF_FIX = {
    '/katalog/':                     '/buketi-cvetov/',
    '/informaciya-o-dostavke':       '/informaciya-o-dostavke/',
    '/katalog/buketi-v-korobkah/':   '/buketi-cvetov/kompozicii/buketi-v-korobkah/',
    '/po_cvetam/bukety-s-pionami/':  '/po_cvetam/bukety-s-gortenziej/',   # М2.4 -> гортензии
}
# BE «Адреса быстрых ссылок» (без query -> без завершающего слэша, иначе 301)
SL_OLD = '||'.join([B+'/katalog/', B+'/informaciya-o-dostavke', B+'/gallery/',
                    B+'/katalog/buketi-v-korobkah/'])
SL_NEW = '||'.join([B+'/buketi-cvetov', B+'/informaciya-o-dostavke', B+'/gallery',
                    B+'/buketi-cvetov/kompozicii/buketi-v-korobkah'])

PEONY_GROUP  = '5806400169'         # М2.4 — ищем строки по ID, а не по номеру (переносимо)
PEONY_PHRASE_IDS = {'58168684647', '58168684648', '205806400169'}  # пионы x2 + автотаргетинг
HYDR_PHRASE_ID   = '58168684649'                                    # гортензия — НЕ приостанавливать
HYDR_TITLE   = 'Букеты с гортензией в Раменском'                              # 31/56
HYDR_TITLE2  = 'Доставка 2 часа. От 2000 руб'                                 # 28/30 (min цена по JSON-LD = 2000 ₽)
HYDR_TEXT    = 'Объёмные букеты с гортензией: один цветок заменяет охапку. Доставка за 2 часа!'  # 78/81
HYDR_DISP    = 'Гортензии'

TITLE2_BY_PREFIX = [
    ('Д4', 'Доставим в любой посёлок'),   ('Д3', 'Доставим в любой посёлок'),
    ('Д1', 'Привезём за 2 часа. От 2000 ₽'), ('Д2', 'Привезём за 2 часа. От 2000 ₽'),
    ('Д5', 'Привезём за 2 часа. От 2000 ₽'),
    ('К1', 'Оплата картой. Открытка в дар'), ('К2', 'Оплата картой. Открытка в дар'),
    ('М1', '150+ букетов в наличии'),
    ('М2.4', HYDR_TITLE2),
    ('М2', 'Соберём под ваш бюджет'),      ('М3', 'Открытка в подарок'),
    ('М4', 'Композиции со сладостями'),    ('Б1', 'Свои флористы. Доставка 2 ч'),
]

# ------------------------------------------------------------------ XML-utils
def enc(s):
    """В формат листа: XML-escape + non-ASCII -> numeric character reference."""
    s = s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return ''.join(ch if ord(ch) < 128 else '&#%d;' % ord(ch) for ch in s)

CELL_RE = {}
def cell_re(ref):
    if ref not in CELL_RE:
        CELL_RE[ref] = re.compile(r'(<c r="%s"[^>]*?>)(.*?)(</c>)' % ref, re.S)
    return CELL_RE[ref]

def read_cell(xml, ref):
    m = cell_re(ref).search(xml)
    if not m: return None
    t = re.search(r'<t[^>]*>(.*?)</t>', m.group(2), re.S)
    if not t: return ''
    v = t.group(1)
    v = re.sub(r'&#(\d+);', lambda m: chr(int(m.group(1))), v)
    return v.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')

def write_cell(xml, ref, value):
    """Заменяет содержимое ячейки, сохраняя атрибут s= (стиль) и тип inlineStr."""
    m = cell_re(ref).search(xml)
    if not m:
        return xml, False
    new = '%s<is><t xml:space="preserve">%s</t></is>%s' % (m.group(1), enc(value), m.group(3))
    return xml[:m.start()] + new + xml[m.end():], True

# ------------------------------------------------------------------ чтение
wb = openpyxl.load_workbook(SRC)
ws = wb['Тексты']
H = {}; HI = {}
for i, c in enumerate(ws[10], 1):
    if c.value:
        H[str(c.value).strip()] = CL(i); HI[str(c.value).strip()] = i
COL = {k: H[k] for k in ['ID группы', 'Название группы', 'ID объявления', 'Фраза (с минус-словами)',
                         'Ссылка', 'Отображаемая ссылка', 'Статус фразы', 'Адреса быстрых ссылок', 'Регион']}
print('колонки:', COL)
COL['Заголовок 1 (комб.)'] = 'O'; COL['Заголовок 2 (комб.)'] = 'P'; COL['Текст 1 (комб.)'] = 'V'
rows = [r for r in range(12, ws.max_row + 1) if ws.cell(row=r, column=HI['ID группы']).value]
print('данных строк:', len(rows))

def cellstr(r, name):
    v = ws[f'{COL[name]}{r}'].value if False else ws[f'{COL[name] if isinstance(COL[name],str) else CL(COL[name])}{r}'].value
    return '' if v is None else str(v).strip()

PEONY_ROWS, HYDR_ROWS = [], []
for r in rows:
    if cellstr(r, 'ID группы') == PEONY_GROUP:
        HYDR_ROWS.append(r)
        ph = ws[f'F{r}'].value
        if ph is not None and str(ph).strip() in PEONY_PHRASE_IDS:
            PEONY_ROWS.append(r)
print(f'группа М2.4: строк {len(HYDR_ROWS)} -> из них приостанавливаем {len(PEONY_ROWS)} (пионы+автотаргетинг)')
assert len(HYDR_ROWS) == 4 and len(PEONY_ROWS) == 3, 'раскладка М2.4 отличается от ожидаемой — проверьте файл'

def gv(r, name):
    col = COL[name]
    return ws[f'{col}{r}'].value if isinstance(col, str) and not col.isdigit() else ws.cell(row=r, column=int(col)).value

# ------------------------------------------------------------------ план правок
changes = []            # (ref, поле, было, стало)
def plan(ref, field, old, new):
    if old != new: changes.append({'ref': ref, 'field': field, 'old': old, 'new': new})

for r in rows:
    gname = str(gv(r, 'Название группы') or '')
    # 1. AU Ссылка
    href = gv(r, 'Ссылка') or ''
    if href.startswith(B):
        path = href[len(B):].split('?')[0]
        if path in HREF_FIX:
            plan(f'{COL["Ссылка"]}{r}', 'Ссылка', href, B + HREF_FIX[path] + UTM)
    # 2. BE Адреса быстрых ссылок
    sl = gv(r, 'Адреса быстрых ссылок') or ''
    if sl == SL_OLD:
        plan(f'{COL["Адреса быстрых ссылок"]}{r}', 'Адреса быстрых ссылок', sl, SL_NEW)
    # 3. BB Статус фразы (пионы)
    if r in PEONY_ROWS:
        plan(f'{COL["Статус фразы"]}{r}', 'Статус фразы', gv(r, 'Статус фразы'), 'Приостановлена')
    # 4a. М2 «По видам — остаток»: убрать лилии из объявления (50 строк одного объявления)
    if cellstr(r, 'ID группы') == M2REST_GROUP:
        FN = {'O': 'Заголовок 1 (комб.)', 'P': 'Заголовок 2 (комб.)',
              'V': 'Текст 1 (комб.)', 'AV': 'Отображаемая ссылка'}
        for col, new in M2REST_NEW.items():
            plan(f'{col}{r}', FN[col], ws[f'{col}{r}'].value, new)
    # 4b. ключ про лилии -> на паузу
    if str(ws[f'G{r}'].value or '').strip() == LILY_PHRASE:
        plan(f'{COL["Статус фразы"]}{r}', 'Статус фразы', gv(r, 'Статус фразы'), 'Приостановлена')
    # 4c. гео Б1. Бренд — намеренно НЕ трогаем (см. комментарий у BRAND_NEW_GEO)

    # 4. М2.4 -> гортензии (заголовок/текст/отображаемая ссылка)
    if r in HYDR_ROWS:
        plan(f'O{r}', 'Заголовок 1 (комб.)', gv(r, 'Заголовок 1 (комб.)'), HYDR_TITLE)
        plan(f'V{r}', 'Текст 1 (комб.)',    gv(r, 'Текст 1 (комб.)'),    HYDR_TEXT)
        plan(f'{COL["Отображаемая ссылка"]}{r}', 'Отображаемая ссылка',
             gv(r, 'Отображаемая ссылка'), HYDR_DISP)
        plan(f'P{r}', 'Заголовок 2 (комб.)', gv(r, 'Заголовок 2 (комб.)'), HYDR_TITLE2)

# 6. минус-фразы кампании (ячейка E9, одна строка на всю кампанию)
neg_old = ws[NEG_CELL].value or ''
neg_new = neg_old
for w in BAD_NEGATIVES:
    neg_new = re.sub(r'(?<!\S)-%s(?!\S)\s*' % re.escape(w), '', neg_new)
neg_new = re.sub(r'\s{2,}', ' ', neg_new).strip()
removed = sorted(set(neg_old.split()) - set(neg_new.split()))
print(f'\nE9 минус-фразы: токенов {len(neg_old.split())} -> {len(neg_new.split())}, '
      f'удалено {len(removed)}: {removed}')
assert len(neg_old.split()) - len(neg_new.split()) == len(BAD_NEGATIVES), \
    f'ожидали удалить {len(BAD_NEGATIVES)} токенов, вышло {len(neg_old.split())-len(neg_new.split())}'
# добавить новые (дубли исключены)
have = {t.lstrip('-') for t in neg_new.split()}
added = []
for w in ADD_NEGATIVES:
    tok = '-' + w
    if w in have or tok in neg_new.split():
        print(f'  = минус-фраза {tok!r} уже есть — пропускаю'); continue
    neg_new = (neg_new + ' ' + tok).strip(); added.append(tok)
print(f'   добавлено {len(added)}: {added}')
plan(NEG_CELL, 'Минус-фразы на кампанию',
     f'{len(neg_old.split())} токенов',
     f'{len(neg_new.split())} токенов (−{len(removed)} конфликтных: {", ".join(x.lstrip("-") for x in removed)}; '
     f'+{len(added)} новых: {", ".join(x.lstrip("-") for x in added)})')

# 7. групповые минус-фразы на бренд (колонка BM) во всех небрендовых живых группах
BM = 'BM'
bm_n = 0
for r in rows:
    gid = cellstr(r, 'ID группы')
    if not gid or gid == BRAND_GROUP:
        continue
    cur = (ws[f'{BM}{r}'].value or '').strip()
    parts = cur.split() if cur else []
    need = [x for x in BRAND_GROUP_NEG.split() if x not in parts]
    if not need:
        continue
    new = (' '.join(parts + need)).strip()
    plan(f'{BM}{r}', 'Минус-фразы на группу', cur or '(пусто)', new)
    bm_n += 1
print(f'\nBM групповые минус-фразы «{BRAND_GROUP_NEG}»: строк {bm_n}')

BASE_CHANGES = list(changes)

# 5. (опционально) Заголовок 2 для всех объявлений
t2_changes = []
for r in rows:
    if r in HYDR_ROWS or cellstr(r, 'ID группы') == M2REST_GROUP:
        continue   # у этих групп Заголовок 2 уже задан явно в M2REST_NEW / HYDR_TITLE2
    gname = str(gv(r, 'Название группы') or '')
    t2 = next((v for p, v in TITLE2_BY_PREFIX if gname.startswith(p)), None)
    if not t2:
        print(f'  ?? нет правила Заголовка 2 для группы {gname!r} (строка {r})'); continue
    cur = gv(r, 'Заголовок 2 (комб.)')
    if cur in (None, ''):
        t2_changes.append({'ref': f'P{r}', 'field': 'Заголовок 2 (комб.)',
                           'old': '', 'new': t2, 'group': gname})

# ------------------------------------------------------------------ сборка
def build(dst, chg):
    with zipfile.ZipFile(SRC) as z:
        names = z.namelist()
        data = {n: z.read(n) for n in names}
    xml = data['xl/worksheets/sheet1.xml'].decode('utf-8')
    refs = [c['ref'] for c in chg]
    dup = {x for x in refs if refs.count(x) > 1}
    assert not dup, f'двойная запись в ячейки: {sorted(dup)[:10]} — план противоречив'
    ok = fail = 0
    for c in chg:
        val = c['new']
        if c['ref'] == NEG_CELL:
            val = neg_new
        xml, done = write_cell(xml, c['ref'], val)
        ok += done; fail += (not done)
    data['xl/worksheets/sheet1.xml'] = xml.encode('utf-8')
    with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
        for n in names:
            z.writestr(n, data[n])
    print(f'  -> {os.path.basename(dst)}: ячеек изменено {ok}'
          + (f', НЕ найдено {fail}' if fail else '') + f', размер {os.path.getsize(dst)/1024:.0f} КБ')
    return ok, fail

print('\n=== СБОРКА ===')
f1 = os.path.join(OUT, '40732207_итоговый.xlsx')
build(f1, BASE_CHANGES + t2_changes)          # основной: всё вместе
f2 = os.path.join(OUT, '40732207_без_Заголовка2.xlsx')
build(f2, BASE_CHANGES)                       # запасной: без массовой перемодерации

# ------------------------------------------------------------------ лог
by_field = {}
for c in BASE_CHANGES: by_field.setdefault(c['field'], []).append(c)
print('\n=== ИЗМЕНЕНИЯ (файл 1) ===')
for fld, lst in by_field.items():
    print(f'\n  {fld}: {len(lst)} ячеек')
    seen = set()
    for c in lst:
        key = (c['old'], c['new'])
        if key in seen: continue
        seen.add(key)
        o = c['old'].split('?')[0].replace(B, '') if c['old'].startswith('http') else c['old']
        n = c['new'].split('?')[0].replace(B, '') if c['new'].startswith('http') else c['new']
        print(f'     {str(o)[:70]:72} -> {str(n)[:70]}')
json.dump({'file1': BASE_CHANGES, 'file2_extra': t2_changes,
           'ts': datetime.datetime.now().isoformat()},
          open(os.path.join(OUT, 'change_log.json'), 'w'), ensure_ascii=False, indent=1)
print(f'\n  Заголовок 2 (файл 2, дополнительно): {len(t2_changes)} ячеек')
