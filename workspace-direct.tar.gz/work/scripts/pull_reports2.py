# -*- coding: utf-8 -*-
"""Отчёты Директа с ретраями на лимит 1 запрос/10 сек."""
import json, os, sys, csv, io, datetime, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, CFG
c=client()
GOALS=[str(CFG['metrica']['primary_goal_id'])]+[str(g) for g in CFG['metrica']['secondary_goal_ids']]

def report(rtype, fields, dfrom, dto, goals=None, tries=8):
    sel={'DateFrom':dfrom,'DateTo':dto,'Filter':[]}
    rd={'SelectionCriteria':sel,'FieldNames':fields,'ReportName':f"{rtype}_{dfrom}_{dto}",
        'ReportType':rtype,'DateRangeType':'CUSTOM_DATE','Format':'TSV','IncludeVAT':'YES'}
    if goals: rd['Goals']=goals; rd['AttributionModels']=['LSC']
    for t in range(tries):
        try:
            tsv=c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
            return list(csv.DictReader(io.StringIO(tsv), delimiter='\t')), None
        except Exception as e:
            m=str(e)
            if '"56"' in m or 'лимит запросов' in m:
                time.sleep(15); continue
            return None, m
    return None, 'rate-limit exhausted'

TODAY=datetime.date(2026,10,17)
D=lambda n:(TODAY-datetime.timedelta(days=n)).isoformat()
jobs=[
 ('r_campaign_goals_90d.tsv','CAMPAIGN_PERFORMANCE_REPORT',
   ['CampaignId','CampaignName','Impressions','Clicks','Ctr','Cost','AvgCpc','Conversions','CostPerConversion'], D(90), D(0), GOALS),
 ('r_adgroup_90d.tsv','ADGROUP_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','AdGroupName','Impressions','Clicks','Ctr','Cost','Conversions','CostPerConversion'], D(90), D(0), GOALS),
 ('r_keyword_90d.tsv','CRITERIA_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','CriteriaId','Criteria','Impressions','Clicks','Ctr','Cost','AvgCpc','Conversions','CostPerConversion'], D(90), D(0), GOALS),
 ('r_ad_90d.tsv','AD_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','AdId','Impressions','Clicks','Ctr','Cost','Conversions','CostPerConversion'], D(90), D(0), GOALS),
 ('r_keyword_30d.tsv','CRITERIA_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','CriteriaId','Criteria','Impressions','Clicks','Cost','Conversions','CostPerConversion'], D(30), D(0), GOALS),
 ('r_query_60d.tsv','SEARCH_QUERY_PERFORMANCE_REPORT',
   ['SearchPhrase','Impressions','Clicks','Cost','Conversions'], D(60), D(0), GOALS),
]
for name, rt, fields, df, dt, goals in jobs:
    p=os.path.join(OUT,name)
    if os.path.exists(p) and os.path.getsize(p)>60:
        print(f"  = {name} уже есть"); continue
    time.sleep(12)
    rows, err = report(rt, fields, df, dt, goals)
    if err:
        print(f"  ❌ {name:28} {err[:400]}")
    else:
        cols=list(fields)
        if rows:
            for k in rows[0].keys():
                if k not in cols: cols.append(k)
        with open(p,'w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f, fieldnames=cols, delimiter='\t', extrasaction='ignore')
            w.writeheader(); w.writerows(rows or [])
        print(f"  ✅ {name:28} строк: {len(rows or []):6d} ({os.path.getsize(p)/1024:.0f} KB)")
print("DONE")
