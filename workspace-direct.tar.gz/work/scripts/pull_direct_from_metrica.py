# -*- coding: utf-8 -*-
"""Метрика как независимый источник по кампаниям Директа (параметр direct_client_logins)."""
import json, os, sys, urllib.parse, urllib.request, urllib.error, time, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG, OUT
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; BASE='https://api-metrika.yandex.net'
G=[('36895733','Заказ (Спасибо)'),('168348169','Купить в 1 клик'),('136163740','Звонок'),
   ('197752867','Автоцель: форма'),('339702220','Автоцель: контакты'),('168348397','Мессенджер'),
   ('318185345','Автоцель: заполнил контакты'),('512002319','Начало оформления'),
   ('36895973','Переход в корзину'),('568074580','Автосбор: покупка')]
def q(p, tries=3):
    p=dict(p); p.setdefault('direct_client_logins','skipor31'); p.setdefault('accuracy','full')
    url=BASE+'/stat/v1/data?'+urllib.parse.urlencode(p, doseq=True)
    for t in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=150) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            b=e.read().decode()
            if e.code in (429,502,503): time.sleep(8); continue
            return {'_error':b[:250]}
        except Exception: time.sleep(5)
    return {'_error':'retries'}
def save(n,d):
    p=os.path.join(OUT,n); json.dump(d,open(p,'w'),ensure_ascii=False,indent=1)
    print(f"   saved {n} ({os.path.getsize(p)/1024:.0f} КБ)")

BASE_M=['ym:ad:visits','ym:ad:clicks','ym:ad:RUBConvertedAdCost','ym:ad:bounceRate',
        'ym:ad:avgVisitDurationSeconds','ym:ad:ecommercePurchases','ym:ad:ecommerceRUBConvertedRevenue']
GOAL_M=[f'ym:ad:goal{g}reaches' for g,_ in G]

print("=== A. ПО КАМПАНИЯМ, 90 дней, 3 модели атрибуции ===")
ATTR={'default':'ym:ad:DirectOrderName','last':'ym:ad:lastDirectOrderName',
      'cross_device':'ym:ad:cross_device_last_significantDirectOrderName'}
out={}
for aname,dim in ATTR.items():
    d=q({'ids':CID,'metrics':','.join(BASE_M+GOAL_M),'dimensions':dim,
         'date1':'90daysAgo','date2':'today','limit':100,'sort':'-ym:ad:RUBConvertedAdCost'})
    if '_error' in d: print(f"  ❌ {aname}: {d['_error'][:120]}"); continue
    out[aname]=d
    print(f"\n  --- атрибуция: {aname} ({dim}) ---")
    rows=d.get('data') or []
    hdr=f"  {'кампания':44}{'визит':>6}{'клик':>6}{'расход₽':>10}{'отк%':>6}{'врем':>6}{'заказ':>6}{'1клик':>6}{'форм':>6}{'месс':>6}{'всеЦ':>6}"
    if aname=='default': print(hdr)
    for r in rows:
        nm=r['dimensions'][0]['name'][:42]; m=r['metrics']
        goals=[m[7+i] for i in range(len(G))]
        allg=sum(goals)
        print(f"  {nm:44}{m[0]:6.0f}{m[1]:6.0f}{m[2]:10.0f}{m[3]:6.1f}{m[4]:6.0f}"
              f"{goals[0]:6.0f}{goals[1]:6.0f}{goals[3]:6.0f}{goals[5]:6.0f}{allg:6.0f}")
    print(f"  {'ИТОГО':44}{sum(r['metrics'][0] for r in rows):6.0f}{sum(r['metrics'][1] for r in rows):6.0f}"
          f"{sum(r['metrics'][2] for r in rows):10.0f}{'':6}{'':6}"
          f"{sum(r['metrics'][7] for r in rows):6.0f}{sum(r['metrics'][8] for r in rows):6.0f}"
          f"{sum(r['metrics'][10] for r in rows):6.0f}{sum(r['metrics'][12] for r in rows):6.0f}"
          f"{sum(sum(r['metrics'][7+i] for i in range(len(G))) for r in rows):6.0f}")
save('m_direct_by_campaign_3attr.json', out)

print("\n=== B. ПО ДНЯМ (default атрибуция), 60 дней ===")
d=q({'ids':CID,'metrics':','.join(['ym:ad:visits','ym:ad:clicks','ym:ad:RUBConvertedAdCost']+GOAL_M[:2]),
     'dimensions':'ym:ad:date','date1':'60daysAgo','date2':'today','limit':200,'sort':'ym:ad:date'})
save('m_direct_by_day.json', d)
rows=d.get('data') or []
print(f"   дней: {len(rows)}")
print("   дата        визит клик  расход₽  заказ 1клик")
for r in rows[-26:]:
    m=r['metrics']
    print(f"   {r['dimensions'][0]['name']} {m[0]:5.0f} {m[1]:5.0f} {m[2]:8.0f} {m[3]:5.0f} {m[4]:5.0f}")

print("\n=== C. ПО ПЛОЩАДКАМ (DirectPlatform), 90 дней ===")
d=q({'ids':CID,'metrics':'ym:ad:visits,ym:ad:clicks,ym:ad:RUBConvertedAdCost,ym:ad:bounceRate',
     'dimensions':'ym:ad:DirectPlatform','date1':'90daysAgo','date2':'today','limit':40,'sort':'-ym:ad:clicks'})
save('m_direct_by_platform.json', d)
for r in (d.get('data') or [])[:18]:
    m=r['metrics']
    print(f"   {r['dimensions'][0]['name'][:34]:36} визит={m[0]:6.0f} клик={m[1]:6.0f} расход={m[2]:9.0f}₽ отказ={m[3]:5.1f}%")

print("\n=== D. ВСЕ ЦЕЛИ по рекламе, 90 дней (default) ===")
d=q({'ids':CID,'metrics':','.join(GOAL_M),'date1':'90daysAgo','date2':'today'})
save('m_direct_goals_total.json', d)
vals=(d.get('data') or [{}])[0].get('metrics', [0]*len(G))
for (gid,name),v in zip(G, vals): print(f"   {gid:>11} {name:28} {v:6.0f}")
print(f"\n   ВСЕГО «сильных» целей по рекламе: {sum(vals):.0f}")
