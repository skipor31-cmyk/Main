import json, sys, time
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client
c = client()
r = c.call('adgroups', 'get', {
    'SelectionCriteria': {'Ids': [4166852642, 4166852847, 5806224424]},
    'FieldNames': ['Id','Name','Status','RegionIds','NegativeKeywords'],
})
print(json.dumps(r, ensure_ascii=False)[:2500])
time.sleep(2)
r2 = c.call('ads', 'get', {
    'SelectionCriteria': {'AdGroupIds': [4166852642, 4166852847, 4166852849, 3688099772, 4166852644, 4166852655, 4166852705, 4166852729, 4166852706, 4166852753, 4166852738]},
    'FieldNames': ['Id','AdGroupId','Status','State','Type','StatusClarification'],
})
print(json.dumps(r2, ensure_ascii=False)[:4000])
