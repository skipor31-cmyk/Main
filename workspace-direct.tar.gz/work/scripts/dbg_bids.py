import json, sys
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client
c = client()
for fields in (['KeywordId','Bid','ContextBid','AuctionBids'], ['KeywordId','Bid','ContextBid']):
    try:
        r = c.call('keywordbids', 'get', {
            'SelectionCriteria': {'KeywordIds': [20363191489, 20363191694, 20363191696, 20363191491, 58167571692],
                                  'CampaignIds': ['40732207']},
            'FieldNames': fields,
        })
        print(json.dumps(r, ensure_ascii=False, indent=1)[:2200]); break
    except Exception as e:
        print('ERR with', fields[-1], ':', str(e)[:200])
