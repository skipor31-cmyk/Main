#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Свежие данные за сегодня 21.10: группы + запросы + статусы объявлений."""
import json, sys, os, csv, io, time
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client, OUT
from direct_api import DirectError

c = client()

def rep(rtype, fields, dfrom, dto, tag, filt=None):
    fn = os.path.join(OUT, f'deep_{tag}.tsv')
    sel = {'DateFrom': dfrom, 'DateTo': dto, 'Filter': filt or []}
    rd = {'SelectionCriteria': sel, 'FieldNames': fields,
          'ReportName': f'deep_{tag}', 'ReportType': rtype,
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    for attempt in range(10):
        try:
            tsv = c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
            open(fn,'w').write(tsv); print(tag, 'rows:', len(tsv.splitlines())); return
        except DirectError as e:
            if '56' in str(getattr(e,'code','')) or 'Превышен лимит' in str(e):
                print(tag, 'rate-limit wait'); time.sleep(15); continue
            raise

FILT = [{'Field':'CampaignId','Operator':'EQUALS','Values':['40732207']}]
rep('ADGROUP_PERFORMANCE_REPORT', ['AdGroupName','Impressions','Clicks','Cost'],
    '2026-10-21','2026-10-21','today_ag', FILT)
time.sleep(11)
rep('SEARCH_QUERY_PERFORMANCE_REPORT', ['Query','AdGroupName','Impressions','Clicks','Cost'],
    '2026-10-21','2026-10-21','today_query', FILT)
