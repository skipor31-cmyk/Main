# -*- coding: utf-8 -*-
"""
Сводное применение изменений 21.10.2026 — спецрежим Яндекса СНЯТ, API принимает запись.
Объединяет правки из плана 17.10 (XLSX 40732207_итоговый.xlsx) в один проход через API.

ШАГИ (идемпотентно: повторный запуск пропускает выполненные шаги):
  N1  Минус-слова кампании: −5 конфликтов (101/онлайн/подмосковье/сайт/срочно), +10 новых
  N2  Групповые минус-слова «поэзия flowerpoetry»: 30 групп + слияние в Д5 (Жуковский)
  S1  Новый набор быстрых ссылок (прямые 200 без редиректа)
  H1  Новое объявление «Гортензии» в М2.4 + модерация
  P1  Пауза: ключ «букет лилий купить» (58168248818) + автотаргетинг М2.4 (205806400169)
  P2  Пауза объявления пионов М2.4 (1922758453206718169)
  P3  Переименование М2.4 -> «М2.4 Гортензии (пионы — СТОП до сезона)»
  A1  UPDATE 47 объявлений: Href->прямой 200, Заголовок 2, новый набор быстрых ссылок,
      правка копии М2-остаток (без лилий). Все расширения сохраняются.
  A2  Модерация всех обновлённых объявлений

    python3 apply_21-10.py            # DRY-RUN
    python3 apply_21-10.py --apply    # применить
    python3 apply_21-10.py --rollback # откатить (обратный порядок)
"""
import json, os, sys, time, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError

WS    = os.environ.get('ARENA_WORKSPACE', '/home/user')
A     = os.path.join(WS, 'work/analysis')
STATE = os.path.join(A, 'apply_state_21-10.json')

B       = 'https://flowerpoetry.ru'
UTM     = ('?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}'
           '&utm_content={ad_id}&utm_term={keyword}')
CAMPAIGN      = 40732207
OLD_SITELINKS = 1384724168
PEONY_GROUP   = 5806400169
PEONY_AD      = 1922758453206718169
LILY_AD       = 1922742232187391648          # М2. По видам — остаток
SUSPEND_KEYS  = [58168248818]   # «букет лилий купить». Автотаргетинг (205806400169) через API
                                # не останавливается — ошибка 8305, ограничение Яндекса.
                                # Вместо паузы: групповые минусы про пионы в М2.4 (шаг P1b).
D5_GROUP      = 5806224424                   # Д5. Жуковский — слияние с «раменское»
PEONY_NEWNAME = 'М2.4 Гортензии (пионы — СТОП до сезона)'
PEONY_NEG_M24 = ['пион', 'пионы', 'пионов', 'пиона', 'пионами', 'пионах']

# --- быстрые ссылки: все 4 отдают 200 БЕЗ query (проверено 21.10) ---
NEW_SITELINKS = [
    {'Title': 'Каталог букетов',       'Href': B + '/buketi-cvetov',
     'Description': 'Красивые букеты на любой случай, от 2000 руб.'},
    {'Title': 'Доставка цветов',       'Href': B + '/informaciya-o-dostavke',
     'Description': 'Быстрая доставка за 2 часа по Раменскому и району.'},
    {'Title': 'Галерея работ',         'Href': B + '/gallery',
     'Description': 'Авторские букеты и композиции наших флористов.'},
    {'Title': 'Композиции в коробках', 'Href': B + '/buketi-cvetov/kompozicii/buketi-v-korobkah',
     'Description': 'Элегантные композиции в стильных коробках.'},
]

# --- Href объявлений: замены (с UTM целевые отдают 200 напрямую, проверено 21.10) ---
HREF_FIX = {
    '/katalog/':                       '/buketi-cvetov/',
    '/katalog/buketi-v-korobkah/':     '/buketi-cvetov/kompozicii/buketi-v-korobkah/',
    '/informaciya-o-dostavke':         '/informaciya-o-dostavke/',
}

# --- правка копии объявления М2-остаток (лилии не продаются) ---
LILY_COPY = {
    'Title': 'Букеты орхидей и альстромерий',
    'Text':  'Редкие цветы в наличии и под заказ. Доставка за 2 часа. От 2500 руб.',
    'DisplayUrlPath': 'Орхидеи-альстромерии',
}

# --- новое объявление М2.4 (гортензии) ---
HYDRANGEA_AD = {
    'Title':  'Букеты с гортензией в Раменском',
    'Title2': 'Доставка 2 часа. От 2660 руб',
    'Text':   'Объёмные букеты с гортензией: один цветок заменяет охапку. Доставка за 2 часа!',
    'DisplayUrlPath': 'Гортензии',
    'HrefPath': '/po_cvetam/bukety-s-gortenziej/',
}

# --- Заголовок 2 по префиксу группы (проверено: все ≤30 символов) ---
TITLE2_BY_PREFIX = [
    ('Д4',  'Доставим в любой посёлок'),
    ('Д1',  'Привезём за 2 часа. От 2000 ₽'),
    ('Д2',  'Привезём за 2 часа. От 2000 ₽'),
    ('Д3',  'Доставим в любой посёлок'),
    ('Д5',  'Привезём за 2 часа. От 2000 ₽'),
    ('К1',  'Оплата картой. Открытка в дар'),
    ('К2',  'Оплата картой. Открытка в дар'),
    ('М1',  '150+ букетов в наличии'),
    ('М2',  'Соберём под ваш бюджет'),
    ('М3',  'Открытка в подарок'),
    ('М4',  'Композиции со сладостями'),
    ('Б1',  'Свои флористы. Доставка 2 ч'),
]

NEG30 = [3688099772, 4166852642, 4166852644, 4166852655, 4166852705, 4166852706,
         4166852729, 4166852738, 4166852753, 4166852847, 4166852849, 5806224423,
         5806224425, 5806224426, 5806224427, 5806224428, 5806373449, 5806400166,
         5806400167, 5806400168, 5806400169, 5806400170, 5806400171, 5806400172,
         5806400173, 5806400174, 5806400175, 5806400176, 5806400177, 5806400178]


def st_load():
    if os.path.exists(STATE):
        return json.load(open(STATE, encoding='utf-8'))
    return {'created': datetime.datetime.now().isoformat(), 'applied': []}

def st_save(s):
    json.dump(s, open(STATE, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

def log_entry(state, sid, desc, rollback=None, **extra):
    e = {'id': sid, 'desc': desc, 'rollback': rollback,
         'ts': datetime.datetime.now().isoformat()}
    e.update(extra)
    state['applied'].append(e); st_save(state)
    return e


def chunks(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i + n]


def title2_for(gname):
    for pfx, t2 in TITLE2_BY_PREFIX:
        if gname.startswith(pfx):
            return t2
    return None


def main():
    mode = 'apply' if '--apply' in sys.argv else 'rollback' if '--rollback' in sys.argv else 'dry'
    c = client()
    state = st_load()
    done = {e['id'] for e in state.get('applied', [])}

    if mode == 'rollback':
        print('ОТКАТ (обратный порядок)...')
        c501 = client(); c501.base = 'https://api.direct.yandex.com/json/v501/'
        for e in reversed(state.get('applied', [])):
            rb = e.get('rollback')
            if not rb:
                print(f"  [{e['id']}] авто-откат не предусмотрен"); continue
            try:
                if rb.get('svc501'):
                    c501.call(rb['svc501'], rb['method'], rb['params'])
                elif rb['svc'] == 'ads_delete':
                    c.call('ads', 'delete', {'SelectionCriteria': {'Ids': rb['ids']}})
                elif rb['svc'] == 'sitelinks_delete':
                    c.call('sitelinks', 'delete', {'SelectionCriteria': {'Ids': rb['ids']}})
                else:
                    c.call(rb['svc'], rb['method'], rb['params'])
                print(f"  [{e['id']}] откачено")
            except DirectError as ex:
                print(f"  [{e['id']}] ОШИБКА: {str(ex)[:200]}")
            time.sleep(0.7)
        state['rolled_back'] = datetime.datetime.now().isoformat(); st_save(state)
        return

    # ============================ ДАННЫЕ ============================
    ads = json.load(open(os.path.join(A, 'live_ads_21-10.json'), encoding='utf-8'))
    groups = {g['Id']: g['Name'] for g in json.load(open(os.path.join(A, 'live_adgroups_21-10.json'), encoding='utf-8'))}
    neg = json.load(open(os.path.join(A, 'negatives_state_21-10.json'), encoding='utf-8'))

    print('=' * 78)
    print(f'ПЛАН ПРИМЕНЕНИЯ 21.10 — режим {mode.upper()}  (выполнено ранее: {sorted(done) or "—"})')
    print('=' * 78)
    print(f"N1  минус-слова кампании: −{len(neg['removed'])} {neg['removed']} / +{len(neg['add'])} → {len(neg['kept'])+len(neg['add'])}")
    print(f"N2  групповые минус-слова: {len(NEG30)} групп + Д5 (слияние с «раменское»)")
    print(f"S1  новый набор быстрых ссылок (4 шт., все 200 без редиректа)")
    print(f"H1  объявление «Гортензии» в М2.4")
    print(f"P1  пауза ключа {SUSPEND_KEYS} (лилия) + P1b пион-минусы в М2.4 (автотаргетинг API не отключает — 8305)")
    print(f"P2  пауза объявления пионов {PEONY_AD}")
    print(f"P3  переименование М2.4")
    n_href = sum(1 for a in ads if a['Id'] != PEONY_AD and
                 ((a.get('TextAd') or {}).get('Href') or '').split('?')[0].replace(B, '') in HREF_FIX)
    print(f"A1  update {len(ads)-1} объявлений: Href у {n_href}, Заголовок 2 у всех, новые быстрые ссылки у всех")
    print(f"A2  модерация")

    if mode == 'dry':
        print('\n--- DRY-RUN: ничего не изменено. Запуск: python3 apply_21-10.py --apply ---')
        return

    print('\nПРИМЕНЕНИЕ...')

    # ---- N1: минус-слова кампании ----
    if 'N1' not in done:
        new_items = neg['kept'] + neg['add']
        res = c.call('campaigns', 'update', {'Campaigns': [
            {'Id': CAMPAIGN, 'NegativeKeywords': {'Items': new_items}}]})
        errs = [x.get('Errors') for x in (res.get('UpdateResults') or []) if x.get('Errors')]
        assert not errs, errs
        log_entry(state, 'N1', f'Минус-слова кампании: {len(neg["original"])}→{len(new_items)}',
                  rollback={'svc': 'campaigns', 'method': 'update',
                            'params': {'Campaigns': [{'Id': CAMPAIGN,
                                          'NegativeKeywords': {'Items': neg['original']}}]}})
        print('[N1] ✅ минус-слова кампании обновлены:', len(neg['original']), '→', len(new_items))
        time.sleep(0.8)

    # ---- N2: групповые минус-слова ----
    if 'N2' not in done:
        payload = [{'Id': gid, 'NegativeKeywords': {'Items': ['поэзия', 'flowerpoetry']}}
                   for gid in NEG30]
        payload.append({'Id': D5_GROUP,
                        'NegativeKeywords': {'Items': ['раменское', 'поэзия', 'flowerpoetry']}})
        errs_all = []
        for batch in chunks(payload, 10):
            res = c.call('adgroups', 'update', {'AdGroups': batch})
            for x in (res.get('UpdateResults') or []):
                if x.get('Errors'): errs_all.append((x.get('Id'), x['Errors']))
            time.sleep(0.8)
        assert not errs_all, errs_all
        log_entry(state, 'N2', f'Групповые минус-слова у {len(payload)} групп',
                  rollback={'svc': 'adgroups', 'method': 'update',
                            'params': {'AdGroups':
                                [{'Id': gid, 'NegativeKeywords': {'Items': []}} for gid in NEG30] +
                                [{'Id': D5_GROUP, 'NegativeKeywords': {'Items': ['раменское']}}]}})
        print(f'[N2] ✅ групповые минус-слова «поэзия flowerpoetry»: {len(payload)} групп')

    # ---- S1: новый набор быстрых ссылок ----
    new_sl = state.get('new_sitelink_set')
    if 'S1' not in done:
        res = c.call('sitelinks', 'add', {'SitelinksSets': [{'Sitelinks': NEW_SITELINKS}]})
        ids = [x.get('Id') for x in (res.get('AddResults') or [])]
        assert ids and ids[0], res
        new_sl = ids[0]
        e = log_entry(state, 'S1', f'Новый набор быстрых ссылок {new_sl}',
                  rollback={'svc': 'sitelinks_delete', 'ids': [new_sl]})
        state['new_sitelink_set'] = new_sl; st_save(state)
        print(f'[S1] ✅ создан набор быстрых ссылок: {new_sl}')
        time.sleep(0.8)
    else:
        new_sl = state.get('new_sitelink_set') or OLD_SITELINKS

    # ---- H1: объявление гортензий ----
    if 'H1' not in done:
        ref_ad = next(a for a in ads if a['Id'] != PEONY_AD)  # донор BusinessId/TrackingPhoneId
        rta = ref_ad['TextAd']
        payload = {'AdGroupId': PEONY_GROUP, 'TextAd': {
            'Title': HYDRANGEA_AD['Title'], 'Title2': HYDRANGEA_AD['Title2'],
            'Text': HYDRANGEA_AD['Text'],
            'Href': B + HYDRANGEA_AD['HrefPath'] + UTM, 'Mobile': 'NO',
            'SitelinkSetId': new_sl,
            'AdExtensionIds': [x['AdExtensionId'] for x in (rta.get('AdExtensions') or [])],
            'BusinessId': rta.get('BusinessId'), 'TrackingPhoneId': rta.get('TrackingPhoneId'),
            'DisplayUrlPath': HYDRANGEA_AD['DisplayUrlPath']}}
        res = c.call('ads', 'add', {'Ads': [payload]})
        ids = [x.get('Id') for x in (res.get('AddResults') or [])]
        errs = [x.get('Errors') for x in (res.get('AddResults') or []) if x.get('Errors')]
        assert ids and ids[0] and not errs, res
        hydrangea_ad_id = ids[0]
        try:
            c.call('ads', 'moderate', {'SelectionCriteria': {'Ids': [hydrangea_ad_id]}})
        except DirectError as ex:
            print('   moderate:', str(ex)[:150])
        log_entry(state, 'H1', f'Объявление «Гортензии» {hydrangea_ad_id} в М2.4',
                  rollback={'svc': 'ads_delete', 'ids': [hydrangea_ad_id]},
                  created_ids=[hydrangea_ad_id])
        print(f'[H1] ✅ создано объявление гортензий: {hydrangea_ad_id}, отправлено в модерацию')
        time.sleep(0.8)

    # ---- P1: пауза ключа лилий ----
    if 'P1' not in done:
        res = c.call('keywords', 'suspend', {'SelectionCriteria': {'Ids': SUSPEND_KEYS}})
        errs = [x.get('Errors') for x in (res.get('SuspendResults') or []) if x.get('Errors')]
        assert not errs, errs
        log_entry(state, 'P1', f'Пауза ключей {SUSPEND_KEYS} (лилии)',
                  rollback={'svc': 'keywords', 'method': 'resume',
                            'params': {'SelectionCriteria': {'Ids': SUSPEND_KEYS}}})
        print(f'[P1] ✅ ключ приостановлен: {SUSPEND_KEYS} (букет лилий купить)')
        time.sleep(0.8)

    # ---- P1b: пион-минусы в М2.4 (автотаргетинг через API не отключается — 8305) ----
    if 'P1b' not in done:
        new_items = ['поэзия', 'flowerpoetry'] + PEONY_NEG_M24
        res = c.call('adgroups', 'update', {'AdGroups': [
            {'Id': PEONY_GROUP, 'NegativeKeywords': {'Items': new_items}}]})
        errs = [x.get('Errors') for x in (res.get('UpdateResults') or []) if x.get('Errors')]
        assert not errs, errs
        log_entry(state, 'P1b', f'М2.4: минус-слова группы + пион-формы {PEONY_NEG_M24}',
                  rollback={'svc': 'adgroups', 'method': 'update',
                            'params': {'AdGroups': [{'Id': PEONY_GROUP,
                                          'NegativeKeywords': {'Items': ['поэзия', 'flowerpoetry']}}]}})
        print(f'[P1b] ✅ М2.4: пион-запросы заблокированы групповыми минусами (автотаргетинг ON, '
              f'переориентируется на гортензии)')
        time.sleep(0.8)

    # ---- P2: пауза объявления пионов ----
    if 'P2' not in done:
        res = c.call('ads', 'suspend', {'SelectionCriteria': {'Ids': [PEONY_AD]}})
        errs = [x.get('Errors') for x in (res.get('SuspendResults') or []) if x.get('Errors')]
        assert not errs, errs
        log_entry(state, 'P2', f'Пауза объявления пионов {PEONY_AD}',
                  rollback={'svc': 'ads', 'method': 'resume',
                            'params': {'SelectionCriteria': {'Ids': [PEONY_AD]}}})
        print(f'[P2] ✅ объявление пионов приостановлено')
        time.sleep(0.8)

    # ---- P3: переименование М2.4 ----
    if 'P3' not in done:
        old_name = groups.get(PEONY_GROUP)
        res = c.call('adgroups', 'update', {'AdGroups': [
            {'Id': PEONY_GROUP, 'Name': PEONY_NEWNAME}]})
        errs = [x.get('Errors') for x in (res.get('UpdateResults') or []) if x.get('Errors')]
        assert not errs, errs
        log_entry(state, 'P3', f'М2.4 переименована: {old_name} → {PEONY_NEWNAME}',
                  rollback={'svc': 'adgroups', 'method': 'update',
                            'params': {'AdGroups': [{'Id': PEONY_GROUP, 'Name': old_name}]}})
        print(f'[P3] ✅ М2.4 переименована')
        time.sleep(0.8)

    # ---- A1: массовый update объявлений (минимальные payload'ы: пропущенные поля не меняются) ----
    if 'A1' not in done:
        upd, rb = [], []
        skipped_t2 = []
        for a in ads:
            if a['Id'] == PEONY_AD:
                continue
            ta = a['TextAd']
            gname = groups.get(a['AdGroupId'], '')
            href = ta['Href']
            path = href.split('?')[0].replace(B, '')
            query = href[len(B + path):]
            new_href = B + HREF_FIX[path] + (query or UTM) if path in HREF_FIX else None
            t2 = ta.get('Title2') or title2_for(gname)
            if not t2:
                skipped_t2.append((a['Id'], gname)); continue
            textad = {'Title2': t2, 'SitelinkSetId': new_sl}
            rb_textad = {'Title2': None, 'SitelinkSetId': ta.get('SitelinkSetId')}
            if new_href:
                textad['Href'] = new_href
                rb_textad['Href'] = href
            if a['Id'] == LILY_AD:   # М2-остаток: лилии не продаются
                textad.update({'Title': LILY_COPY['Title'], 'Text': LILY_COPY['Text'],
                               'DisplayUrlPath': LILY_COPY['DisplayUrlPath']})
                rb_textad.update({'Title': ta['Title'], 'Text': ta['Text'],
                                  'DisplayUrlPath': ta.get('DisplayUrlPath')})
            upd.append({'Id': a['Id'], 'TextAd': textad})
            rb.append({'Id': a['Id'], 'TextAd': rb_textad})
        if skipped_t2:
            print('   !! нет правила Заголовка 2, пропущены:', skipped_t2)
        errs_all = []
        for batch in chunks(upd, 10):
            res = c.call('ads', 'update', {'Ads': batch})
            for x in (res.get('UpdateResults') or []):
                if x.get('Errors'): errs_all.append((x.get('Id'), x['Errors']))
            time.sleep(1.0)
        if errs_all:
            log_entry(state, 'A1_PARTIAL', f'Часть объявлений обновлена, ошибки: {errs_all[:5]}',
                      rollback={'svc': 'ads', 'method': 'update', 'params': {'Ads': rb}})
            raise SystemExit(f'A1 ошибки: {errs_all[:5]} — доступен --rollback')
        log_entry(state, 'A1', f'UPDATE {len(upd)} объявлений (Href/Заголовок2/быстрые ссылки)',
                  rollback={'svc': 'ads', 'method': 'update', 'params': {'Ads': rb}},
                  updated_ids=[u['Id'] for u in upd])
        print(f'[A1] ✅ обновлено объявлений: {len(upd)}')
        state['updated_ad_ids'] = [u['Id'] for u in upd]; st_save(state)
        time.sleep(0.8)

    # ---- A2: модерация ----
    if 'A2' not in done:
        ids = state.get('updated_ad_ids') or [a['Id'] for a in ads if a['Id'] != PEONY_AD]
        try:
            c.call('ads', 'moderate', {'SelectionCriteria': {'Ids': ids}})
            log_entry(state, 'A2', f'Модерация {len(ids)} объявлений', rollback=None)
            print(f'[A2] ✅ отправлено в модерацию: {len(ids)}')
        except DirectError as ex:
            print(f'[A2] moderate: {str(ex)[:200]}')

    state['finished'] = datetime.datetime.now().isoformat(); st_save(state)
    print('\n✅ ГОТОВО. Откат: python3 apply_21-10.py --rollback')
    print(f'   Новый набор быстрых ссылок: {state.get("new_sitelink_set")}')


if __name__ == '__main__':
    main()
