# -*- coding: utf-8 -*-
import json, os, sys, csv, io, datetime, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT
c=client()
T=datetime.date(2026,10,17)
CAND=['SearchPhrase','Query','SearchQuery','Criteria','CriteriaId','CampaignId','CampaignName',
      'AdGroupId','AdGroupName','AdId','Impressions','Clicks','Ctr','Cost','AvgCpc','Conversions',
      'CostPerConversion','ImpressionPosition','ClickPosition','AvgClickPosition','Date','IsText',
      'SearchPhrasePosition','WeightedCtr','AudienceDemographics','ExternalNetwork']
def tryf(fields):
    rd={'SelectionCriteria':{'DateFrom':(T-datetime.timedelta(days=90)).isoformat(),'DateTo':T.isoformat(),'Filter':[]},
        'FieldNames':fields,'ReportName':'sq','ReportType':'SEARCH_QUERY_PERFORMANCE_REPORT',
        'DateRangeType':'CUSTOM_DATE','Format':'TSV','IncludeVAT':'YES'}
    tsv=c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
    return list(csv.DictReader(io.StringIO(tsv), delimiter='\t'))
ok=[]
for f in CAND:
    try:
        tryf([f]); ok.append(f); print(f"  ✅ {f}")
    except Exception as e:
        m=str(e); print(f"  ❌ {f}: {m[m.find('error_detail'):m.find('error_detail')+95] if 'error_detail' in m else m[:95]}")
    time.sleep(11)
print("\nВАЛИДНЫЕ ПОЛЯ:", ok)
if 'SearchPhrase' in ok:
    base=[x for x in ['CampaignId','AdGroupId','SearchPhrase','Impressions','Clicks','Cost','Conversions'] if x in ok]
    print("\nпробую набор:", base)
    try:
        rows=tryf(base); print("  ✅ строк:", len(rows))
    except Exception as e: print("  ❌", str(e)[:200])
