# -*- coding: utf-8 -*-
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
for fld in ['TextCampaign','Strategy','CampaignDomain','TextCampaignFieldNames']:
    try:
        p={'SelectionCriteria':{'Ids':[40732207]},'FieldNames':['Id','Name']+([fld] if fld!='TextCampaignFieldNames' else [])}
        if fld=='TextCampaignFieldNames':
            p['FieldNames']=['Id','Name','TextCampaign']; p['TextCampaignFieldNames']=['BiddingStrategy','PriorityGoals','CounterIds','Settings','AttributionModel','NegativeKeywordSharedSetIds']
        r=c.call('campaigns','get',p)
        print(f"✅ {fld}:"); print(json.dumps(r,ensure_ascii=False)[:2200]); 
        json.dump(r, open(os.path.join(OUT,'live_campaign_strategy.json'),'w'), ensure_ascii=False, indent=1)
        break
    except DirectError as e:
        print(f"❌ {fld}: {str(e)[:180]}")
