# -*- coding: utf-8 -*-
"""Финальная верификация: каждый кандидат проверен на конфликт со ВСЕМИ живыми ключами."""
import json, os, sys, re, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import OUT
WS=os.environ.get('ARENA_WORKSPACE','"$ARENA_WORKSPACE"')
kw=json.load(open(os.path.join(OUT,'live_keywords.json')))['Keywords']
ags=json.load(open(os.path.join(OUT,'live_adgroups.json')))['AdGroups']
cmp_=json.load(open(os.path.join(OUT,'live_campaigns_full.json')))['Campaigns']
gn={g['Id']:g['Name'] for g in ags}; gs={g['Id']:g.get('Status') for g in ags}
negs={x.strip().lstrip('-').lstrip('!+').strip().lower() for x in
      [c for c in cmp_ if c['Id']==40732207][0]['NegativeKeywords']['Items']}
live=[k for k in kw if k['CampaignId']==40732207 and k.get('State')=='ON' and gs.get(k['AdGroupId'])!='DRAFT']
allkw=[k for k in kw if k['CampaignId']==40732207]
def pos(ph): return [t.lstrip('+!').lower() for t in str(ph).split() if not t.startswith('-')]

CAND=['flowwow','maxflora','ultraflowers','версаль','диния','букетная','линия розы',
      'гладиолусы','гардины','шипами','поэзия','flowerpoetry']
print(f"проверяем {len(CAND)} кандидатов против {len(live)} живых ключей ({len(allkw)} всего в кампании)\n")
print(f"{'кандидат':16} {'уже в минусах':13} {'конфликт с живыми':52} вердикт")
print('-'*104)
final=[]
for c in CAND:
    words=c.split()
    conf=[]
    for k in live:
        pw=pos(k['Keyword'])
        if all(w in pw for w in words): conf.append((k['Keyword'], gn.get(k['AdGroupId'])))
    already = all(w in negs for w in words)
    v = '❌ НЕ ДОБАВЛЯТЬ' if conf else ('— уже есть' if already else '✅ ДОБАВИТЬ')
    if not conf and not already: final.append(c)
    cf = f"{len(conf)}: {conf[0][0][:40]} [{conf[0][1][:14]}]" if conf else 'нет'
    print(f"-{c:15} {'да' if already else 'нет':13} {cf:52} {v}")

print(f"\n{'='*104}\nИТОГОВЫЙ СПИСОК К ДОБАВЛЕНИЮ ({len(final)}):")
print('  ' + ' '.join('-'+x for x in final))

# групповые минус-слова для маршрутизации бренда
brand_grp=[g for g in ags if g['CampaignId']==40732207 and g.get('Status')!='DRAFT' and g['Name']!='Б1. Бренд']
have={g['Id'] for g in ags if (g.get('NegativeKeywords') or {}).get('Items')}
need=[g for g in brand_grp if g['Id'] not in have]
print(f"\n{'='*104}\nГРУППОВЫЕ МИНУС-СЛОВА ДЛЯ БРЕНДА")
print(f"  живых небрендовых групп: {len(brand_grp)}")
print(f"  уже имеют групповые минус-слова: {len([g for g in brand_grp if g['Id'] in have])}")
print(f"  нужно добавить «-поэзия -flowerpoetry» в: {len(need)} групп")
for g in need: print(f"     {g['Id']}  {g['Name']}")
json.dump({'campaign_negatives_add':final,
           'group_negatives':{'phrase':'-поэзия -flowerpoetry',
                              'groups':[{'id':g['Id'],'name':g['Name']} for g in need]}},
          open(os.path.join(OUT,'negatives_plan_18-10.json'),'w'), ensure_ascii=False, indent=1)
