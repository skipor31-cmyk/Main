# -*- coding: utf-8 -*-
"""Какие живые ключи содержат гео зоны доставки, а какие «голые» — от этого зависит безопасная ширина гео."""
import json, os, sys, re, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import OUT
WS=os.environ.get('ARENA_WORKSPACE','"$ARENA_WORKSPACE"')
kw=json.load(open(os.path.join(OUT,'live_keywords.json')))['Keywords']
ags=json.load(open(os.path.join(OUT,'live_adgroups.json')))['AdGroups']
gn={g['Id']:g['Name'] for g in ags}; gs={g['Id']:g.get('Status') for g in ags}
live=[k for k in kw if k['CampaignId']==40732207 and k.get('State')=='ON' and gs.get(k['AdGroupId'])!='DRAFT']

ZONE=['раменск','жуковск','быково','дергаево','кратово','родник','удельная','хрипань',
      'ильинск','верейск','вялков','гжель','заболоть','кузнецов','сафон','софьин','чулков',
      'петровск','новое','московская область','подмосковье','московск']
def has_geo(ph):
    p=ph.lower()
    return [w for w in ZONE if w in p]

with_geo=[k for k in live if has_geo(k['Keyword'])]
no_geo=[k for k in live if not has_geo(k['Keyword'])]
print(f"живых ключей: {len(live)}")
print(f"  ✅ с гео зоны доставки : {len(with_geo)} ({len(with_geo)/len(live)*100:.0f}%)")
print(f"  ⚠️  БЕЗ гео («голые»)    : {len(no_geo)} ({len(no_geo)/len(live)*100:.0f}%)")

print("\n=== «ГОЛЫЕ» КЛЮЧИ ПО ГРУППАМ (при широком гео они сольют бюджет) ===")
bg=collections.defaultdict(list)
for k in no_geo: bg[gn.get(k['AdGroupId'])].append(k['Keyword'])
for g,lst in sorted(bg.items(), key=lambda x:-len(x[1])):
    print(f"\n  ● {g} — {len(lst)} голых ключей:")
    for x in lst[:14]: print(f"      {x[:84]}")
    if len(lst)>14: print(f"      … ещё {len(lst)-14}")

print("\n\n=== БРЕНД-КЛЮЧИ (Б1) ===")
for k in live:
    if gn.get(k['AdGroupId'])=='Б1. Бренд':
        print(f"  {k['Keyword']!r:44} гео в ключе: {'да' if has_geo(k['Keyword']) else 'НЕТ'}")

print("\n=== КЛЮЧИ ПРО РОМАШКИ/РАНУНКУЛЮСЫ/ОРХИДЕИ/АЛЬСТРОМЕРИИ (уже есть?) ===")
for w in ['ромашк','ранункулюс','орхиде','альстромер','лилии','лилия','сухоцвет','гладиолус']:
    hits=[(k['Keyword'], gn.get(k['AdGroupId']), k.get('State')) for k in kw
          if k['CampaignId']==40732207 and w in k['Keyword'].lower()]
    print(f"  {w:14} найдено {len(hits):3}")
    for h in hits[:6]: print(f"      {h[0][:56]!r:58} [{h[1]}] {h[2]}")
