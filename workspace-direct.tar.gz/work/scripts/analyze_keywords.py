# -*- coding: utf-8 -*-
"""Аналитика: по каким ключевым словам были переходы + кандидаты в минус-слова."""
import json, os, sys, csv, collections, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import OUT
WS=os.environ.get('ARENA_WORKSPACE','"$ARENA_WORKSPACE"')
def f(x):
    try: return float(x)
    except: return 0.0
G=['36895733','168348169','136163740','197752867','339702220','168348397']
GN={'36895733':'Заказ','168348169':'1клик','136163740':'Звонок','197752867':'Форма',
    '339702220':'Контакты','168348397':'Мессендж'}
ags=json.load(open(os.path.join(OUT,'live_adgroups.json')))['AdGroups']
gname={str(g['Id']):g['Name'] for g in ags}

rows=list(csv.DictReader(open(os.path.join(OUT,'r_keyword_90d.tsv'),encoding='utf-8'),delimiter='\t'))
recs=[]
for r in rows:
    d={g:f(r.get(f'Conversions_{g}_LSCCD')) for g in G}
    recs.append({'crit':r['Criteria'],'camp':r['CampaignId'],'grp':gname.get(r['AdGroupId'],r['AdGroupId']),
                 'imp':f(r['Impressions']),'clk':f(r['Clicks']),'cost':f(r['Cost']),
                 'ctr':f(r['Ctr']),'cpc':f(r['AvgCpc']),'ord':d['36895733'],'all':sum(d.values()),'goals':d})

# --- 1. КЛЮЧИ, ПО КОТОРЫМ БЫЛИ ПЕРЕХОДЫ ---
clicked=[r for r in recs if r['clk']>0]
clicked.sort(key=lambda x:-x['clk'])
print("="*112)
print(f"1. КЛЮЧЕВЫЕ СЛОВА, ПО КОТОРЫМ БЫЛИ ПЕРЕХОДЫ НА САЙТ (90 дней, всего {len(clicked)} из {len(recs)})")
print("="*112)
print(f"{'клики':>5} {'показ':>7} {'расход₽':>8} {'CPC₽':>7} {'CTR%':>6} {'зак':>4} {'всЦ':>4}  ключевая фраза / группа")
for r in clicked:
    nm=r['crit'] if r['crit'] else '(автотаргетинг/фид)'
    print(f"{r['clk']:5.0f} {r['imp']:7.0f} {r['cost']:8.0f} {r['cpc']:7.1f} {r['ctr']:6.2f} {r['ord']:4.0f} {r['all']:4.0f}  {nm[:52]:54} [{r['grp'][:20]}]")
print(f"\nИТОГО: {sum(r['clk'] for r in clicked):.0f} кликов, {sum(r['cost'] for r in clicked):.0f} ₽, "
      f"{sum(r['ord'] for r in clicked):.0f} заказов, {sum(r['all'] for r in clicked):.0f} всех целей")

# --- 2. топ по расходу ---
print("\n"+"="*112)
print("2. ТОП-15 ПО РАСХОДУ (где уходят деньги)")
print("="*112)
for r in sorted(recs,key=lambda x:-x['cost'])[:15]:
    nm=r['crit'] or '(автотаргетинг/фид)'
    flag='🔴' if r['all']==0 else ('🟢' if r['ord']>0 else '🟡')
    print(f"{flag} {r['cost']:8.0f}₽ {r['clk']:5.0f} клик CPC {r['cpc']:6.1f} зак {r['ord']:.0f} всеЦ {r['all']:.0f}  {nm[:56]:58} [{r['grp'][:20]}]")

# --- 3. CSV-выгрузка ---
p=os.path.join(OUT,'КЛЮЧИ_С_ПЕРЕХОДАМИ_90д.csv')
with open(p,'w',newline='',encoding='utf-8-sig') as fh:
    w=csv.writer(fh,delimiter=';')
    w.writerow(['Ключевая фраза','Кампания','Группа','Показы','Клики','CTR %','Расход ₽','CPC ₽',
                'Заказы','Все цели']+[GN[g] for g in G]+['Вердикт'])
    for r in sorted(recs,key=lambda x:-x['cost']):
        v='🔴 слив (0 целей)' if r['cost']>0 and r['all']==0 else ('🟢 есть заказ' if r['ord']>0 else ('🟡 есть цели' if r['all']>0 else '—'))
        w.writerow([r['crit'] or '(автотаргетинг/фид)',r['camp'],r['grp'],int(r['imp']),int(r['clk']),
                    round(r['ctr'],2),round(r['cost'],2),round(r['cpc'],2),int(r['ord']),int(r['all'])]
                   +[int(r['goals'][g]) for g in G]+[v])
print(f"\nсохранено: {p} ({os.path.getsize(p)/1024:.0f} КБ)")

# --- 4. агрегат по группам: где клики есть, а заказов нет ---
print("\n"+"="*112)
print("3. ПО ГРУППАМ: клики / расход / заказы (только поисковая кампания 40732207)")
print("="*112)
bg=collections.defaultdict(lambda: collections.Counter())
for r in recs:
    if r['camp']!='40732207': continue
    b=bg[r['grp']]
    b['clk']+=r['clk']; b['cost']+=r['cost']; b['imp']+=r['imp']; b['ord']+=r['ord']; b['all']+=r['all']; b['n']+=1
print(f"{'группа':34} {'ключ':>4} {'показ':>7} {'клик':>5} {'расход₽':>8} {'CPC₽':>7} {'зак':>4} {'всЦ':>4}")
for gn_,b in sorted(bg.items(), key=lambda x:-x[1]['cost']):
    if b['clk']==0 and b['cost']==0: continue
    print(f"{gn_[:34]:34} {b['n']:4.0f} {b['imp']:7.0f} {b['clk']:5.0f} {b['cost']:8.0f} "
          f"{(b['cost']/b['clk'] if b['clk'] else 0):7.1f} {b['ord']:4.0f} {b['all']:4.0f}")
