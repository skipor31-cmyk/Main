import os, sys

WS = os.environ.get('ARENA_WORKSPACE') or '/home/user'
SCRIPTS = os.path.join(WS, 'extract/workspace/skills_repo/extracted1/'
                           'skill_for_claude_code_yandex_direct-main/scripts')
sys.path.insert(0, SCRIPTS)
os.chdir(SCRIPTS)
from direct_api import DirectClient, load_config, DirectError, collect_add_results  # noqa

CFG = load_config()
OUT = os.path.join(WS, 'work/analysis')
os.makedirs(OUT, exist_ok=True)


def client():
    return DirectClient(CFG)
