# -*- coding: utf-8 -*-
"""
Майнинг минус-слов из РЕАЛЬНЫХ поисковых запросов (архив sq_40732207_90d.tsv, 103 запроса)
+ проверка каждого кандидата на конфликт с живыми ключами и с уже имеющимися минус-словами.
"""
import json, os, sys, csv, re, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import OUT
WS = os.environ.get('ARENA_WORKSPACE', '"$ARENA_WORKSPACE"')

# --- данные ---
sq = list(csv.DictReader(open(os.path.join(WS,'extract/workspace/analysis/sq_40732207_90d.tsv'),encoding='utf-8'),delimiter='\t'))
kw = json.load(open(os.path.join(OUT,'live_keywords.json')))['Keywords']
ags= json.load(open(os.path.join(OUT,'live_adgroups.json')))['AdGroups']
cmp_=json.load(open(os.path.join(OUT,'live_campaigns_full.json')))['Campaigns']
gname={g['Id']:g['Name'] for g in ags}; gstat={g['Id']:g.get('Status') for g in ags}
negs=[x.strip().lstrip('-').lstrip('!+').strip().lower() for x in
      [c for c in cmp_ if c['Id']==40732207][0]['NegativeKeywords']['Items']]
def f(x):
    try: return float(x)
    except: return 0.0

# живые ключи: позитивные слова (без inline-минусов)
live=[k for k in kw if k['CampaignId']==40732207 and k.get('State')=='ON' and gstat.get(k['AdGroupId'])!='DRAFT']
def pos_words(ph):
    return [t.lstrip('+!').lower() for t in str(ph).split() if not t.startswith('-')]
live_pos=collections.defaultdict(list)
for k in live:
    for w in pos_words(k['Keyword']):
        for part in re.findall(r'[а-яёa-z0-9]{2,}', w): live_pos[part].append(k['Keyword'])

print(f"исходники: {len(sq)} запросов | {len(live)} живых ключей | {len(negs)} минус-слов кампании")

# --- категории кандидатов ---
COMPETITORS = {   # бренд конкурента -> что это
 'flowwow':'Flowwow — маркетплейс цветов (конкурент)',
 'maxflora':'MaxFlora — сеть доставки (конкурент)',
 'ultraflowers':'UltraFlowers — доставка (конкурент)',
 'версаль':'«Версаль» — цветочный магазин в Раменском',
 'диния':'«Диния» — цветочный магазин',
 'букетная':'«Букетная» — магазин на ул. Молодёжная',
 'линия':'«Линия розы» — магазин в Раменском',
}
NO_ASSORT = {   # запрос про товар, которого нет в 11 категориях /po_cvetam/
 'гладиолусы':'гладиолусов на сайте нет (0 URL в sitemap из 5 119, нет категории)',
 'подсолнухи':'подсолнухов нет',
 'ирисы':'ирисов нет',
 'лилии':'⚠️ категории лилий нет, но объявление М2-остаток обещает «Букеты лилий…» — см. вопрос к вам',
}
JUNK = {'гардины':'гардины = шторы, очевидный мусор',
        'шипами':'«розы бордовые с шипами» — нестандартный запрос, 1 клик 161 ₽, 0 конверсий'}
SPEED = {'минут':'«за 30 минут» — вы delivers за 2 часа, заведомо невыполнимое обещание'}

def norm(t): return re.sub(r'[^\wё]','',t.lower())

cands=collections.defaultdict(lambda: {'imp':0.0,'clk':0.0,'cost':0.0,'conv':0.0,'q':[]})
for r in sq:
    q=r['Query'].lower(); i,c,co,cv=f(r['Impressions']),f(r['Clicks']),f(r['Cost']),f(r['Conversions'])
    toks=[norm(t) for t in q.split()]
    for grp,name in (('COMPETITORS',COMPETITORS),('NO_ASSORT',NO_ASSORT),('JUNK',JUNK),('SPEED',SPEED)):
        for w in name:
            if w in toks or any(w in t for t in toks):
                d=cands[(grp,w)]; d['imp']+=i; d['clk']+=c; d['cost']+=co; d['conv']+=cv; d['q'].append(r['Query'])

print("\n" + "="*104)
print("КАНДИДАТЫ В МИНУС-СЛОВА (из реальных запросов, с проверкой на конфликт)")
print("="*104)
LABEL={'COMPETITORS':'🏷  БРЕНДЫ КОНКУРЕНТОВ','NO_ASSORT':'🚫 НЕТ В АССОРТИМЕНТЕ',
       'JUNK':'🗑  МУСОР','SPEED':'⏱  НЕВЫПОЛНИМОЕ ОБЕЩАНИЕ'}
res=[]
for grp in ['COMPETITORS','NO_ASSORT','JUNK','SPEED']:
    items=[(k[1],v) for k,v in cands.items() if k[0]==grp]
    if not items: continue
    print(f"\n{LABEL[grp]}")
    print(f"  {'слово':16} {'показ':>5} {'клик':>4} {'расход₽':>8}  {'конфликт?':46} решение")
    for w,v in sorted(items, key=lambda x:-x[1]['cost']):
        conflict = live_pos.get(w)
        already  = w in negs
        cf = f"🔴 УБИВАЕТ {len(conflict)} живых ключей" if conflict else ("уже в минусах" if already else "✅ конфликтов нет")
        verdict = 'НЕ ДОБАВЛЯТЬ' if conflict else ('уже есть' if already else 'ДОБАВИТЬ')
        note = {**COMPETITORS,**NO_ASSORT,**JUNK,**SPEED}[w]
        print(f"  -{w:15} {v['imp']:5.0f} {v['clk']:4.0f} {v['cost']:8.2f}  {cf:46} {verdict}")
        print(f"     ↳ {note[:88]}")
        for q in list(dict.fromkeys(v["q"]))[:3]: print(f"        запрос: {q[:80]}")
        res.append({'group':grp,'word':w,'imp':v['imp'],'clk':v['clk'],'cost':v['cost'],
                    'conflict':bool(conflict),'already':already,'verdict':verdict,
                    'note':note,'queries':list(dict.fromkeys(v['q']))})

add=[r for r in res if r['verdict']=='ДОБАВИТЬ']
print(f"\n{'='*104}")
print(f"ИТОГО: добавить {len(add)} минус-слов | суммарно по ним {sum(r['cost'] for r in add):.2f} ₽ / "
      f"{sum(r['clk'] for r in add):.0f} кликов / {sum(r['imp'] for r in add):.0f} показов за 90 дней")
print("  список:", ' '.join('-'+r['word'] for r in add))
json.dump(res, open(os.path.join(OUT,'negatives_candidates.json'),'w'), ensure_ascii=False, indent=1)

# --- брендовые запросы, которые НЕ должны быть минус-словами ---
print(f"\n{'='*104}\n⚠️  СВОЙ БРЕНД — НЕ минус-слово, а перенос в группу Б1")
br=[r for r in sq if 'цветочная поэзия' in r['Query'].lower() or 'поэзия' in r['Query'].lower()]
tb=sum(f(r['Cost']) for r in br); tk=sum(f(r['Clicks']) for r in br)
print(f"  запросов: {len(br)} | кликов: {tk:.0f} | расход: {tb:.2f} ₽ | групп: "
      f"{sorted({gname.get(int(r['AdGroupId']),'?') for r in br})}")
for r in br: print(f"     {f(r['Impressions']):3.0f} показ / {f(r['Clicks']):2.0f} клик / {f(r['Cost']):7.2f} ₽  «{r['Query']}»  [{gname.get(int(r['AdGroupId']))}]")

# --- деревни/улицы: в зоне доставки или нет ---
print(f"\n{'='*104}\n📍 ГЕО в запросах — сверить с зоной доставки (17 регионов)")
for pat in ['воровского','фабричная','северном шоссе','новое село','петровское','приборостроителей','сафоново','куйбышева','московская область']:
    hits=[r for r in sq if pat in r['Query'].lower()]
    if hits:
        cost=sum(f(r['Cost']) for r in hits); clk=sum(f(r['Clicks']) for r in hits)
        print(f"  {pat:20} {len(hits)} зап. / {clk:.0f} клик / {cost:7.2f} ₽   напр.: «{hits[0]['Query'][:56]}»")
