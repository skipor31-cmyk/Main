#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Статистика сентябрь vs октябрь по группам/ключам кампании 40732207."""
import json, sys, os, csv, io, time
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client, OUT
from direct_api import DirectError

c = client()

def rep(rtype, fields, dfrom, dto, tag, filt=None):
    fn = os.path.join(OUT, f'deep_{tag}.tsv')
    if os.path.exists(fn) and os.path.getsize(fn) > 50:
        print(tag, 'already exists, skip'); return
    sel = {'DateFrom': dfrom, 'DateTo': dto, 'Filter': filt or []}
    rd = {'SelectionCriteria': sel, 'FieldNames': fields,
          'ReportName': f'deep_{tag}', 'ReportType': rtype,
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    for attempt in range(8):
        try:
            tsv = c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
            open(fn,'w').write(tsv)
            rows = list(csv.DictReader(io.StringIO(tsv), delimiter='\t'))
            print(tag, 'rows:', len(rows)); return
        except DirectError as e:
            if '56' in str(e.code) or 'Превышен лимит' in str(e):
                print(f'{tag}: rate-limit, wait 15s (attempt {attempt+1})'); time.sleep(15); continue
            raise
    print(tag, 'FAILED after retries')

FILT = [{'Field': 'CampaignId', 'Operator': 'EQUALS', 'Values': ['40732207']}]

rep('CRITERIA_PERFORMANCE_REPORT',
    ['AdGroupId','AdGroupName','CriteriaId','Criteria','Impressions','Clicks','Cost'],
    '2026-09-01','2026-09-30','crit_sep', FILT)
rep('CRITERIA_PERFORMANCE_REPORT',
    ['AdGroupId','AdGroupName','CriteriaId','Criteria','Impressions','Clicks','Cost'],
    '2026-10-01','2026-10-21','crit_oct', FILT)
rep('CAMPAIGN_PERFORMANCE_REPORT',
    ['Date','CampaignId','CampaignName','Impressions','Clicks','Cost'],
    '2026-09-01','2026-10-21','camp_day', None)
