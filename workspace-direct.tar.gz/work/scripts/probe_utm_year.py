# -*- coding: utf-8 -*-
import json, os, sys, urllib.parse, urllib.request, time, re, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG, OUT
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; BASE='https://api-metrika.yandex.net'
def q(p):
    url=BASE+'/stat/v1/data?'+urllib.parse.urlencode(p, doseq=True)
    for t in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=180) as r:
                return json.loads(r.read().decode())
        except Exception as e: print('   retry:',str(e)[:60]); time.sleep(8)
    return {}
for win in ['365daysAgo','180daysAgo']:
    d=q({'ids':CID,'metrics':'ym:pv:pageviews','dimensions':'ym:pv:URL','date1':win,'date2':'today','limit':50000,'accuracy':'full'})
    data=d.get('data') or []
    urls=[(x['dimensions'][0]['name'] or '', x['metrics'][0]) for x in data]
    n_utm=[(u,m) for u,m in urls if 'utm_source' in u]
    n_ya =[(u,m) for u,m in urls if 'utm_ya_campaign' in u]
    n_term=[(u,m) for u,m in urls if 'utm_term' in u]
    print(f"\n=== окно {win} ===")
    print(f"  URL-строк: {len(urls)} | просмотров: {sum(m for _,m in urls):.0f} | totals={d.get('totals')}")
    print(f"  с utm_source    : {len(n_utm):5} URL / {sum(m for _,m in n_utm):8.0f} просмотров")
    print(f"  с utm_term      : {len(n_term):5} URL / {sum(m for _,m in n_term):8.0f} просмотров")
    print(f"  с utm_ya_campaign: {len(n_ya):4} URL / {sum(m for _,m in n_ya):8.0f} просмотров  (Яндекс Бизнес geoadv — ДЛЯ СРАВНЕНИЯ)")
    for u,m in sorted(n_utm,key=lambda x:-x[1])[:6]: print(f"     {m:6.0f} {u[:150]}")
    if win=='365daysAgo':
        json.dump(urls, open(os.path.join(OUT,'m_urls_365d.json'),'w'), ensure_ascii=False)
