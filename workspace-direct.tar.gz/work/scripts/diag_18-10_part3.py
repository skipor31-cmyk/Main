# -*- coding: utf-8 -*-
"""Диагностика 18.10, часть 3:
- полное расписание (в т.ч. суббота/воскресенье — 17-18.10 это СБ/ВС!)
- сравнение минус-слов кампании с XLSX (применилась ли загрузка)
- какой группы есть минус-слова
- keywords/ads с минимальными полями (спецрежим режет enums)
- Метрика: визиты с Директа 10–18.10
- история: были ли показы в прошлые выходные
"""
import json, os, sys, csv, io, datetime, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, CFG, DirectError

c = client()
CID = 40732207
WS = os.environ.get('ARENA_WORKSPACE') or '/home/user'

print("=" * 70)
print("A. РАСПИСАНИЕ ПОКАЗОВ (TimeTargeting) — полностью")
print("=" * 70)
DAYS = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС']
try:
    r = c.call('campaigns', 'get', {'SelectionCriteria': {'Ids': [CID]},
                                    'FieldNames': ['Id', 'TimeTargeting']})
    tt = r['Campaigns'][0]['TimeTargeting']
    sched = (tt.get('Schedule') or {}).get('Items', [])
    print(f"  HolidaysSchedule: {tt.get('HolidaysSchedule')}")
    for row in sched:
        parts = row.split(',')
        d = int(parts[0])
        hours = parts[1:25]
        on_hours = [i for i, v in enumerate(hours) if v != '0']
        label = DAYS[d-1] if 1 <= d <= 7 else f'?{d}'
        if on_hours:
            print(f"  {label}: показ {on_hours[0]:02d}:00–{on_hours[-1]+1:02d}:00  ({len(on_hours)} ч)")
        else:
            print(f"  {label}: *** ПОКАЗЫ ВЫКЛЮЧЕНЫ ВЕСЬ ДЕНЬ ***")
    for dstr in ['2026-10-17', '2026-10-18']:
        dt = datetime.date.fromisoformat(dstr)
        print(f"  {dstr} = {DAYS[dt.weekday()]} (weekday={dt.weekday()})")
except DirectError as e:
    print("  ERR:", str(e)[:250])

print()
print("=" * 70)
print("B. МИНУС-СЛОВА КАМПАНИИ vs XLSX — применилась ли загрузка?")
print("=" * 70)
try:
    r = c.call('campaigns', 'get', {'SelectionCriteria': {'Ids': [CID]},
                                    'FieldNames': ['Id', 'NegativeKeywords']})
    live_items = r['Campaigns'][0]['NegativeKeywords']['Items']
    print(f"  live Items: {len(live_items)} фраз")
    live_norm = set(x.strip().lower() for x in live_items)
    live_words = set()
    for x in live_items:
        for w in x.strip().lower().split():
            live_words.add(w)

    ADDED = ['flowwow', 'maxflora', 'ultraflowers', 'версаль', 'диния',
             'букетная', 'гладиолусы', 'гардины', 'шипами']
    REMOVED = ['онлайн', '101', 'срочно', 'подмосковье', 'сайт']
    print("  ДОБАВЛЕННЫЕ в XLSX (ищем в live):")
    for w in ADDED:
        in_phr = w in live_norm
        in_word = w in live_words
        print(f"    {w:14} phrase={'+' if in_phr else '—'} word={'+' if in_word else '—'}")
    print(f"    'линия розы'  phrase={'+' if 'линия розы' in live_norm else '—'}  "
          f"line_word={'+' if 'линия' in live_words else '—'}")
    print("  УДАЛЁННЫЕ в XLSX (не должно быть в live):")
    for w in REMOVED:
        hits = [x for x in live_items if w in x.strip().lower().split() or
                x.strip().lower() == w or
                (w == '101' and '101' in x)]
        print(f"    {w:14} {'❌ ПРИСУТСТВУЕТ: ' + str(hits[:3]) if hits else '✅ отсутствует'}")
    # Сравнение с ячейками XLSX
    import openpyxl
    for path, tag in [(os.path.join(WS, 'uploads/40732207.xlsx'), 'ОРИГИНАЛ'),
                      (os.path.join(WS, 'work/xlsx/40732207_итоговый.xlsx'), 'ИТОГОВЫЙ')]:
        if not os.path.exists(path):
            print(f"  {tag}: файл не найден {path}")
            continue
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        sh = wb['Тексты'] if 'Тексты' in wb.sheetnames else wb[wb.sheetnames[0]]
        cell = None
        for row in sh.iter_rows(min_row=1, max_row=15, min_col=5, max_col=5):
            for cc in row:
                if cc.value and isinstance(cc.value, str) and len(cc.value) > 500:
                    cell = cc.value
                    print(f"  {tag}: найден E-блок в {cc.coordinate}, {len(cell)} симв.")
        if cell:
            toks = [t.strip().lstrip('-').lower() for t in re.split(r'\s+', cell) if t.strip()]
            tset = set(toks)
            print(f"    токенов: {len(toks)}  уникальных: {len(tset)}")
            print(f"    добавленные присутствуют: {[w for w in ADDED if w in tset]}")
            print(f"    удалённые присутствуют:   {[w for w in REMOVED if w in tset]}")
            # live vs xlsx: сколько live-фраз не находится в xlsx-токенах
            missing = [x for x in live_items
                       if not all(w in tset for w in x.strip().lower().split())]
            print(f"    live-фраз, отсутствующих в XLSX: {len(missing)} (примеры: {missing[:4]})")
        wb.close()
except DirectError as e:
    print("  ERR:", str(e)[:250])

print()
print("=" * 70)
print("C. ГРУППА С МИНУС-СЛОВАМИ (какая?)")
print("=" * 70)
try:
    r = c.call('adgroups', 'get', {'SelectionCriteria': {'CampaignIds': [CID]},
                                   'FieldNames': ['Id', 'Name', 'Status', 'NegativeKeywords']})
    for g in r.get('AdGroups', []):
        nk = (g.get('NegativeKeywords') or {}).get('Items', [])
        if nk:
            print(f"  G{g['Id']} '{g.get('Name','')}' Status={g.get('Status')}: {' '.join(nk[:20])}")
except DirectError as e:
    print("  ERR:", str(e)[:200])

print()
print("=" * 70)
print("D. КЛЮЧИ (минимальные поля)")
print("=" * 70)
try:
    r = c.call('keywords', 'get', {'SelectionCriteria': {'CampaignIds': [CID]},
                                   'FieldNames': ['Id', 'AdGroupId', 'Keyword',
                                                  'State', 'Status', 'Bid']})
    kws = r.get('Keywords', [])
    from collections import Counter
    print(f"  всего: {len(kws)}")
    st = Counter((k.get('State'), k.get('Status')) for k in kws)
    for key, n in st.most_common(12):
        print(f"    State={key[0]} Status={key[1]}: {n}")
    on = [k for k in kws if k.get('State') == 'ON']
    bids = sorted([k.get('Bid') for k in on if k.get('Bid') is not None])
    nobid = sum(1 for k in on if k.get('Bid') is None)
    print(f"  ON: {len(on)}, без ставки: {nobid}")
    if bids:
        print(f"  ставки: min={bids[0]} p25={bids[len(bids)//4]} med={bids[len(bids)//2]} "
              f"p75={bids[3*len(bids)//4]} max={bids[-1]}")
except DirectError as e:
    print("  ERR:", str(e)[:350])

print()
print("=" * 70)
print("E. ОБЪЯВЛЕНИЯ — пробуем достать Href/TextAd (важно для проверки загрузки)")
print("=" * 70)
for fields in [['Id', 'TextAd'], ['Id', 'Href'], ['Id', 'AdGroupId', 'State', 'Status']]:
    try:
        r = c.call('ads', 'get', {'SelectionCriteria': {'CampaignIds': [CID]},
                                  'FieldNames': fields})
        ads = r.get('Ads', [])
        print(f"  ✅ fields={fields}: {len(ads)} ads")
        if 'TextAd' in fields and ads:
            n_t2 = sum(1 for a in ads if (a.get('TextAd') or {}).get('Title2'))
            n_new = sum(1 for a in ads
                        if 'buketi-cvetov' in ((a.get('TextAd') or {}).get('Href') or '')
                        or 'po_cvetam' in ((a.get('TextAd') or {}).get('Href') or ''))
            n_on = sum(1 for a in ads if a.get('State') == 'ON')
            print(f"     ON: {n_on}, с Title2: {n_t2}, с новым URL: {n_new}")
            for a in ads[:3]:
                ta = a.get('TextAd') or {}
                print(f"     Ad {a['Id']}: {ta.get('Href','')[:120]}")
        break
    except DirectError as e:
        print(f"  ❌ fields={fields}: {str(e)[:200]}")

print()
print("=" * 70)
print("F. МЕТРИКА: визиты с Директа и всего, 10–18.10")
print("=" * 70)
import urllib.request, urllib.parse
try:
    q = {
        'ids': str(CFG['metrica']['counter_id']),
        'date1': '2026-10-10', 'date2': '2026-10-18',
        'metrics': 'ym:ad:visits,ym:ad:clicks,ym:s:visits',
        'dimensions': 'ym:ad:date',
        'direct_client_logins': CFG['metrica']['direct_client_logins'],
        'sort': 'ym:ad:date',
    }
    url = 'https://api-metrika.yandex.net/stat/v1/data?' + urllib.parse.urlencode(q)
    req = urllib.request.Request(url, headers={'Authorization': 'OAuth ' + CFG['token']})
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode())
    for row in data.get('data', []):
        print(f"  {row['dimensions'][0]['name']}: ad_visits={row['metrics'][0]} "
              f"ad_clicks={row['metrics'][1]} all_visits={row['metrics'][2]}")
    tq = data.get('totals')
    if tq:
        print(f"  ИТОГО: ad_visits={tq[0]} ad_clicks={tq[1]} all_visits={tq[2]}")
except Exception as e:
    print("  metrika ERR:", repr(e)[:250])

print()
print("=" * 70)
print("G. ИСТОРИЯ: показы по дням за сентябрь–октябрь (были ли выходные?)")
print("=" * 70)
p = os.path.join(OUT, 'r_campaign_by_day.tsv')
if os.path.exists(p):
    with open(p, encoding='utf-8') as f:
        rows = list(csv.DictReader(f, delimiter='\t'))
    rows40 = [r_ for r_ in rows if r_.get('CampaignId') == str(CID)]
    rows40.sort(key=lambda x: x.get('Date', ''))
    for r_ in rows40[-21:]:
        d = datetime.date.fromisoformat(r_['Date'])
        wd = DAYS[d.weekday()]
        imp = int(float(r_.get('Impressions') or 0))
        bar = '#' * min(60, imp // 2)
        print(f"  {r_['Date']} {wd} imp={imp:4d} clk={r_.get('Clicks'):>3} cost={r_.get('Cost'):>8} {bar}")
else:
    print("  файл не найден")
