# -*- coding: utf-8 -*-
"""Отчёты Директа: кампании/дни, группы, ключи, поисковые запросы + цели Метрики."""
import json, os, sys, csv, io, datetime, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, CFG
sys.path.insert(0, os.path.join(os.environ.get('ARENA_WORKSPACE','"$ARENA_WORKSPACE"'),
    'extract/workspace/skills_repo/extracted1/skill_for_claude_code_yandex_direct-main/scripts'))
c=client()
GOALS=[str(CFG['metrica']['primary_goal_id'])]+[str(g) for g in CFG['metrica']['secondary_goal_ids']]
print("goals:", GOALS)

def report(rtype, fields, dfrom, dto, extra=None, filt=None, goals=None):
    sel={'DateFrom':dfrom,'DateTo':dto,'Filter':filt or []}
    rd={'SelectionCriteria':sel,'FieldNames':fields,
        'ReportName':f"{rtype}_{dfrom}_{dto}",'ReportType':rtype,
        'DateRangeType':'CUSTOM_DATE','Format':'TSV','IncludeVAT':'YES'}
    if goals: rd['Goals']=goals; rd['AttributionModels']=['LSC']
    if extra: rd.update(extra)
    tsv=c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
    return list(csv.DictReader(io.StringIO(tsv), delimiter='\t'))

TODAY=datetime.date(2026,10,17)
D90=(TODAY-datetime.timedelta(days=90)).isoformat()
D30=(TODAY-datetime.timedelta(days=30)).isoformat()
D120=(TODAY-datetime.timedelta(days=120)).isoformat()
TOD=TODAY.isoformat()

jobs=[
 ('r_campaign_by_day.tsv','CAMPAIGN_PERFORMANCE_REPORT',
   ['Date','CampaignId','CampaignName','Impressions','Clicks','Ctr','Cost','AvgCpc','Conversions','CostPerConversion'],
   D120, TOD, None),
 ('r_campaign_goals_90d.tsv','CAMPAIGN_PERFORMANCE_REPORT',
   ['CampaignId','CampaignName','Impressions','Clicks','Ctr','Cost','AvgCpc','Conversions','CostPerConversion'],
   D90, TOD, GOALS),
 ('r_adgroup_90d.tsv','ADGROUP_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','AdGroupName','Impressions','Clicks','Ctr','Cost','Conversions','CostPerConversion'],
   D90, TOD, GOALS),
 ('r_keyword_90d.tsv','CRITERIA_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','CriteriaId','Criteria','Impressions','Clicks','Ctr','Cost','AvgCpc','Conversions','CostPerConversion'],
   D90, TOD, GOALS),
 ('r_query_90d.tsv','SEARCH_QUERY_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','CriteriaId','Criteria','SearchPhrase','Impressions','Clicks','Cost','Conversions'],
   D90, TOD, GOALS),
 ('r_ad_90d.tsv','AD_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','AdId','Impressions','Clicks','Ctr','Cost','Conversions','CostPerConversion'],
   D90, TOD, GOALS),
 ('r_keyword_30d.tsv','CRITERIA_PERFORMANCE_REPORT',
   ['CampaignId','AdGroupId','CriteriaId','Criteria','Impressions','Clicks','Cost','Conversions','CostPerConversion'],
   D30, TOD, GOALS),
]
for name, rt, fields, df, dt, goals in jobs:
    if os.path.exists(os.path.join(OUT,name)) and os.path.getsize(os.path.join(OUT,name))>50:
        print(f"  = {name} уже есть"); continue
    time.sleep(12)
    try:
        rows=report(rt, fields, df, dt, goals=goals)
        p=os.path.join(OUT,name)
        with open(p,'w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f, fieldnames=fields, delimiter='\t'); w.writeheader(); w.writerows(rows)
        print(f"  ✅ {name:30} строк: {len(rows):6d}  ({os.path.getsize(p)/1024:.0f} KB)")
    except Exception as e:
        print(f"  ❌ {name:30} {str(e)[:200]}")
print("DONE")
