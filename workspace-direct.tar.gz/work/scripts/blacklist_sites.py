# -*- coding: utf-8 -*-
"""
Блэклист площадок РСЯ (YD53/YD54). Данные: Метрика ym:ad:DirectOrderName × ym:ad:DirectPlatform, 90 дней.
Учитывает УЖЕ существующие ExcludedSites каждой кампании — добавляет только недостающее.

  python3 blacklist_sites.py                  # отчёт + формирование списков
  python3 blacklist_sites.py --apply          # записать ExcludedSites (сейчас -> ошибка 54, спецрежим)
  python3 blacklist_sites.py --rollback       # вернуть прежние списки

Критерий «плохой площадки»: мобильное приложение/игра ИЛИ отказ >= 55%.
"""
import json, os, sys, csv, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
WS=os.environ.get('ARENA_WORKSPACE','"$ARENA_WORKSPACE"')
XLSX=os.path.join(WS,'work','xlsx')
BOUNCE=55.0
APP_PREFIX=('com.','and.','ru.','me.','con.','br.','easy.','tile.','sorting.','teskin.','closet.',
            'video.','game.yandex.ru')
C2ID={'[ПОИСК] Доставка Раменское':'40732207',
      '[РСЯ] Фид - Офферный ретаргетинг':'704507321',
      '[ПОИСК-ФИД] Товарная кампания - Поиск + Динамика':'704504054',
      'Товарная кампания flowerpoetry.ru от 07.07.22':'76065880',
      '[ПОИСК] Доставка_NEW':'52821021'}
ID2N={v:k for k,v in C2ID.items()}
LIVE=['40732207','704507321','704504054']

rows=json.load(open(os.path.join(OUT,'m_campaign_x_platform.json')))
try: exc=json.load(open(os.path.join(OUT,'excluded_sites_all.json')))
except Exception: exc={}

bad=collections.defaultdict(dict)   # cid -> plat -> (cost, bounce, vis)
for r in rows:
    cid=C2ID.get(r['dimensions'][0]['name'])
    if not cid: continue
    p=r['dimensions'][1]['name']; m=r['metrics']
    if not (p.startswith(APP_PREFIX) or m[3]>=BOUNCE): continue
    prev=bad[cid].get(p)
    if prev is None or m[2]>prev[0]: bad[cid][p]=(m[2],m[3],m[0])

print("="*104)
print("БЛЭКЛИСТ ПЛОЩАДОК РСЯ — по кампаниям, с учётом уже существующих ExcludedSites")
print("="*104)
summary={}
for cid in LIVE:
    cur=set(exc.get(cid,[]))
    todo=sorted(((v[0],p,v[1],v[2]) for p,v in bad.get(cid,{}).items() if p not in cur), reverse=True)
    tot_all=sum(v[0] for v in bad.get(cid,{}).values())
    tot_new=sum(t[0] for t in todo)
    summary[cid]={'already':len(cur),'to_add':len(todo),'leaked_rub':round(tot_new,2),'bad_total_rub':round(tot_all,2)}
    print(f"\n● {cid}  {ID2N.get(cid,'?')}")
    print(f"   уже в ExcludedSites: {len(cur)} · плохих площадок в отчёте: {len(bad.get(cid,{}))} "
          f"· НЕ заблокировано: {len(todo)} ({tot_new:,.0f} ₽)")
    for c,p,b,v in todo[:12]:
        kind='прил/игра' if p.startswith(APP_PREFIX) else f'отказ {b:.0f}%'
        print(f"      {p[:44]:46} {kind:12} {v:6.0f} визит {c:9,.0f} ₽")
    if len(todo)>12: print(f"      ... ещё {len(todo)-12}")
    if todo:
        fn=os.path.join(XLSX,f'БЛЭКЛИСТ_добавить_{cid}.txt')
        open(fn,'w',encoding='utf-8').write('\n'.join(t[1] for t in todo))
        cf=os.path.join(XLSX,f'БЛЭКЛИСТ_добавить_{cid}.csv')
        with open(cf,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f,delimiter=';'); w.writerow(['Площадка','Тип','Визиты','Отказ %','Расход ₽'])
            for c,p,b,v in todo: w.writerow([p,'приложение/игра' if p.startswith(APP_PREFIX) else f'отказ>={BOUNCE:.0f}%',int(v),round(b,1),round(c,2)])
print("\n"+"="*104)
print("ИТОГ")
for cid,s in summary.items():
    print(f"  {cid} {ID2N.get(cid,'')[:34]:36} добавить {s['to_add']:>4} площадок · {s['leaked_rub']:>10,.0f} ₽ исторической утечки")
json.dump(summary, open(os.path.join(OUT,'blacklist_summary.json'),'w'), ensure_ascii=False, indent=1)
print("\nВАЖНО: поисковая кампания 40732207 чистая — её блэклист из 57 записей работает (утечка 24 ₽ из 36 893 ₽).")
print("Основная утечка (9 572 ₽) — в РСЯ-кампании 704507321, которая уже SUSPENDED. Блэклист нужен ПЕРЕД её перезапуском.")

if '--apply' in sys.argv or '--rollback' in sys.argv:
    c=client(); st=os.path.join(OUT,'apply_state_blacklist.json')
    prev=json.load(open(st)) if os.path.exists(st) else {}
    for cid in LIVE:
        i=int(cid); cur=exc.get(cid,[])
        if '--apply' in sys.argv:
            todo=[l.strip() for l in open(os.path.join(XLSX,f'БЛЭКЛИСТ_добавить_{cid}.txt'),encoding='utf-8') if l.strip()] \
                 if os.path.exists(os.path.join(XLSX,f'БЛЭКЛИСТ_добавить_{cid}.txt')) else []
            if not todo: print(f"\n{cid}: добавлять нечего"); continue
            merged=sorted(set(cur)|set(todo))
            try:
                c.call('campaigns','update',{'Campaigns':[{'Id':i,'ExcludedSites':{'Items':merged}}]})
                print(f"\n{cid}: ✅ записано {len(merged)} (было {len(cur)}, добавлено {len(todo)})")
                prev[cid]={'old':cur,'new':merged}
            except DirectError as e:
                print(f"\n{cid}: ⛔ {str(e)[:110]}")
                if 'Нет прав' in str(e) or 'code 54' in str(e):
                    print("   Спецрежим Яндекса. Список готов: work/xlsx/БЛЭКЛИСТ_добавить_%s.txt — вставить вручную или повторить --apply позже."%cid)
        else:
            if cid in prev:
                try:
                    c.call('campaigns','update',{'Campaigns':[{'Id':i,'ExcludedSites':{'Items':prev[cid]['old']}}]})
                    print(f"  {cid}: откачено до {len(prev[cid]['old'])} записей")
                except DirectError as e: print(f"  {cid}: ERR {str(e)[:110]}")
    json.dump(prev, open(st,'w'), ensure_ascii=False, indent=1)
