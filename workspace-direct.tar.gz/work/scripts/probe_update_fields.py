# -*- coding: utf-8 -*-
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
AID=1922742232187391646
r=c.call('ads','get',{'SelectionCriteria':{'Ids':[AID]},'FieldNames':['Id'],
   'TextAdFieldNames':['Title','Title2','Text','Href','Mobile','SitelinkSetId','AdExtensions',
                       'BusinessId','TrackingPhoneId','DisplayUrlPath','DisplayDomain']})
ta=r['Ads'][0]['TextAd']
base={'Title':ta['Title'],'Text':ta['Text'],'Href':ta['Href']}
CANDS=['Mobile','SitelinkSetId','AdExtensionIds','AdExtensions','BusinessId','TrackingPhoneId',
       'DisplayUrlPath','DisplayDomain','Title2','VideoExtension','PriceExtension','Features',
       'HrefCondition','TurboPageId','ButtonExtension','TrackingToken','MobileFeatures','FinalUrl',
       'LfHref','LfButtonText','ErirAdDescription','Carousel','VCardId','PreferVCardOverBusiness',
       'AdImageHash','LogoExtensionHash','DutPrefix','DutSuffix']
ok,bad=[],[]
for f in CANDS:
    val = ta.get(f)
    if f=='AdExtensionIds': val=[e['AdExtensionId'] for e in (ta.get('AdExtensions') or [])]
    if val is None: val={'Mobile':'NO','SitelinkSetId':ta['SitelinkSetId'],'BusinessId':ta['BusinessId'],
        'TrackingPhoneId':ta['TrackingPhoneId'],'DisplayUrlPath':ta['DisplayUrlPath'],
        'DisplayDomain':ta['DisplayDomain'],'Title2':'x'*20,'TrackingToken':'tok123'}.get(f)
    if val is None: continue
    p=dict(base); p[f]=val
    try:
        # НЕ применяем реально — проверяем только валидацию, используя ads.update с тем же Href
        c.call('ads','update',{'Ads':[{'Id':AID,'TextAd':p}]})
        ok.append(f)
    except DirectError as e:
        m=str(e)
        bad.append((f, 'неизвестный параметр' if 'неизвестный параметр' in m else m.split('|')[0][:70]))
print("ПРИНИМАЕТ (update реально выполнен для этих полей):", ok)
print("\nОТКЛОНЯЕТ:")
for f,m in bad: print(f"   {f:26} {m}")
