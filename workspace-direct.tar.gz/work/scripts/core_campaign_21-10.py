# -*- coding: utf-8 -*-
"""
Вариант A (одобрен владельцем 21.10.2026):
1) P1 — 7 минус-слов на мусор 20-21.10 в кампанию 40732207.
2) P2-P6 — новая кампания «[ПОИСК-ЯДРО] Доставка Раменское»:
   стратегия «Средняя цена клика» 250 ₽ (потолок 450 ₽), недельный бюджет 7 000 ₽,
   12 групп-копий головных (Д1–Д4.2, К1, К1.2, К1.3-топ, К2-гео), ~70 фраз,
   автотаргетинг только EXACT, объявления-копии текущих ACCEPTED (прямые URL + UTM),
   быстрые ссылки 1518331115, уточнения, подменный номер — как в 40732207.
3) P7 — после модерации: пауза головных объявлений в 40732207 (без конкуренции с собой)
   + пауза 4 гео-ключей в К2 (уходят в новую кампанию).

    python3 core_campaign_21-10.py            # DRY-RUN
    python3 core_campaign_21-10.py --apply    # применить
    python3 core_campaign_21-10.py --rollback # откатить всё
"""
import json, os, sys, time, datetime, csv
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError, collect_add_results

STATE = os.path.join(OUT, 'apply_state_core_21-10.json')
OLD = 40732207
ZONE17 = [10750, 20571, 10718, 117802, 118482, 119749, 105573, 120351,
          133110, 161506, 161512, 161520, 161524, 161526, 161536, 161541, 161548]
SITELINKS = 1518331115
CALLOUTS = [36689089, 36689093, 36689312, 36689333, 36689334, 36689336,
            36689428, 36689429, 36689431, 7103330, 7103334, 9309894]
BUSINESS, TRACKPHONE = 103128457869, 6247510023894529225
COUNTER = 33595239
AT_CATEGORIES = [{"Category": "EXACT", "Value": "YES"}, {"Category": "ALTERNATIVE", "Value": "NO"},
                 {"Category": "COMPETITOR", "Value": "NO"}, {"Category": "BROADER", "Value": "NO"},
                 {"Category": "ACCESSORY", "Value": "NO"}]
AT_BRANDS = [{"Option": "WITHOUT_BRANDS", "Value": "YES"},
             {"Option": "WITH_ADVERTISER_BRAND", "Value": "YES"}]
BRAND_NEG = ['поэзия', 'flowerpoetry']
NEW_NEGS = ['фантазия', 'атриум', 'грунт', 'сортировка', 'пасха', 'анализ', 'uilrjdf']

# среднее CPC / потолок / недельный бюджет (микро-рубли)
AVG_CPC, BID_CEIL, WEEKLY = 250_000_000, 450_000_000, 7_000_000_000

# исходные группы: (имя в новой кампании, source AdGroupId)
SRC = [
    ('Я-Д1. Доставка — город',            4166852642),
    ('Я-Д1.2 Доставка — город (+с)',      4166852847),
    ('Я-Д1.3 Доставка — город и район',   4166852849),
    ('Я-Д2. На дом +с доставкой',         4166852655),
    ('Я-Д2.2 На дом',                     4166852705),
    ('Я-Д2.3 Курьером',                   4166852729),
    ('Я-Д4. Область',                     4166852706),
    ('Я-Д4.2 В область',                  4166852753),
    ('Я-К1. Заказ +с доставкой',          3688099772),
    ('Я-К1.2 Заказать +с доставкой',      4166852644),
    ('Я-К1.3 Купить-заказать (топ)',      4166852738),
    ('Я-К2Г. Доставка Раменское (уточн.)', 5806224425),
]
K2_GEO_KEYS = [58167571692, 58167571693, 58167571694, 58167571696]  # недорого/срочно/сегодня/цена
K13_GROUP = 4166852738
HEAD_ADGROUP_IDS = [g for _, g in SRC if g != 5806224425]  # К2 не паузим целиком


def st_load():
    if os.path.exists(STATE):
        return json.load(open(STATE, encoding='utf-8'))
    return {'created': datetime.datetime.now().isoformat(), 'applied': []}


def st_save(s):
    json.dump(s, open(STATE, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


def build_key_lists():
    """Ключи для новой кампании из live-среза + сентябрьской статистики."""
    kws = json.load(open(os.path.join(OUT, 'live_keywords_21-10.json'), encoding='utf-8'))
    by_group = {}
    for k in kws:
        by_group.setdefault(k['AdGroupId'], []).append(k)
    # сентябрь: какие ключи К1.3 реально работали
    sep_ids = set()
    for r in csv.DictReader(open(os.path.join(OUT, 'deep_crit_sep.tsv')), delimiter='\t'):
        if r['AdGroupName'].startswith('К1.3') and (int(r['Impressions']) > 0 or int(r['Clicks']) > 0):
            sep_ids.add(int(r['CriteriaId']))
    plan = {}
    for name, gid in SRC:
        ks = [k for k in by_group.get(gid, []) if k['Keyword'] != '---autotargeting']
        if gid == K13_GROUP:
            on = [k for k in ks if k['State'] == 'ON']
            rev = [k for k in ks if k['State'] == 'SUSPENDED' and k['Id'] in sep_ids]
            ks = on + rev
            plan['k13_revived'] = [(k['Id'], k['Keyword'][:60]) for k in rev]
        if gid == 5806224425:   # К2 — только 4 гео-ключа
            ks = [k for k in ks if k['Id'] in K2_GEO_KEYS]
        plan[name] = [(k['Keyword'], k['State']) for k in ks]
    return plan


def fetch_source_ads(c, c501):
    """Объявления-источники: по одному ON/ACCEPTED на группу, с прямым URL и 2 заголовками."""
    gids = [g for _, g in SRC]
    r = c.call('ads', 'get', {
        'SelectionCriteria': {'AdGroupIds': gids, 'States': ['ON'], 'Statuses': ['ACCEPTED', 'MODERATION', 'PREACCEPTED']},
        'FieldNames': ['Id', 'AdGroupId', 'State', 'Status', 'Type'],
        'TextAdFieldNames': ['Title', 'Text', 'Href', 'DisplayUrlPath', 'SitelinkSetId']})
    ads = r.get('Ads', [])
    r5 = c501.call('ads', 'get', {
        'SelectionCriteria': {'AdGroupIds': gids, 'States': ['ON', 'OFF']},
        'FieldNames': ['Id', 'AdGroupId'],
        'ResponsiveAdFieldNames': ['Titles', 'Texts']})
    titles, texts501 = {}, {}
    for a in r5.get('Ads', []):
        ra = a.get('ResponsiveAd') or {}
        ts = [t['Title'] for t in (ra.get('Titles') or [])]
        if ts:
            titles[a['Id']] = ts
        xs = [t['Text'] for t in (ra.get('Texts') or [])]
        if xs:
            texts501[a['Id']] = xs
    by_group = {}
    for a in ads:
        ta = a.get('TextAd') or {}
        href = ta.get('Href', '')
        if 'flowerpoetry.ru' not in href or 'utm_source' not in href:
            continue
        # предпочтение — комбинаторным (id 19xx.xxxx) с ≥1 заголовком из v501
        score = (len(titles.get(a['Id'], [])), str(a['Id']).startswith('19'))
        cur = by_group.get(a['AdGroupId'])
        if cur is None or score > cur[0]:
            by_group[a['AdGroupId']] = (score, a, ta)
    out = {}
    UTM = ('?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}'
           '&utm_content={ad_id}&utm_term={keyword}')
    for name, gid in SRC:
        if gid not in by_group:
            raise SystemExit(f'Нет подходящего объявления-источника для группы {name} ({gid})')
        _, a, ta = by_group[gid]
        ts = titles.get(a['Id']) or [ta.get('Title', '')]
        xs = texts501.get(a['Id']) or []
        text = xs[0] if xs else ta.get('Text', '')
        if len(text) > 81:   # обрезаем по границе предложений до лимита 81
            import re as _re
            sents = _re.split(r'(?<=\.)\s+', text)
            acc = ''
            for s_ in sents:
                cand = (acc + ' ' + s_).strip()
                if len(cand) <= 81:
                    acc = cand
                else:
                    break
            text = acc or text[:81]
        # посадочная по теме группы: доставка -> /informaciya-o-dostavke/, купить/заказать -> /buketi-cvetov/
        theme_path = '/informaciya-o-dostavke/' if name.startswith('Я-Д') else '/buketi-cvetov/'
        href = 'https://flowerpoetry.ru' + theme_path + UTM
        out[name] = {'src_ad_id': a['Id'], 'src_group_id': gid,
                     'titles': ts[:2], 'text': text,
                     'href': href, 'src_href': ta.get('Href', ''),
                     'display': ta.get('DisplayUrlPath', '')}
    # все ON-объявления ГОЛОВНЫХ групп (К2 не трогаем — он кормит кампанию)
    on_ads = [a['Id'] for a in ads if a['AdGroupId'] in HEAD_ADGROUP_IDS]
    return out, on_ads


def main():
    mode = 'apply' if '--apply' in sys.argv else 'rollback' if '--rollback' in sys.argv else 'dry'
    c = client()
    c501 = client(); c501.base = 'https://api.direct.yandex.com/json/v501/'
    state = st_load()

    # ---------------- ROLLBACK ----------------
    if mode == 'rollback':
        print('ОТКАТ (обратный порядок)...')
        for e in reversed(state.get('applied', [])):
            rb = e.get('rollback')
            if rb:
                try:
                    cl = c501 if rb.get('svc501') else c
                    cl.call(rb.get('svc') or rb['svc501'], rb['method'], rb['params'])
                    print(f"  [{e['id']}] откачено")
                except DirectError as ex:
                    print(f"  [{e['id']}] ERR {str(ex)[:180]}")
                continue
            ids = e.get('created_ids') or []
            if e['id'].startswith('P2_campaign') and state.get('new_campaign_id'):
                try:
                    c.call('campaigns', 'suspend', {'SelectionCriteria': {'Ids': [state['new_campaign_id']]}})
                    print(f"  [P2] кампания {state['new_campaign_id']} приостановлена")
                except DirectError as ex:
                    print('  [P2] ERR', str(ex)[:150])
            elif ids:
                svc = 'ads' if e['id'].startswith('P5') else 'keywords' if e['id'].startswith('P4') else 'adgroups'
                try:
                    c.call(svc, 'suspend', {'SelectionCriteria': {'Ids': ids}})
                    print(f"  [{e['id']}] приостановлено {len(ids)}")
                except DirectError as ex:
                    print(f"  [{e['id']}] ERR {str(ex)[:150]}")
        state['rolled_back'] = datetime.datetime.now().isoformat(); st_save(state)
        return

    # ---------------- P0: сбор данных ----------------
    print('P0: собираю исходники...')
    camp = c.call('campaigns', 'get', {
        'SelectionCriteria': {'Ids': [OLD]},
        'FieldNames': ['Id', 'NegativeKeywords', 'TimeTargeting']}).get('Campaigns', [{}])[0]
    old_negs = (camp.get('NegativeKeywords') or {}).get('Items') or []
    tt = camp.get('TimeTargeting') or {}
    print(f'   минус-слов кампании сейчас: {len(old_negs)}')
    keyplan = build_key_lists()
    total_keys = sum(len(v) for k, v in keyplan.items() if isinstance(v, list))
    print('   ключей по группам:', {k: len(v) for k, v in keyplan.items() if isinstance(v, list)},
          '| всего фраз:', total_keys)
    print('   воскрешаемые из К1.3:', keyplan.get('k13_revived'))
    adsrc, old_head_on_ads = fetch_source_ads(c, c501)
    for name, a in adsrc.items():
        print(f"   {name[:34]:34s} ← ad {a['src_ad_id']} | T: {a['titles'][0][:40]!r}"
              f"{(' / ' + repr(a['titles'][1][:30])) if len(a['titles'])>1 else ''}")
    print(f'   ON-объявлений в головных группах 40732207 (кандидаты на паузу в P7): {len(old_head_on_ads)}')

    if mode == 'dry':
        plan = {'new_negs': NEW_NEGS, 'groups': {k: v for k, v in keyplan.items() if isinstance(v, list)},
                'revived': keyplan.get('k13_revived'), 'ads': adsrc,
                'pause_old_ads': old_head_on_ads, 'pause_k2_keys': K2_GEO_KEYS,
                'strategy': {'AVERAGE_CPC': AVG_CPC // 10**6, 'BidCeiling': BID_CEIL // 10**6,
                             'WeeklySpendLimit': WEEKLY // 10**6}}
        json.dump(plan, open(os.path.join(OUT, 'plan_core_campaign.json'), 'w'), ensure_ascii=False, indent=1)
        print('\n--- DRY-RUN: план в work/analysis/plan_core_campaign.json. Ничего не изменено. ---')
        return

    def step(sid, desc, svc, method, params, cl=None, rollback=None, creates=None):
        cl = cl or c
        print(f'\n[{sid}] {desc}')
        try:
            res = cl.call(svc, method, params)
        except DirectError as ex:
            print('   ОШИБКА:', str(ex)[:400]); st_save(state)
            print('   СТОП. Доступен --rollback.'); sys.exit(2)
        entry = {'id': sid, 'desc': desc, 'rollback': rollback,
                 'ts': datetime.datetime.now().isoformat()}
        if creates:
            ids, errs, warns = collect_add_results(res, 'add')
            got = [x for x in ids if x is not None]
            entry['created_ids'] = got
            print(f'   создано {len(got)}' + (f' | ОШИБКИ: {errs[:4]}' if errs else '') +
                  (f' | WARN: {warns[:2]}' if warns else ''))
        else:
            print('   ok:', json.dumps(res, ensure_ascii=False)[:200])
        state['applied'].append(entry); st_save(state)
        return res

    # ---------------- P1: минус-слова ----------------
    add_negs = [n for n in NEW_NEGS if n not in old_negs]
    if add_negs:
        new_full = old_negs + add_negs
        step('P1_negs', f'+{len(add_negs)} минус-слов в 40732207 ({", ".join(add_negs)})',
             'campaigns', 'update',
             {'Campaigns': [{'Id': OLD, 'NegativeKeywords': {'Items': new_full}}]},
             rollback={'svc': 'campaigns', 'method': 'update',
                       'params': {'Campaigns': [{'Id': OLD, 'NegativeKeywords': {'Items': old_negs}}]}})
        negs_final = new_full
    else:
        negs_final = old_negs
        print('\n[P1] минус-слова уже на месте — пропуск')

    # ---------------- P2: кампания ----------------
    if state.get('new_campaign_id'):
        NEWC = state['new_campaign_id']
        print(f'\n[P2] кампания уже создана ранее: {NEWC}')
    else:
        tt_clean = {k: v for k, v in (tt or {}).items() if v is not None}
        camp_params = {
            'Name': '[ПОИСК-ЯДРО] Доставка Раменское',
            'StartDate': '2026-10-21',
            'NegativeKeywords': {'Items': negs_final},
            'TimeTargeting': tt_clean or None,
            'TextCampaign': {
                'BiddingStrategy': {
                    'Search': {'BiddingStrategyType': 'AVERAGE_CPC',
                               'AverageCpc': {'AverageCpc': AVG_CPC, 'WeeklySpendLimit': WEEKLY}},
                    'Network': {'BiddingStrategyType': 'SERVING_OFF'}},
                'CounterIds': {'Items': [COUNTER]},
                'Settings': [{'Option': 'ADD_METRICA_TAG', 'Value': 'YES'}],
            },
        }
        camp_params = {k: v for k, v in camp_params.items() if v is not None}
        res = step('P2_campaign', 'Создать кампанию «[ПОИСК-ЯДРО] Доставка Раменское» '
                   '(AVERAGE_CPC 250₽, потолок 450₽, 7000₽/нед, поиск only)',
                   'campaigns', 'add', {'Campaigns': [camp_params]}, creates=True)
        new_ids = state['applied'][-1].get('created_ids') or []
        if not new_ids:
            print('   кампания не создана'); sys.exit(2)
        NEWC = new_ids[0]
        state['new_campaign_id'] = NEWC; st_save(state)
    print(f'   КАМПАНИЯ ID = {NEWC}')

    # ---------------- P3: группы ----------------
    if state.get('gid_by_name'):
        gmap = state['gid_by_name']
        print(f'\n[P3] группы уже созданы ранее: {len(gmap)}')
    else:
        step('P3_groups', f'{len(SRC)} групп', 'adgroups', 'add',
             {'AdGroups': [{'CampaignId': NEWC, 'Name': name, 'RegionIds': ZONE17,
                            'NegativeKeywords': {'Items': BRAND_NEG}} for name, _ in SRC]},
             creates=True)
        gids = state['applied'][-1].get('created_ids') or []
        if len(gids) != len(SRC):
            print('   созданы не все группы:', gids); sys.exit(2)
        gmap = dict(zip([n for n, _ in SRC], gids))
        state['gid_by_name'] = gmap; st_save(state)

    # ---------------- P4: ключи ----------------
    if state.get('kw_count'):
        print(f"\n[P4] ключи уже добавлены ранее: {state['kw_count']}")
    else:
        items = []
        for name, gid in SRC:
            for k, _st in keyplan[name]:
                items.append({'Keyword': k, 'AdGroupId': gmap[name]})
        step('P4_keys', f'{len(items)} фраз', 'keywords', 'add', {'Keywords': items}, creates=True)
        state['kw_count'] = len(items); st_save(state)
        step('P4b_autotarget', f'{len(SRC)} автотаргетинг-ключей (только EXACT)', 'keywords', 'add',
             {'Keywords': [{'Keyword': '---autotargeting', 'AdGroupId': gmap[n],
                            'AutotargetingCategories': AT_CATEGORIES,
                            'AutotargetingBrandOptions': AT_BRANDS} for n, _ in SRC]}, creates=True)

    # ---------------- P5: объявления ----------------
    if state.get('new_ad_ids'):
        ad_ids = state['new_ad_ids']
        print(f'\n[P5] объявления уже созданы ранее: {len(ad_ids)}')
    else:
        ads = []
        for name, _ in SRC:
            a = adsrc[name]
            t = a['titles']
            ads.append({'AdGroupId': gmap[name], 'TextAd': {
                'Title': t[0][:56], 'Text': a['text'][:81], 'Href': a['href'],
                'Mobile': 'NO', 'SitelinkSetId': SITELINKS, 'AdExtensionIds': CALLOUTS,
                'BusinessId': BUSINESS, 'TrackingPhoneId': TRACKPHONE,
                'DisplayUrlPath': a['display'][:20]}})
        step('P5_ads', f'{len(ads)} объявлений (копии проверенных, прямые URL)', 'ads', 'add',
             {'Ads': ads}, creates=True)
        ad_ids = state['applied'][-1].get('created_ids') or []
        state['new_ad_ids'] = ad_ids; st_save(state)

        # второй заголовок через v501 (в v5 Title2 для комбинаторных не работает)
        upd = []
        rb = []
        for (name, _), aid in zip(SRC, ad_ids):
            ts = adsrc[name]['titles']
            if len(ts) >= 2:
                upd.append({'Id': aid, 'ResponsiveAd': {'Titles': ts[:2]}})
                rb.append({'Id': aid, 'ResponsiveAd': {'Titles': ts[:1]}})
        if upd:
            time.sleep(2)
            step('P5b_titles501', f'Вторые заголовки у {len(upd)} объявлений (v501)',
                 'ads', 'update', {'Ads': upd}, cl=c501,
                 rollback={'svc501': 'ads', 'method': 'update', 'params': {'Ads': rb}})

    # ---------------- P6: модерация + ожидание ----------------
    if ad_ids:
        try:
            c.call('ads', 'moderate', {'SelectionCriteria': {'Ids': ad_ids}})
            print('\n[P6] отправлено в модерацию')
        except DirectError as e:
            print('\n[P6] moderate:', str(e)[:150])
    accepted = False
    for i in range(15):
        time.sleep(60)
        r = c.call('ads', 'get', {'SelectionCriteria': {'Ids': ad_ids},
                                  'FieldNames': ['Id', 'Status', 'State']})
        sts = [a.get('Status') for a in r.get('Ads', [])]
        n_acc = sts.count('ACCEPTED') + sts.count('PREACCEPTED')
        print(f'   [{i+1}/15] ACCEPTED/PREACCEPTED: {n_acc}/{len(sts)}')
        if n_acc == len(sts) and sts:
            accepted = True
            break
        if any(s == 'REJECTED' for s in sts):
            print('   есть REJECTED — стоп P7, нужна ручная проверка'); break
    state['ads_accepted'] = accepted; st_save(state)

    # ---------------- P7: пауза головных в 40732207 ----------------
    if any(e['id'] == 'P7_old_ads' for e in state.get('applied', [])):
        print('\n[P7] уже выполнено ранее — пропуск')
    elif accepted:
        pause_ads = [a for a in old_head_on_ads]
        step('P7_old_ads', f'Пауза {len(pause_ads)} головных объявлений в 40732207 '
               '(ядро переехало в новую кампанию)', 'ads', 'suspend',
             {'SelectionCriteria': {'Ids': pause_ads}},
             rollback={'svc': 'ads', 'method': 'resume',
                       'params': {'SelectionCriteria': {'Ids': pause_ads}}})
        step('P7_k2_geo', f'Пауза {len(K2_GEO_KEYS)} гео-ключей в К2 (переехали в Я-К2Г)',
             'keywords', 'suspend', {'SelectionCriteria': {'Ids': K2_GEO_KEYS}},
             rollback={'svc': 'keywords', 'method': 'resume',
                       'params': {'SelectionCriteria': {'Ids': K2_GEO_KEYS}}})
    else:
        print('\n[P7] ПРОПУЩЕНО: объявления новой кампании ещё не ACCEPTED — '
              'головные в 40732207 оставлены включёнными (пауза после модерации).')

    state['finished'] = datetime.datetime.now().isoformat(); st_save(state)
    print('\n✅ ГОТОВО. State: work/analysis/apply_state_core_21-10.json; откат: --rollback')


if __name__ == '__main__':
    main()
