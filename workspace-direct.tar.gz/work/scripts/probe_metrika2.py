# -*- coding: utf-8 -*-
"""18.10: что отдаёт Метрика теперь. Ищем связку с Директом и utm-разрезы."""
import json, os, sys, urllib.parse, urllib.request, urllib.error, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG, OUT
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; BASE='https://api-metrika.yandex.net'
def q(params):
    url=BASE+'/stat/v1/data?'+urllib.parse.urlencode(params, doseq=True)
    for t in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=90) as r:
                return 'OK', json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            b=e.read().decode()
            if 'direct_client_logins' in b or 'access_denied' in b: return 'DENIED', b[:200]
            if '503' in str(e.code) or '502' in str(e.code): time.sleep(6); continue
            return 'ERR', b[:200]
        except Exception as e:
            time.sleep(4)
    return 'ERR','retries exhausted'

print("=== ИЗМЕРЕНИЯ, СВЯЗАННЫЕ С ДИРЕКТОМ / РЕКЛАМОЙ ===")
AD_DIMS=['ym:ad:directCampaignID','ym:ad:directCampaign','ym:ad:directCampaignName',
         'ym:ad:directAdId','ym:ad:directAd','ym:ad:directPhrase','ym:ad:directKeyword',
         'ym:ad:directPlatform','ym:ad:directCondition','ym:ad:directAdGroupName',
         'ym:ad:trafficSource','ym:ad:adNetwork','ym:ad:campaign','ym:ad:phrase']
for d in AD_DIMS:
    st,r=q({'ids':CID,'metrics':'ym:s:visits','dimensions':d,'date1':'30daysAgo','date2':'today','limit':5})
    if st=='OK':
        print(f"  ✅ {d:32} -> {[x['dimensions'][0]['name'] for x in (r.get('data') or [])]}")
    else:
        print(f"  ❌ {d:32} {st}: {str(r)[:105]}")

print("\n=== МЕТРИКИ ym:ad:* (для пары с ad-измерениями) ===")
for m in ['ym:ad:clicks','ym:ad:cost','ym:ad:impressions','ym:ad:goalreaches','ym:ad:visits']:
    st,r=q({'ids':CID,'metrics':m,'date1':'30daysAgo','date2':'today'})
    print(f"  {st:7} {m:22} {str(r)[:100] if st!='OK' else (r.get('data') or [{}])[0].get('metrics')}")

print("\n=== URL / UTM-разрезы (чтобы достать utm_term={keyword}) ===")
for d in ['ym:pv:URL','ym:pv:URLDimension','ym:s:landingPage','ym:s:referer','ym:s:fullReferer',
          'ym:pv:pageviewID','ym:s:source','ym:s:medium','ym:s:utmSource','ym:s:utmTerm']:
    st,r=q({'ids':CID,'metrics':'ym:pv:pageviews' if d.startswith('ym:pv') else 'ym:s:visits',
            'dimensions':d,'date1':'14daysAgo','date2':'today','limit':3})
    if st=='OK':
        print(f"  ✅ {d:24} -> {[x['dimensions'][0]['name'][:70] for x in (r.get('data') or [])]}")
    else:
        print(f"  ❌ {d:24} {st}: {str(r)[:85]}")
