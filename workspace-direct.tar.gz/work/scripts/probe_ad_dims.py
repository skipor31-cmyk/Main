# -*- coding: utf-8 -*-
import json, os, sys, urllib.parse, urllib.request, urllib.error, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG, OUT
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; BASE='https://api-metrika.yandex.net'
def q(p, tries=3):
    p=dict(p); p['direct_client_logins']='skipor31'
    url=BASE+'/stat/v1/data?'+urllib.parse.urlencode(p, doseq=True)
    for t in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=120) as r:
                return 'OK', json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            b=e.read().decode()
            if e.code in (502,503): time.sleep(6); continue
            return 'ERR', b
        except Exception: time.sleep(4)
    return 'ERR','retries'

ATTR=['','last_','last_significant_','cross_device_last_significant_']
NAMES=['DirectOrderName','DirectOrderId','DirectCampaignName','DirectBannerName','DirectBannerId',
       'DirectPhrase','DirectCondition','DirectPlatform','DirectAdGroupName','DirectGoalName',
       'DirectTrafficType','DirectDeviceType']
print("=== ПОДБОР ИЗМЕРЕНИЙ ym:ad:* (с префиксами атрибуции) ===")
ok=[]
for base in NAMES:
    for a in ATTR:
        d=f'ym:ad:{a}{base}'
        st,r=q({'ids':CID,'metrics':'ym:ad:visits','dimensions':d,'date1':'30daysAgo','date2':'today','limit':3})
        if st=='OK':
            vals=[x['dimensions'][0]['name'][:40] for x in (r.get('data') or [])]
            print(f"  ✅ {d:62} {vals}")
            ok.append(d)
        time.sleep(0.4)
print(f"\nвалидных измерений: {len(ok)}")
json.dump(ok, open(os.path.join(OUT,'metrika_ad_dims_ok.json'),'w'), ensure_ascii=False, indent=1)

print("\n=== ПОДБОР МЕТРИК ym:ad:* ===")
okm=[]
for m in ['ym:ad:visits','ym:ad:clicks','ym:ad:RUBConvertedAdCost','ym:ad:ecommercePurchases',
          'ym:ad:ecommerceRUBConvertedRevenue','ym:ad:goal36895733reaches','ym:ad:goalreaches',
          'ym:ad:goalDimension','ym:ad:bounceRate','ym:ad:pageviews','ym:ad:users',
          'ym:ad:RUBConvertedAdCostNDS','ym:ad:avgVisitDurationSeconds','ym:ad:ecommerceAddToCart',
          'ym:ad:goal168348169reaches','ym:ad:goal197752867reaches','ym:ad:goal168348397reaches']:
    st,r=q({'ids':CID,'metrics':m,'date1':'90daysAgo','date2':'today'})
    if st=='OK':
        v=(r.get('data') or [{}])[0].get('metrics')
        print(f"  ✅ {m:44} {v}"); okm.append(m)
    else:
        print(f"  ❌ {m:44} {str(r)[:78]}")
    time.sleep(0.4)
json.dump(okm, open(os.path.join(OUT,'metrika_ad_metrics_ok.json'),'w'), ensure_ascii=False, indent=1)
