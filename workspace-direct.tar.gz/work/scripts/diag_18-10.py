# -*- coding: utf-8 -*-
"""Диагностика 18.10: почему не идут показы после загрузки через Коммандер + пополнения счёта.
Читаем: кампании (статус/состояние/уточнения), объявления, группы, ключи, счёт.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError

c = client()
TODAY = '2026-10-18'

# Поля, доступные в спецрежиме (Strategy/TextCampaign/WeeklyBudget/StateClarification недоступны)
CAMP_FIELDS_BASE = ['Id', 'Name', 'Status', 'State', 'StatusClarification',
                    'Funds', 'ClientInfo', 'StartDate', 'EndDate',
                    'NegativeKeywords', 'TimeTargeting', 'Currency',
                    'Notification', 'Representative', 'DailyBudget']
CAMP_FIELDS_REDUCED = ['Id', 'Name', 'Status', 'State', 'StatusClarification',
                       'ClientInfo', 'StartDate', 'EndDate', 'Currency']

def camp_get(fields):
    try:
        r = c.call('campaigns', 'get', {
            'SelectionCriteria': {},
            'FieldNames': fields})
        return r.get('Campaigns', []), None
    except DirectError as e:
        return None, str(e)

print("=" * 70)
print("1. КАМПАНИИ — СТАТУСЫ")
print("=" * 70)
camps, err = camp_get(CAMP_FIELDS_BASE)
if err:
    print(f"  базовые поля не отдались: {err[:200]}")
    print("  пробую сокращённый набор…")
    camps, err = camp_get(CAMP_FIELDS_REDUCED)
    if err:
        print(f"  сокращённые тоже не отдались: {err[:300]}")
        camps = []

if camps:
    # Ключевые кампании
    focus = {40732207: 'ПОИСК (основная)', 704504054: 'ПОИСК-ФИД',
             704507321: 'РСЯ', 76065880: 'Мастер кампаний'}
    for camp in camps:
        cid = camp.get('Id')
        if cid in focus:
            print(f"\n  --- {focus[cid]} (ID {cid}) ---")
            for k in ['Name', 'Status', 'State', 'StatusClarification',
                      'StartDate', 'EndDate', 'Currency']:
                if k in camp:
                    print(f"      {k}: {json.dumps(camp[k], ensure_ascii=False)[:220]}")
            f = camp.get('Funds')
            if f:
                print(f"      Funds: {json.dumps(f, ensure_ascii=False)[:300]}")
    # Сколько всего кампаний в каждом статусе
    from collections import Counter
    st = Counter((x.get('Status'), x.get('State')) for x in camps)
    print(f"\n  Всего кампаний: {len(camps)}")
    for (s1, s2), n in st.most_common(12):
        print(f"      Status={s1} State={s2}: {n}")

print()
print("=" * 70)
print("2. СЧЁТ (campaigns.get Funds уже выше; пробуем отдельный запрос)")
print("=" * 70)
try:
    r = c.call('campaigns', 'get', {
        'SelectionCriteria': {'Ids': [40732207]},
        'FieldNames': ['Id', 'Funds']})
    print(" ", json.dumps(r, ensure_ascii=False)[:500])
except DirectError as e:
    print("  Funds ERR:", str(e)[:250])

# Пробуем clients.get (иногда показывает баланс)
try:
    r = c.call('clients', 'get', {'SelectionCriteria': {},
                                  'FieldNames': ['Id', 'Balance', 'AccountQuality',
                                                 'Funds', 'ClientInfo']})
    print("  clients.get:", json.dumps(r, ensure_ascii=False)[:600])
except DirectError as e:
    print("  clients.get ERR:", str(e)[:250])

print()
print("=" * 70)
print("3. ОБЪЯВЛЕНИЯ ПОИСКОВОЙ КАМПАНИИ 40732207 — СТАТУСЫ МОДЕРАЦИИ")
print("=" * 70)
AD_FIELDS = ['Id', 'AdGroupId', 'CampaignId', 'State', 'Status',
             'StatusClarification', 'Type', 'Subtype']
try:
    r = c.call('ads', 'get', {
        'SelectionCriteria': {'CampaignIds': [40732207]},
        'FieldNames': AD_FIELDS})
    ads = r.get('Ads', [])
    print(f"  объявлений: {len(ads)}")
    from collections import Counter
    st = Counter((a.get('State'), a.get('Status'), a.get('StatusClarification')) for a in ads)
    for k, n in st.most_common():
        print(f"      State={k[0]} Status={k[1]} Clar={k[2]}: {n}")
    # Показать примеры отклонённых/премодерации
    for a in ads:
        if a.get('Status') in ('REJECTED', 'PREMODERATION') or a.get('State') == 'OFF':
            print(f"      ⚠ Ad {a['Id']}: State={a.get('State')} Status={a.get('Status')} Clar={a.get('StatusClarification')}")
except DirectError as e:
    print("  ads.get ERR:", str(e)[:300])

print()
print("=" * 70)
print("4. ГРУППЫ И КЛЮЧИ ПОИСКОВОЙ КАМПАНИИ — СОСТОЯНИЯ")
print("=" * 70)
try:
    r = c.call('adgroups', 'get', {
        'SelectionCriteria': {'CampaignIds': [40732207]},
        'FieldNames': ['Id', 'Name', 'Status', 'NegativeKeywords', 'RegionIds']})
    groups = r.get('AdGroups', [])
    print(f"  групп: {len(groups)}")
    from collections import Counter
    st = Counter(g.get('Status') for g in groups)
    for k, n in st.most_common():
        print(f"      Status={k}: {n}")
except DirectError as e:
    print("  adgroups.get ERR:", str(e)[:300])

try:
    r = c.call('keywords', 'get', {
        'SelectionCriteria': {'CampaignIds': [40732207]},
        'FieldNames': ['Id', 'CampaignId', 'AdGroupId', 'Keyword', 'State', 'Status',
                       'StatusClarification', 'Bid', 'ServingAvailable']})
    kws = r.get('Keywords', [])
    print(f"  ключей: {len(kws)}")
    from collections import Counter
    st = Counter((k.get('State'), k.get('Status'), k.get('ServingAvailable')) for k in kws)
    for key, n in st.most_common(15):
        print(f"      State={key[0]} Status={key[1]} ServingAvailable={key[2]}: {n}")
    # Примеры ключей со ServingAvailable=False или непонятными статусами
    odd = [k for k in kws if k.get('ServingAvailable') is False
           or k.get('Status') not in ('ACCEPTED', 'REJECTED', 'MODERATION', None)]
    for k in odd[:10]:
        print(f"      ⚠ KW {k['Id']} '{k.get('Keyword')}' State={k.get('State')} Status={k.get('Status')} Clar={k.get('StatusClarification')}")
except DirectError as e:
    print("  keywords.get ERR:", str(e)[:300])

print()
print("=" * 70)
print("5. ПРОВЕРКА: СНЯТ ЛИ СПЕЦРЕЖИМ (попытка безвредной записи)")
print("=" * 70)
try:
    r = c.call('campaigns', 'suspend', {'SelectionCriteria': {'Ids': [704507321]}})
    print("  campaigns.suspend (РСЯ уже SUSPENDED, no-op):", json.dumps(r, ensure_ascii=False)[:200])
except DirectError as e:
    print("  campaigns.suspend ERR:", str(e)[:200])
# Пробуем заведомо пустой update — если спецрежим, будет 54; если снят — другая ошибка (валидация)
try:
    r = c.call('campaigns', 'update', {'Campaigns': [{'Id': 40732207, 'Name': None}]})
    print("  campaigns.update (тест):", json.dumps(r, ensure_ascii=False)[:200])
except DirectError as e:
    print("  campaigns.update (тест):", str(e)[:250])

print()
print("=" * 70)
print("6. СТАТИСТИКА ЗА 17-18.10 (есть ли показы/клики вообще)")
print("=" * 70)
import csv, io, datetime
def rep(campaign_ids, fields, d_from, d_to):
    rd = {'SelectionCriteria': {'CampaignIds': campaign_ids, 'Filter': [],
                                'DateFrom': d_from, 'DateTo': d_to},
          'FieldNames': fields, 'ReportName': 'diag',
          'ReportType': 'CAMPAIGN_PERFORMANCE_REPORT',
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    try:
        tsv = c.report(rd, skip_report_header=True, skip_column_header=False,
                       skip_report_summary=True)
        return list(csv.DictReader(io.StringIO(tsv), delimiter='\t')), None
    except DirectError as e:
        return None, str(e)

rows, err = rep([40732207, 704504054, 704507321],
                ['Date', 'CampaignId', 'Impressions', 'Clicks', 'Cost'],
                '2026-10-15', TODAY)
if err:
    print("  report ERR:", err[:250])
else:
    print(f"  строк отчёта: {len(rows)}")
    for r_ in rows:
        print("     ", r_)
