# -*- coding: utf-8 -*-
"""Проверка прав на запись + выполнение отключения пионов."""
import json, os, sys, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
PEONY_KEYS=[58168684647, 58168684648, 205806400169]
PEONY_AD=1922758453206718169
PEONY_GROUP=5806400169
log=[]

def try_(label, svc, method, params, rollback=None):
    print(f"\n● {label}  ({svc}.{method})")
    try:
        res=c.call(svc, method, params)
        s=json.dumps(res, ensure_ascii=False)
        print("   ✅ OK:", s[:400])
        log.append({'label':label,'svc':svc,'method':method,'ok':True,'res':res,
                    'rollback':rollback,'ts':datetime.datetime.now().isoformat()})
        return True
    except DirectError as e:
        print("   ❌", str(e)[:300])
        log.append({'label':label,'svc':svc,'method':method,'ok':False,'err':str(e)[:400],
                    'ts':datetime.datetime.now().isoformat()})
        return False

# 1. ключи пионов
try_('Пауза ключей пионов + автотаргетинга','keywords','suspend',
     {'SelectionCriteria':{'Ids':PEONY_KEYS}},
     {'svc':'keywords','method':'resume','params':{'SelectionCriteria':{'Ids':PEONY_KEYS}}})
# 2. объявление пионов
try_('Пауза объявления М2.4 (пионы)','ads','suspend',
     {'SelectionCriteria':{'Ids':[PEONY_AD]}},
     {'svc':'ads','method':'resume','params':{'SelectionCriteria':{'Ids':[PEONY_AD]}}})
# 3. группа пионов
try_('Пауза группы М2.4','adgroups','suspend',
     {'SelectionCriteria':{'Ids':[PEONY_GROUP]}},
     {'svc':'adgroups','method':'resume','params':{'SelectionCriteria':{'Ids':[PEONY_GROUP]}}})
# 4. переименование
r=c.call('adgroups','get',{'SelectionCriteria':{'Ids':[PEONY_GROUP]},'FieldNames':['Id','Name']})
old=(r.get('AdGroups') or [{}])[0].get('Name')
print("\n   старое имя группы:", old)
try_('Переименование группы М2.4','adgroups','update',
     {'AdGroups':[{'Id':PEONY_GROUP,'Name':"М2.4 Пионы и гортензии [СТОП — сезон 2026]"}]},
     {'svc':'adgroups','method':'update','params':{'AdGroups':[{'Id':PEONY_GROUP,'Name':old}]} if old else None})
# 5. sitelinks.add — проверка права
try_('Создание нового набора быстрых ссылок (тест прав)','sitelinks','add',
     {'SitelinksSets':[{'Sitelinks':[
        {'Title':'Каталог букетов','Href':'https://flowerpoetry.ru/buketi-cvetov','Description':'Красивые букеты на любой случай, от 2000 руб.'},
        {'Title':'Доставка цветов','Href':'https://flowerpoetry.ru/informaciya-o-dostavke','Description':'Быстрая доставка за 2 часа по Раменскому и району.'},
        {'Title':'Галерея работ','Href':'https://flowerpoetry.ru/gallery','Description':'Авторские букеты и композиции наших флористов.'},
        {'Title':'Композиции в коробках','Href':'https://flowerpoetry.ru/buketi-cvetov/kompozicii/buketi-v-korobkah','Description':'Элегантные композиции в стильных коробках.'}]}]})

json.dump(log, open(os.path.join(OUT,'write_test_log.json'),'w'), ensure_ascii=False, indent=1)
print("\n=== ИТОГ ПРАВ ===")
for e in log: print(f"  {'✅' if e['ok'] else '❌'} {e['label']}")
