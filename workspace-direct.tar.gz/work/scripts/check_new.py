# -*- coding: utf-8 -*-
import json, os, sys, re, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import OUT
SK=os.path.join(os.environ.get('ARENA_WORKSPACE','"$ARENA_WORKSPACE"'),
  'extract/workspace/skills_repo/extracted1/skill_for_claude_code_yandex_direct-main/scripts')
sys.path.insert(0,SK)
from ads import validate_ad, LIMITS
kw=json.load(open(os.path.join(OUT,'live_keywords.json')))['Keywords']
ags=json.load(open(os.path.join(OUT,'live_adgroups.json')))['AdGroups']
gn={g['Id']:g['Name'] for g in ags}; gs={g['Id']:g.get('Status') for g in ags}
allkw=[k for k in kw if k['CampaignId']==40732207]
def pos(ph): return [t.lstrip('+!').lower() for t in str(ph).split() if not t.startswith('-')]

print("=== КОНФЛИКТ-ЧЕК новых минус-слов со ВСЕМИ ключами кампании ===")
for w in ['сухоцветы','сухоцвет','лилии','лилия','лилий','гладиолус','гладиолусы','ромашк','ранункулюс','орхиде','альстромер']:
    hits=[(k['Keyword'],gn.get(k['AdGroupId']),k.get('State'),gs.get(k['AdGroupId'])) for k in allkw
          if any(w in x for x in pos(k['Keyword']))]
    print(f"  -{w:14} задевает ключей: {len(hits)}")
    for h in hits[:5]: print(f"      {h[0][:52]!r:54} [{h[1]}] state={h[2]} группа={h[3]}")

print("\n=== ВАЛИДАЦИЯ ТЕКСТОВ (гейт скилла ads.py) ===")
ADS=[
 ("М2. По видам — остаток (без лилий)", dict(
   title="Букеты орхидей и альстромерий", title2="Экзотика. Доставка за 2 часа",
   text="Редкие цветы в наличии и под заказ. Доставка за 2 часа. От 2500 руб.",
   display_path="Орхидеи-альстромерии")),
 ("М2.4 Гортензии (правка цены)", dict(
   title="Букеты с гортензией в Раменском", title2="Доставка 2 часа. От 2000 руб",
   text="Объёмные букеты с гортензией: один цветок заменяет охапку. Доставка за 2 часа!",
   display_path="Гортензии")),
 ("М2.7 Ромашки", dict(
   title="Букеты с ромашками в Раменском", title2="Доставка 2 часа. От 2600 руб",
   text="Нежные букеты с ромашками. Соберём за 2 часа. Доставка по Раменскому. Открытка в дар!",
   display_path="Ромашки")),
 ("М2.8 Ранункулюсы", dict(
   title="Букеты с ранункулюсами — Раменское", title2="Премиум-цветы. От 4250 руб",
   text="Ранункулюсы в наличии и под заказ. Сборка за 2 часа. Доставка по Раменскому и району!",
   display_path="Ранункулюсы")),
 ("М2.9 Орхидеи", dict(
   title="Букеты с орхидеей в Раменском", title2="Доставка 2 часа. От 2500 руб",
   text="Экзотические букеты с орхидеей. Соберём за 2 часа. Доставка по Раменскому. Открытка в дар!",
   display_path="Орхидеи")),
 ("М2.10 Альстромерии", dict(
   title="Букеты с альстромерией — Раменское", title2="Стойкие цветы. От 2500 руб",
   text="Альстромерии стоят до 3 недель. Соберём букет за 2 часа. Доставка по Раменскому!",
   display_path="Альстромерии")),
]
for name,ad in ADS:
    errs=validate_ad(ad,0)
    print(f"\n● {name}")
    print(f"   T1 ({len(ad['title'])}/56): {ad['title']}")
    print(f"   T2 ({len(ad['title2'])}/30): {ad['title2']}")
    print(f"   TX ({len(ad['text'])}/81): {ad['text']}")
    print(f"   DP ({len(ad['display_path'])}/20): {ad['display_path']}")
    print("   " + ("✅ VALID" if not errs else "❌ "+"; ".join(errs)))
