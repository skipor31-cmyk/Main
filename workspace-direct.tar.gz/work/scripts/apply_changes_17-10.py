# -*- coding: utf-8 -*-
"""
Изменения в аккаунте Директа flowerpoetry.ru (skipor31), подготовлены 17.10.2026.

ЗАДАЧИ (поручение владельца):
  1. Заменить URL в объявлениях после переезда сайта 12.10.2026 (редиректные цепочки -> прямые 200).
  2. Исправить URL в наборе быстрых ссылок 1384724168.
  3. Отключить пионы (сезон закончился): ключи + автотаргетинг + объявление группы М2.4.
     Гортензии остаются в работе: создаётся отдельное объявление на /po_cvetam/bukety-s-gortenziej/.
  3b. (--title2) Заполнить пустой Заголовок 2 у 48 объявлений — YD38 FAIL.
  4. Убрать минус-слова кампании, которые убивают собственные живые ключи (--fix-negatives).

ВАЖНО: с 08.10.2026 Яндекс Директ работает в «специальном режиме» — редактирование
кампаний/объявлений/библиотек через API запрещено (ошибка 54 «Нет прав»).
Разрешены только: чтение, запуск/остановка КАМПАНИЙ, финансы, недельный бюджет.
Скрипт сам проверяет права и не делает ничего, пока запись не разрешена.

    python3 apply_changes_17-10.py             # DRY-RUN + проверка прав
    python3 apply_changes_17-10.py --apply     # применить
    python3 apply_changes_17-10.py --rollback  # откатить
    python3 apply_changes_17-10.py --apply --fix-negatives   # + чистка 7 конфликтных минус-слов
    python3 apply_changes_17-10.py --apply --title2          # + заполнить Заголовок 2 (YD38)

    Всё вместе:
    python3 apply_changes_17-10.py --apply --fix-negatives --title2
"""
import json, os, sys, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError

STATE   = os.path.join(OUT, 'apply_state_17-10.json')
B       = 'https://flowerpoetry.ru'
UTM     = ('?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}'
           '&utm_content={ad_id}&utm_term={keyword}')
CAMPAIGN     = 40732207
SITELINK_SET = 1384724168
PEONY_GROUP  = 5806400169
PEONY_AD     = 1922758453206718169
PEONY_KEYS   = [58168684647, 58168684648, 205806400169]   # 'букет пионов', 'купить пионы раменское', autotargeting
HYDRANGEA_KEY= 58168684649                                  # 'букеты цветов гортензия' — НЕ трогаем
PEONY_NEWNAME= "М2.4 Гортензии (пионы — СТОП до сезона)"

# --- гортензии остаются в работе: отдельное объявление (валидировано ads.py validate_ad) ---
HYDRANGEA_AD = {
    'Title': 'Букеты с гортензией в Раменском',                      # 31/56
    'Title2': 'Доставка 2 часа. От 2660 руб',                        # 28/30
    'Text': 'Объёмные букеты с гортензией: один цветок заменяет охапку. Доставка за 2 часа!',  # 78/81
    'DisplayUrlPath': 'Гортензии',                                   # 9/20
}
HYDRANGEA_PATH = '/po_cvetam/bukety-s-gortenziej/'
BUSINESS_ID    = 103128457869
TRACKPHONE_ID  = 6247510023894529225
CALLOUTS = [36689089, 36689093, 36689312, 36689333, 36689334, 36689336,
            36689428, 36689429, 36689431, 7103330, 7103334, 9309894]

# --- Заголовок 2 (сейчас пуст у 49/49 объявлений, YD38 FAIL) ---
TITLE2_BY_PREFIX = [
    ('Д4',  'Доставим в любой посёлок'),
    ('Д1',  'Привезём за 2 часа. От 2000 ₽'),
    ('Д2',  'Привезём за 2 часа. От 2000 ₽'),
    ('Д3',  'Доставим в любой посёлок'),
    ('Д5',  'Привезём за 2 часа. От 2000 ₽'),
    ('К1',  'Оплата картой. Открытка в дар'),
    ('К2',  'Оплата картой. Открытка в дар'),
    ('М1',  '150+ букетов в наличии'),
    ('М2',  'Соберём под ваш бюджет'),
    ('М3',  'Открытка в подарок'),
    ('М4',  'Композиции со сладостями'),
    ('Б1',  'Свои флористы. Доставка 2 ч'),
]

# --- 1. объявления: id -> новый путь (со слэшем: с UTM отдаёт 200 без редиректа) ---
AD_HREF = {
    1922742228964443637: '/buketi-cvetov/',                            # К1. Заказ +с доставкой
    1922742228964443639: '/buketi-cvetov/',                            # К1.2 Заказать +с доставкой
    1922742228964443644: '/buketi-cvetov/',                            # К1.3 Купить-заказать (188 фраз)
    1922742232187391646: '/buketi-cvetov/',                            # К2. Купить-заказать (общие)
    1922742232187391648: '/buketi-cvetov/',                            # М2. По видам — остаток
    1922742232187391649: '/buketi-cvetov/',                            # М3. По поводам — остаток
    1922742228964443642: '/informaciya-o-dostavke/',                   # Д4. Область
    1922742232187391644: '/informaciya-o-dostavke/',                   # Д3. Доставка — район и деревни
    1922749843942587805: '/buketi-cvetov/kompozicii/buketi-v-korobkah/',  # М4. Композиции в коробках
}

# --- 2. быстрые ссылки (без query -> БЕЗ слэша, иначе 301) ---
NEW_SITELINKS = [
    {'Title': 'Каталог букетов',       'Href': B + '/buketi-cvetov',
     'Description': 'Красивые букеты на любой случай, от 2000 руб.'},
    {'Title': 'Доставка цветов',       'Href': B + '/informaciya-o-dostavke',
     'Description': 'Быстрая доставка за 2 часа по Раменскому и району.'},
    {'Title': 'Галерея работ',         'Href': B + '/gallery',
     'Description': 'Авторские букеты и композиции наших флористов.'},
    {'Title': 'Композиции в коробках', 'Href': B + '/buketi-cvetov/kompozicii/buketi-v-korobkah',
     'Description': 'Элегантные композиции в стильных коробках.'},
]

# --- 3. минус-слова кампании, убивающие собственные живые ключи ---
BAD_NEGATIVES = ['онлайн', '101', 'срочно', 'подмосковье', 'сайт']   # 5 реальных конфликтов; 'цены'/'расчет' живых фраз не задевают


def st_load():
    if os.path.exists(STATE):
        return json.load(open(STATE, encoding='utf-8'))
    return {'created': datetime.datetime.now().isoformat(), 'applied': []}


def st_save(s):
    json.dump(s, open(STATE, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


def rights_ok(c):
    """Проверка: разрешена ли запись. Пробуем no-op на уже приостановленной кампании."""
    try:
        c.call('keywords', 'suspend', {'SelectionCriteria': {'Ids': [PEONY_KEYS[0]]}})
        return True, 'запись разрешена'
    except DirectError as e:
        m = str(e)
        if 'code 54' in m or 'Нет прав' in m:
            return False, ('ОШИБКА 54 «Нет прав» — Яндекс Директ в специальном режиме '
                           '(редактирование через API запрещено). Изменения невозможны до его снятия.')
        return True, 'запись разрешена (ключ уже приостановлен или иной ответ)'


def plan(c, fix_neg, fill_t2=False):
    P = []
    ads = c.call('ads', 'get', {'SelectionCriteria': {'Ids': list(AD_HREF)},
        'FieldNames': ['Id', 'Status', 'State'],
        'TextAdFieldNames': ['Title', 'Title2', 'Text', 'Href', 'SitelinkSetId',
                             'BusinessId', 'TrackingPhoneId', 'DisplayUrlPath']})
    got = {a['Id']: a for a in ads.get('Ads', [])}
    upd, rb = [], []
    for aid, path in AD_HREF.items():
        a = got.get(aid)
        if not a:
            print(f"  !! объявление {aid} не найдено"); continue
        ta = a['TextAd']
        new = B + path + UTM
        if ta.get('Href') == new:
            print(f"  = {aid}: уже исправлен"); continue
        p = {'Id': aid, 'TextAd': {'Title': ta['Title'], 'Text': ta['Text'], 'Href': new}}
        if ta.get('Title2'):           p['TextAd']['Title2'] = ta['Title2']
        if ta.get('SitelinkSetId'):    p['TextAd']['SitelinkSetId'] = ta['SitelinkSetId']
        if ta.get('DisplayUrlPath'):   p['TextAd']['DisplayUrlPath'] = ta['DisplayUrlPath']
        if ta.get('BusinessId'):       p['TextAd']['BusinessId'] = ta['BusinessId']
        if ta.get('TrackingPhoneId'):  p['TextAd']['TrackingPhoneId'] = ta['TrackingPhoneId']
        upd.append(p)
        rb.append({'Id': aid, 'TextAd': {k: v for k, v in ta.items()
                   if k in ('Title', 'Title2', 'Text', 'Href', 'SitelinkSetId',
                            'DisplayUrlPath', 'BusinessId', 'TrackingPhoneId') and v}})
    if upd:
        P.append({'id': 'A1_ad_hrefs', 'desc': f'{len(upd)} объявлений: Href -> прямой URL (200 без редиректа)',
                  'svc': 'ads', 'method': 'update', 'params': {'Ads': upd},
                  'rollback': {'svc': 'ads', 'method': 'update', 'params': {'Ads': rb}},
                  'detail': [(u['Id'], u['TextAd']['Href'].split('?')[0]) for u in upd]})
        P.append({'id': 'A2_moderate', 'desc': f'Модерация {len(upd)} объявлений',
                  'svc': 'ads', 'method': 'moderate',
                  'params': {'SelectionCriteria': {'Ids': [u['Id'] for u in upd]}}, 'rollback': None})

    # --- быстрые ссылки: update не существует -> создаём новый набор ---
    P.append({'id': 'S1_sitelinks_add', 'desc': 'Создать новый набор быстрых ссылок (прямые URL)',
              'svc': 'sitelinks', 'method': 'add',
              'params': {'SitelinksSets': [{'Sitelinks': NEW_SITELINKS}]},
              'rollback': None, 'creates': True,
              'detail': [(s['Title'], s['Href'].replace(B, '')) for s in NEW_SITELINKS]})

    # --- гортензии: новое объявление в группу М2.4 (пионы при этом на паузе) ---
    hy = dict(HYDRANGEA_AD)
    hy['Href'] = B + HYDRANGEA_PATH + UTM
    payload = {'AdGroupId': PEONY_GROUP, 'TextAd': {
        'Title': hy['Title'], 'Title2': hy['Title2'], 'Text': hy['Text'], 'Href': hy['Href'],
        'Mobile': 'NO', 'SitelinkSetId': SITELINK_SET, 'AdExtensionIds': CALLOUTS,
        'BusinessId': BUSINESS_ID, 'TrackingPhoneId': TRACKPHONE_ID,
        'DisplayUrlPath': hy['DisplayUrlPath']}}
    P.append({'id': 'H1_hydrangea_ad',
              'desc': 'Гортензии: создать объявление в М2.4 (пионы остаются на паузе)',
              'svc': 'ads', 'method': 'add', 'params': {'Ads': [payload]},
              'rollback': None, 'creates': True,
              'detail': [(hy['Title'], hy['Title2'], hy['Text'][:50] + '…', HYDRANGEA_PATH)]})
    P.append({'id': 'H2_hydrangea_moderate', 'desc': 'Модерация нового объявления (гортензии)',
              'svc': 'ads', 'method': 'moderate', 'params': {'SelectionCriteria': {'Ids': []}},
              'rollback': None, 'needs_created_from': 'H1_hydrangea_ad'})

    # --- Заголовок 2 (опционально) ---
    if fill_t2:
        act = c.call('ads', 'get', {'SelectionCriteria': {'AdGroupIds': [g['Id'] for g in
                     c.call('adgroups', 'get', {'SelectionCriteria': {'CampaignIds': [CAMPAIGN]},
                      'FieldNames': ['Id']}).get('AdGroups', [])]},
            'FieldNames': ['Id', 'AdGroupId', 'State', 'Status'],
            'TextAdFieldNames': ['Title', 'Text', 'Href', 'SitelinkSetId', 'BusinessId',
                                 'TrackingPhoneId', 'DisplayUrlPath', 'Title2']})
        gmap = {g['Id']: g['Name'] for g in c.call('adgroups', 'get',
                {'SelectionCriteria': {'CampaignIds': [CAMPAIGN]},
                 'FieldNames': ['Id', 'Name']}).get('AdGroups', [])}
        upd2, rb2, skipped = [], [], 0
        for a in act.get('Ads', []):
            if a.get('State') == 'ARCHIVED' or a['Id'] == PEONY_AD:
                continue   # объявление пионов уходит на паузу — T2 ему не нужен
            ta = a.get('TextAd') or {}
            if ta.get('Title2'):
                skipped += 1; continue
            gname = gmap.get(a['AdGroupId'], '')
            t2 = next((v for p_, v in TITLE2_BY_PREFIX if gname.startswith(p_)), None)
            if not t2:
                print(f"  ?? нет правила T2 для группы {gname!r}"); continue
            payload2 = {'Id': a['Id'], 'TextAd': {'Title': ta['Title'], 'Text': ta['Text'],
                        'Href': ta['Href'], 'Title2': t2}}
            for k_src, k_dst in (('SitelinkSetId', 'SitelinkSetId'), ('BusinessId', 'BusinessId'),
                                 ('TrackingPhoneId', 'TrackingPhoneId'),
                                 ('DisplayUrlPath', 'DisplayUrlPath')):
                if ta.get(k_src):
                    payload2['TextAd'][k_dst] = ta[k_src]
            upd2.append(payload2)
            rb2.append({'Id': a['Id'], 'TextAd': {'Title': ta['Title'], 'Text': ta['Text'],
                        'Href': ta['Href']}})
        if upd2:
            P.append({'id': 'T1_title2', 'desc': f'Заголовок 2: заполнить у {len(upd2)} объявлений '
                      f'(пропущено с уже заполненным: {skipped})',
                      'svc': 'ads', 'method': 'update', 'params': {'Ads': upd2},
                      'rollback': {'svc': 'ads', 'method': 'update', 'params': {'Ads': rb2}},
                      'detail': [(u['Id'], u['TextAd']['Title2']) for u in upd2]})
            P.append({'id': 'T2_moderate', 'desc': f'Модерация {len(upd2)} объявлений после T2',
                      'svc': 'ads', 'method': 'moderate',
                      'params': {'SelectionCriteria': {'Ids': [u['Id'] for u in upd2]}},
                      'rollback': None})

    # --- пионы ---
    P.append({'id': 'P1_peony_keys', 'desc': 'Пауза 2 ключей про пионы + автотаргетинга группы М2.4',
              'svc': 'keywords', 'method': 'suspend',
              'params': {'SelectionCriteria': {'Ids': PEONY_KEYS}},
              'rollback': {'svc': 'keywords', 'method': 'resume',
                           'params': {'SelectionCriteria': {'Ids': PEONY_KEYS}}}})
    P.append({'id': 'P2_peony_ad', 'desc': 'Пауза объявления М2.4 (в текстах — пионы, которых нет)',
              'svc': 'ads', 'method': 'suspend',
              'params': {'SelectionCriteria': {'Ids': [PEONY_AD]}},
              'rollback': {'svc': 'ads', 'method': 'resume',
                           'params': {'SelectionCriteria': {'Ids': [PEONY_AD]}}}})
    try:
        old = (c.call('adgroups', 'get', {'SelectionCriteria': {'Ids': [PEONY_GROUP]},
                 'FieldNames': ['Id', 'Name']}).get('AdGroups') or [{}])[0].get('Name')
    except DirectError:
        old = None
    P.append({'id': 'P3_rename', 'desc': 'Переименовать М2.4 (метка о сезоне)',
              'svc': 'adgroups', 'method': 'update',
              'params': {'AdGroups': [{'Id': PEONY_GROUP, 'Name': PEONY_NEWNAME}]},
              'rollback': {'svc': 'adgroups', 'method': 'update',
                           'params': {'AdGroups': [{'Id': PEONY_GROUP, 'Name': old}]}} if old else None})

    if fix_neg:
        c40 = c.call('campaigns', 'get', {'SelectionCriteria': {'Ids': [CAMPAIGN]},
                     'FieldNames': ['Id', 'NegativeKeywords']})
        items = ((c40.get('Campaigns') or [{}])[0].get('NegativeKeywords') or {}).get('Items') or []
        kept = [x for x in items if x.strip().lstrip('!+').strip().lower() not in BAD_NEGATIVES]
        removed = [x for x in items if x not in kept]
        P.append({'id': 'N1_negatives', 'desc': f'Убрать {len(removed)} конфликтных минус-слов кампании (5 шт.)',
                  'svc': 'campaigns', 'method': 'update',
                  'params': {'Campaigns': [{'Id': CAMPAIGN,
                            'NegativeKeywords': {'Items': kept}}]},
                  'rollback': {'svc': 'campaigns', 'method': 'update',
                               'params': {'Campaigns': [{'Id': CAMPAIGN,
                                         'NegativeKeywords': {'Items': items}}]}},
                  'detail': removed})
    return P


def main():
    mode = 'apply' if '--apply' in sys.argv else 'rollback' if '--rollback' in sys.argv else 'dry'
    fix_neg = '--fix-negatives' in sys.argv
    fill_t2 = '--title2' in sys.argv
    c = client()
    state = st_load()

    if mode == 'rollback':
        print('ОТКАТ...')
        for e in reversed(state.get('applied', [])):
            rb = e.get('rollback')
            if not rb:
                print(f"  [{e['id']}] авто-откат не предусмотрен"); continue
            try:
                c.call(rb['svc'], rb['method'], rb['params']); print(f"  [{e['id']}] откачено")
            except DirectError as ex:
                print(f"  [{e['id']}] ОШИБКА: {str(ex)[:200]}")
        state['rolled_back'] = datetime.datetime.now().isoformat(); st_save(state)
        return

    ok, why = rights_ok(c)
    print('ПРОВЕРКА ПРАВ НА ЗАПИСЬ:', '✅' if ok else '❌', why)

    P = plan(c, fix_neg, fill_t2)
    print('\n' + '=' * 78)
    print(f'ПЛАН ({len(P)} шагов) — режим: {mode.upper()}')
    print('=' * 78)
    for p in P:
        print(f"\n[{p['id']}] {p['desc']}   ({p['svc']}.{p['method']})")
        for d in (p.get('detail') or []):
            print('    ', d)
    json.dump([{k: v for k, v in p.items() if k != 'rollback'} for p in P],
              open(os.path.join(OUT, 'plan_17-10.json'), 'w'), ensure_ascii=False, indent=1)

    if mode == 'dry':
        print('\n--- DRY-RUN: ничего не изменено ---')
        if not ok:
            print('⛔ Запись сейчас запрещена Яндесом (специальный режим). '
                  'Запустите --apply, когда режим снимут.')
        return
    if not ok:
        print('\n⛔ ОСТАНОВЛЕНО: запись через API запрещена. План сохранён в work/analysis/plan_17-10.json')
        sys.exit(3)

    print('\nПРИМЕНЕНИЕ...')
    for p in P:
        print(f"\n[{p['id']}] {p['desc']}")
        src = p.get('needs_created_from')
        if src:
            new_ids = next((e.get('created_ids') or [] for e in reversed(state.get('applied', []))
                            if e['id'] == src), [])
            if not new_ids:
                print("   нет ID созданных объектов — пропускаю"); continue
            p = dict(p); p['params'] = {'SelectionCriteria': {'Ids': new_ids}}
        try:
            res = c.call(p['svc'], p['method'], p['params'])
        except DirectError as e:
            print('   ОШИБКА:', str(e)[:400]); st_save(state)
            print('   СТОП. Доступен --rollback.'); sys.exit(2)
        entry = {'id': p['id'], 'desc': p['desc'], 'rollback': p.get('rollback'),
                 'ts': datetime.datetime.now().isoformat(),
                 'response': json.loads(json.dumps(res, ensure_ascii=False))}
        if p.get('creates'):
            ids = [x.get('Id') for x in (res.get('AddResults') or [])]
            entry['created_ids'] = [i for i in ids if i]
            state['new_sitelink_set'] = entry['created_ids'][:1]
            print('   создан набор:', entry['created_ids'])
        ur = res.get('UpdateResults') or res.get('SuspendResults') or []
        nerr = sum(len(x.get('Errors') or []) for x in ur) if ur else 0
        print('   ok' if not nerr else f'   ошибок: {nerr}')
        for x in ur:
            for er in (x.get('Errors') or []): print('     ', x.get('Id'), er)
        state['applied'].append(entry); st_save(state)
    state['finished'] = datetime.datetime.now().isoformat(); st_save(state)
    print('\n✅ ГОТОВО. Откат: python3 apply_changes_17-10.py --rollback')


if __name__ == '__main__':
    main()
