# -*- coding: utf-8 -*-
"""
Создание 4 новых групп (М2.7–М2.10) + расширение М2.4 гортензиями.
Все ключи проверены через keywordsresearch.hasSearchVolume: спрос в Раменском = YES.
Все объявления прошли гейт ads.py validate_ad. Все посадочные отдают 200 напрямую с UTM.

    python3 create_new_groups.py            # DRY-RUN
    python3 create_new_groups.py --apply    # применить
    python3 create_new_groups.py --rollback # откатить
"""
import json, os, sys, time, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError, collect_add_results

STATE = os.path.join(OUT, 'apply_state_new_groups.json')
CAMPAIGN = 40732207
CITY, ZHUK = 10750, 20571
VILLAGES = [10718, 117802, 118482, 119749, 105573, 120351, 133110,
            161506, 161512, 161520, 161524, 161526, 161536, 161541, 161548]
ZONE17 = [CITY, ZHUK] + VILLAGES
# набор быстрых ссылок: берём новый (создан 21.10 apply_21-10.py), иначе старый
try:
    SITELINKS = json.load(open(os.path.join(OUT, 'apply_state_21-10.json'),
                    encoding='utf-8'))['new_sitelink_set']
except Exception:
    SITELINKS = 1384724168
BUSINESS, TRACKPHONE = 103128457869, 6247510023894529225
BRAND_NEG = {'Items': ['поэзия', 'flowerpoetry']}   # маршрутизация бренда в Б1
CALLOUTS = [36689089, 36689093, 36689312, 36689333, 36689334, 36689336,
            36689428, 36689429, 36689431, 7103330, 7103334, 9309894]
UTM = ('?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}'
       '&utm_content={ad_id}&utm_term={keyword}')
B = 'https://flowerpoetry.ru'
AT_CATEGORIES = [{"Category":"EXACT","Value":"YES"},{"Category":"ALTERNATIVE","Value":"NO"},
                 {"Category":"COMPETITOR","Value":"NO"},{"Category":"BROADER","Value":"NO"},
                 {"Category":"ACCESSORY","Value":"NO"}]
AT_BRANDS = [{"Option":"WITHOUT_BRANDS","Value":"YES"},{"Option":"WITH_ADVERTISER_BRAND","Value":"YES"}]
M24, M2_REST = 5806400169, 5806224427

COPY = json.load(open(os.path.join(OUT, 'ad_copy_final.json'), encoding='utf-8'))
C = {x['key']: x for x in COPY}
DEM = json.load(open(os.path.join(OUT, 'demand_new_groups.json'), encoding='utf-8'))
RA = DEM['Раменское']; ZH = DEM['Жуковский']

def demand(seeds, region=None):
    """Ключи со спросом YES в Раменском, относящиеся к данным корням."""
    reg = RA if region is None else region
    out = [k for k, v in reg.items() if v == 'YES' and any(s in k.lower() for s in seeds)]
    return sorted(out, key=len)

GROUPS = [
    ('М2.7 Ромашки',        C['M27_ROM'],  '/po_cvetam/buketi-s-romashkami/',
     demand(['ромашки', 'ромашек'])),
    ('М2.8 Ранункулюсы',    C['M28_RAN'],  '/po_cvetam/bukety-s-ranunkulyusami/',
     demand(['ранункулюсы', 'ранункулюсов', 'лютики'])),
    ('М2.9 Орхидеи',        C['M29_ORH'],  '/po_cvetam/bukety-s-orhideej/',
     demand(['орхидеи', 'орхидея', 'орхидей'])),
    ('М2.10 Альстромерии',  C['M210_ALS'], '/po_cvetam/bukety-s-alstromeriej/',
     demand(['альстромерия', 'альстромерии', 'альстромерий'])),
]
# расширение существующей М2.4 гортензиями (сейчас там 1 ключ, спрос есть по 28)
HYDR_NEW = [k for k in demand(['гортензия', 'гортензии']) if k != 'букеты цветов гортензия']


def st_load():
    if os.path.exists(STATE): return json.load(open(STATE, encoding='utf-8'))
    return {'created': datetime.datetime.now().isoformat(), 'applied': []}
def st_save(s): json.dump(s, open(STATE, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


def rights_ok(c):
    try:
        c.call('keywords', 'suspend', {'SelectionCriteria': {'Ids': [58168684647]}})
        return True
    except DirectError as e:
        return 'Нет прав' not in str(e) and 'code 54' not in str(e)


def main():
    mode = 'apply' if '--apply' in sys.argv else 'rollback' if '--rollback' in sys.argv else 'dry'
    c = client(); state = st_load()

    if mode == 'rollback':
        print('ОТКАТ...')
        for e in reversed(state.get('applied', [])):
            ids = e.get('created_ids') or []
            if not ids:
                rb = e.get('rollback')
                if rb:
                    try: c.call(rb['svc'], rb['method'], rb['params']); print(f"  [{e['id']}] откачено")
                    except DirectError as ex: print(f"  [{e['id']}] ERR {str(ex)[:150]}")
                continue
            svc = 'ads' if e['id'].startswith('N3') else 'keywords' if e['id'].startswith('N2') else 'adgroups'
            try:
                c.call(svc, 'suspend', {'SelectionCriteria': {'Ids': ids}})
                print(f"  [{e['id']}] приостановлено {len(ids)} объектов")
            except DirectError as ex: print(f"  [{e['id']}] ERR {str(ex)[:150]}")
        state['rolled_back'] = datetime.datetime.now().isoformat(); st_save(state)
        return

    print('ПРОВЕРКА ПРАВ НА ЗАПИСЬ:', '✅ разрешена' if rights_ok(c) else '⛔ ошибка 54 (спецрежим Яндекса)')
    print('\n' + '=' * 96)
    print('ПЛАН СОЗДАНИЯ ГРУПП')
    print('=' * 96)
    for name, cp, path, keys in GROUPS:
        print(f"\n● {name}  →  {path}")
        print(f"   ключей (спрос в Раменском = YES): {len(keys)}")
        print(f"   T1 ({len(cp['title'])}/56): {cp['title']}")
        print(f"   T2 ({len(cp['title2'])}/30): {cp['title2']}")
        print(f"   TX ({len(cp['text'])}/81): {cp['text']}")
        print(f"   DP ({len(cp['display_path'])}/20): {cp['display_path']}")
        print(f"   ключи: {', '.join(keys[:8])}{' …' if len(keys) > 8 else ''}")
    print(f"\n● Расширение существующей М2.4 Гортензии: +{len(HYDR_NEW)} ключей (сейчас 1)")
    print(f"   {', '.join(HYDR_NEW[:10])} …")
    print(f"\n● Дедупликация: приостановить 2 ключа в «М2. По видам — остаток» "
          f"(«купить букет орхидей», «купить цветы альстромерия») — уходят в свои группы")
    print(f"\nИТОГО: {len(GROUPS)} новые группы, {sum(len(g[3]) for g in GROUPS)} новых ключей, "
          f"{len(GROUPS)} объявлений, +{len(HYDR_NEW)} ключей в М2.4")

    if mode == 'dry':
        json.dump({'groups': [{'name': g[0], 'path': g[2], 'keys': g[3],
                               'copy': {k: g[1][k] for k in ('title','title2','text','display_path')}}
                              for g in GROUPS], 'hydrangea_add': HYDR_NEW},
                  open(os.path.join(OUT, 'plan_new_groups.json'), 'w'), ensure_ascii=False, indent=1)
        print('\n--- DRY-RUN: ничего не создано. План: work/analysis/plan_new_groups.json ---')
        if not rights_ok(c):
            print('⛔ Запись сейчас запрещена Яндесом (специальный режим).')
        return

    if not rights_ok(c):
        print('\n⛔ ОСТАНОВЛЕНО: запись через API запрещена (ошибка 54).'); sys.exit(3)

    print('\nПРИМЕНЕНИЕ...')
    def step(sid, desc, svc, method, params, rollback=None, creates=None):
        print(f"\n[{sid}] {desc}")
        try: res = c.call(svc, method, params)
        except DirectError as e:
            print('   ОШИБКА:', str(e)[:300]); st_save(state)
            print('   СТОП. Доступен --rollback.'); sys.exit(2)
        entry = {'id': sid, 'desc': desc, 'rollback': rollback,
                 'ts': datetime.datetime.now().isoformat()}
        if creates:
            ids, errs, warns = collect_add_results(res, 'add')
            got = [x for x in ids if x is not None]
            entry['created_ids'] = got
            print(f"   создано {len(got)}" + (f" | ОШИБКИ: {errs[:3]}" if errs else ""))
        else:
            ur = res.get('UpdateResults') or res.get('SuspendResults') or []
            ne = sum(len(x.get('Errors') or []) for x in ur) if ur else 0
            print('   ok' + (f' | ошибок {ne}' if ne else ''))
        state['applied'].append(entry); st_save(state)
        return res

    # N1 — группы
    step('N1_groups', f"Создать {len(GROUPS)} группы", 'adgroups', 'add',
         {'AdGroups': [{'CampaignId': CAMPAIGN, 'Name': g[0], 'RegionIds': ZONE17,
                       'NegativeKeywords': BRAND_NEG} for g in GROUPS]},
         creates=True)
    gids = state.get('applied', [])[-1].get('created_ids') or []
    if len(gids) != len(GROUPS):
        print('   созданы не все группы:', gids); st_save(state); sys.exit(2)
    gmap = dict(zip([g[0] for g in GROUPS], gids))
    state['gid_by_name'] = gmap; st_save(state)
    print('   ID:', json.dumps(gmap, ensure_ascii=False))

    # N2 — ключи
    items = []
    for name, cp, path, keys in GROUPS:
        for k in keys: items.append({'Keyword': k, 'AdGroupId': gmap[name]})
    step('N2_keys', f"{len(items)} ключей в новые группы", 'keywords', 'add', {'Keywords': items},
         creates=True)
    # автотаргетинг
    step('N2b_autotarget', f"{len(GROUPS)} автотаргетинг-ключей", 'keywords', 'add',
         {'Keywords': [{'Keyword': '---autotargeting', 'AdGroupId': gmap[g[0]],
                        'AutotargetingCategories': AT_CATEGORIES,
                        'AutotargetingBrandOptions': AT_BRANDS} for g in GROUPS]}, creates=True)

    # N3 — объявления
    ads = []
    for name, cp, path, keys in GROUPS:
        ads.append({'AdGroupId': gmap[name], 'TextAd': {
            'Title': cp['title'], 'Title2': cp['title2'], 'Text': cp['text'],
            'Href': B + path + UTM, 'Mobile': 'NO', 'SitelinkSetId': SITELINKS,
            'AdExtensionIds': CALLOUTS, 'BusinessId': BUSINESS, 'TrackingPhoneId': TRACKPHONE,
            'DisplayUrlPath': cp['display_path']}})
    step('N3_ads', f"{len(ads)} объявлений", 'ads', 'add', {'Ads': ads}, creates=True)
    new_ad_ids = state['applied'][-1].get('created_ids') or []
    if new_ad_ids:
        try: c.call('ads', 'moderate', {'SelectionCriteria': {'Ids': new_ad_ids}}); print('   → в модерацию')
        except DirectError as e: print('   moderate ERR', str(e)[:150])
        state['applied'].append({'id': 'N3b_moderate', 'rollback': None,
                                 'ts': datetime.datetime.now().isoformat()}); st_save(state)

    # N4 — расширение М2.4 гортензиями
    step('N4_hydrangea', f"+{len(HYDR_NEW)} ключей про гортензии в М2.4", 'keywords', 'add',
         {'Keywords': [{'Keyword': k, 'AdGroupId': M24} for k in HYDR_NEW]}, creates=True)

    # N5 — дедупликация старых ключей орхидей/альстромерий
    kw = c.call('keywords', 'get', {'SelectionCriteria': {'AdGroupIds': [M2_REST]},
        'FieldNames': ['Id', 'Keyword', 'State']})
    dup = [k['Id'] for k in kw.get('Keywords', [])
           if k.get('State') == 'ON' and k['Keyword'].strip().lower() in
           ('купить букет орхидей', 'купить цветы альстромерия')]
    if dup:
        step('N5_dedup', f"Пауза {len(dup)} дублей в М2-остатке", 'keywords', 'suspend',
             {'SelectionCriteria': {'Ids': dup}},
             rollback={'svc': 'keywords', 'method': 'resume',
                       'params': {'SelectionCriteria': {'Ids': dup}}})
    state['finished'] = datetime.datetime.now().isoformat(); st_save(state)
    print('\n✅ ГОТОВО. Откат: python3 create_new_groups.py --rollback')


if __name__ == '__main__':
    main()
