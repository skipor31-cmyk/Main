# -*- coding: utf-8 -*-
"""Метрика: счётчик, цели, визиты/конверсии по дням, по кампаниям Директа, по источникам."""
import json, os, sys, urllib.parse, urllib.request, urllib.error, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG, OUT
TOK=CFG['token']; CID=CFG['metrica']['counter_id']
BASE='https://api-metrika.yandex.net'
GOALS=[CFG['metrica']['primary_goal_id']]+list(CFG['metrica']['secondary_goal_ids'])

def get(path, params):
    url=BASE+path+'?'+urllib.parse.urlencode(params, doseq=True)
    req=urllib.request.Request(url, headers={'Authorization':f'OAuth {TOK}'})
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            return json.loads(r.read().decode()), None
    except urllib.error.HTTPError as e:
        return None, f"HTTP {e.code}: {e.read().decode()[:250]}"
    except Exception as e:
        return None, str(e)[:200]

def save(n,d):
    p=os.path.join(OUT,n); json.dump(d,open(p,'w'),ensure_ascii=False,indent=1)
    print(f"  saved {n:34} {os.path.getsize(p)/1024:6.1f} KB")

print("[0] счётчик и цели")
d,e=get(f'/management/v1/counter/{CID}',{}); print("  counter:", e or json.dumps(d.get('counter',{}).get('site') or d, ensure_ascii=False)[:200])
if d: save('m_counter.json', d)
d,e=get(f'/management/v1/counter/{CID}/goals',{})
if e: print("  goals ERR:", e)
else:
    save('m_goals.json', d)
    print(f"  целей: {len(d.get('goals',[]))}")
    for g in d.get('goals',[]):
        print(f"    {g.get('id'):>10} | {g.get('name')[:44]:46} | type={g.get('type')} | cond={json.dumps(g.get('conditions'),ensure_ascii=False)[:90]}")

print("\n[1] визиты/просмотры/отказы по дням (120 дней)")
d,e=get('/stat/v1/data', {'ids':CID,'metrics':'ym:s:visits,ym:s:pageviews,ym:s:bounceRate,ym:s:users',
  'dimensions':'ym:s:date','date1':'120daysAgo','date2':'today','sort':'ym:s:date','limit':200,'accuracy':'full'})
if e: print("  ERR:",e)
else:
    save('m_by_day.json', d)
    rows=d.get('data',[])
    print(f"  дней: {len(rows)}")
    print("   дата        визиты  просм.  отказы%  юзеры")
    for r in rows[-40:]:
        dt=r['dimensions'][0]['name']; m=r['metrics']
        print(f"   {dt}  {m[0]:7.0f} {m[1]:7.0f} {m[2]:7.1f} {m[3]:7.0f}")

print("\n[2] конверсии по целям за 90 дней")
for g in GOALS:
    d,e=get('/stat/v1/data', {'ids':CID,'metrics':f'ym:ad:goal{g}reaches,ym:ad:goal{g}users,ym:ad:goal{g}rate',
      'date1':'90daysAgo','date2':'today','accuracy':'full'})
    if e: print(f"  goal {g}: ERR {e[:120]}")
    else:
        m=(d.get('data') or [{}])[0].get('metrics',[0,0,0])
        print(f"  goal {g}: reaches={m[0]:.0f} users={m[1]:.0f} rate={m[2]:.2f}%")

print("\n[3] визиты+конверсии по дням (осн. цель %s, 60 дней)" % GOALS[0])
d,e=get('/stat/v1/data', {'ids':CID,'metrics':f'ym:s:visits,ym:ad:goal{GOALS[0]}reaches,ym:ad:goalreaches',
  'dimensions':'ym:s:date','date1':'60daysAgo','date2':'today','sort':'ym:s:date','limit':100,'accuracy':'full'})
if e: print("  ERR:",e)
else:
    save('m_goals_by_day.json', d)
    for r in d.get('data',[]):
        dt=r['dimensions'][0]['name']; m=r['metrics']
        print(f"   {dt}  visits={m[0]:6.0f}  goal{GOALS[0]}={m[1]:5.0f}  all_goals={m[2]:5.0f}")

print("\n[4] по кампаниям Директа (60 дней)")
d,e=get('/stat/v1/data', {'ids':CID,'metrics':'ym:s:visits,ym:ad:goalreaches',
  'dimensions':'ym:ad:directCampaignID,ym:ad:directCampaignName','date1':'60daysAgo','date2':'today','limit':500,'accuracy':'full'})
if e: print("  ERR:",e)
else:
    save('m_by_direct_campaign.json', d)
    for r in d.get('data',[]):
        dm=r['dimensions']; print(f"   {dm[0]['name'] if dm else '?':>12} {str(dm[1]['name'] if len(dm)>1 else '')[:44]:46} visits={r['metrics'][0]:7.0f} goals={r['metrics'][1]:5.0f}")

print("\n[5] источники (60 дней)")
d,e=get('/stat/v1/data', {'ids':CID,'metrics':'ym:s:visits,ym:ad:goalreaches','dimensions':'ym:s:source,ym:s:medium',
  'date1':'60daysAgo','date2':'today','sort':'-ym:s:visits','limit':40,'accuracy':'full'})
if e: print("  ERR:",e)
else:
    save('m_by_source.json', d)
    for r in d.get('data',[])[:25]:
        dm=r['dimensions']; print(f"   {dm[0]['name'][:28]:30}/{dm[1]['name'] if len(dm)>1 else '':14} visits={r['metrics'][0]:7.0f} goals={r['metrics'][1]:5.0f}")
print("\nDONE")
