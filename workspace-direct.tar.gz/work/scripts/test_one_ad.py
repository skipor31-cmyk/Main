# -*- coding: utf-8 -*-
"""Точечный тест: обновить Href ОДНОГО объявления и проверить, что остальные поля не слетели."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
AID=1922742232187391646   # К2. Купить-заказать (общие)
B='https://flowerpoetry.ru'
UTM='?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}&utm_content={ad_id}&utm_term={keyword}'
FIELDS=['Title','Title2','Text','Href','Mobile','SitelinkSetId','AdExtensions','BusinessId','TrackingPhoneId','DisplayUrlPath','DisplayDomain']

def get():
    r=c.call('ads','get',{'SelectionCriteria':{'Ids':[AID]},
        'FieldNames':['Id','Status','State'],'TextAdFieldNames':FIELDS})
    return r['Ads'][0]

before=get()
print("ДО:", json.dumps(before['TextAd'], ensure_ascii=False)[:600])
ta=before['TextAd']
ext=[e['AdExtensionId'] for e in (ta.get('AdExtensions') or [])]
payload={'Id':AID,'TextAd':{
  'Title':ta['Title'],'Text':ta['Text'],
  'Href':B+'/buketi-cvetov/'+UTM,
  'SitelinkSetId':ta['SitelinkSetId'],
  'DisplayUrlPath':ta['DisplayUrlPath'],
  'BusinessId':ta['BusinessId'],
  'TrackingPhoneId':ta['TrackingPhoneId'],
  'AdExtensionIds':ext}}
if ta.get('Title2'): payload['TextAd']['Title2']=ta['Title2']
try:
    res=c.call('ads','update',{'Ads':[payload]})
    print("\nОТВЕТ update:", json.dumps(res, ensure_ascii=False)[:600])
except DirectError as e:
    print("\nОШИБКА:", str(e)[:500]); sys.exit(1)

after=get()
print("\nПОСЛЕ:", json.dumps(after['TextAd'], ensure_ascii=False)[:600])
print("\n=== СВЕРКА ПОЛЕЙ ===")
for f in FIELDS:
    b1,b2=before['TextAd'].get(f), after['TextAd'].get(f)
    mark='OK ' if (f=='Href' or b1==b2) else '!! '
    if f=='Href': mark='CHG' if b1!=b2 else 'SAME'
    print(f"  {mark:4} {f:20} {str(b1)[:60]!r:64} -> {str(b2)[:60]!r}")
print(f"\n  Status: {before['Status']} -> {after['Status']} | State: {before['State']} -> {after['State']}")
json.dump({'before':before,'after':after}, open(os.path.join(OUT,'test_one_ad.json'),'w'), ensure_ascii=False, indent=1)
