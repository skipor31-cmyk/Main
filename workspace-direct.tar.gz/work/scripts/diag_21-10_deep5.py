#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Запросы 1-8 октября: матчил ли ключ «доставка цветов раменское» до остановки."""
import json, sys, os, csv, io, time
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client, OUT
from direct_api import DirectError

c = client()

def rep(rtype, fields, dfrom, dto, tag, filt=None):
    fn = os.path.join(OUT, f'deep_{tag}.tsv')
    if os.path.exists(fn) and os.path.getsize(fn) > 50:
        print(tag, 'exists, skip'); return
    sel = {'DateFrom': dfrom, 'DateTo': dto, 'Filter': filt or []}
    rd = {'SelectionCriteria': sel, 'FieldNames': fields,
          'ReportName': f'deep_{tag}', 'ReportType': rtype,
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    for attempt in range(8):
        try:
            tsv = c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
            open(fn,'w').write(tsv); print(tag, 'rows:', len(tsv.splitlines())); return
        except DirectError as e:
            if '56' in str(getattr(e,'code','')) or 'Превышен лимит' in str(e):
                print(tag, 'rate-limit wait'); time.sleep(15); continue
            raise

rep('SEARCH_QUERY_PERFORMANCE_REPORT',
    ['Date','Query','MatchedKeyword','AdGroupName','Impressions','Clicks','Cost'],
    '2026-10-01','2026-10-08','query_oct1_8',
    [{'Field':'CampaignId','Operator':'EQUALS','Values':['40732207']}])
