# -*- coding: utf-8 -*-
"""Проверка: есть ли на сайте категории под спорные запросы из поисковых фраз."""
import json, os, sys, urllib.request, urllib.error, ssl, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import OUT
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
# sitemap уже скачан в прошлой сессии
sm=os.path.join(OUT,'..','..','extract/workspace/analysis/sitecheck/sitemap_locs.json')
locs=[]
if os.path.exists(sm):
    locs=json.load(open(sm))
    if isinstance(locs,dict): locs=locs.get('locs') or locs.get('urls') or list(locs.values())[0]
print('URL из sitemap:', len(locs))
if not locs:
    try:
        r=urllib.request.urlopen('https://flowerpoetry.ru/sitemap.xml',timeout=40,context=ctx)
        locs=re.findall(r'<loc>(.*?)</loc>', r.read().decode('utf-8','ignore'))
        print('подтянули sitemap заново:', len(locs))
        json.dump(locs, open(os.path.join(OUT,'sitemap_locs_18-10.json'),'w'))
    except Exception as e: print('sitemap ERR', str(e)[:90])

WORDS=['гладиолус','ромашк','сухоцвет','пион','гортенз','роза','тюльпан','хризантем','эустом',
       'гипсофил','гвоздик','лилия','орхиде','альстромер','подсолн','ирис','пионовидн',
       'коробк','корзин','шляпн','свадеб','невест','новогодн','елк','композиц','букет']
print('\n=== КАТЕГОРИИ/ТОВАРЫ ПО СЛОВАМ (по slugам sitemap) ===')
for w in WORDS:
    hits=[u for u in locs if w in u.lower() or w.replace('к','k') in u.lower()]
    # транслит-варианты
    tr={'гладиолус':'gladiolus','ромашк':'romashk','сухоцвет':'suhocvet','пион':'pion','гортенз':'gortenz',
        'роза':'roz','тюльпан':'tyulpan','хризантем':'hrizantem','эустом':'ehustom','гипсофил':'gipsofil',
        'гвоздик':'gvozdik','лилия':'lilii','орхиде':'orhide','альстромер':'alstromer','подсолн':'podsoln',
        'ирис':'iris','коробк':'korobk','корзин':'korzink','шляпн':'shlyapn','свадеб':'svad','невест':'nevest',
        'новогодн':'novogod','композиц':'kompozicii','букет':'buket'}
    t=tr.get(w)
    if t: hits += [u for u in locs if t in u.lower()]
    hits=sorted(set(hits))
    print(f'  {w:14} {len(hits):5} URL   {hits[0].replace("https://flowerpoetry.ru","")[:64] if hits else "— НЕТ"}')

print('\n=== ВСЕ КАТЕГОРИИ /po_cvetam/ (по видам цветов) ===')
cats=sorted({u.replace('https://flowerpoetry.ru','') for u in locs if '/po_cvetam/' in u and u.count('/')<=5})
for c in cats: print('  ', c)
