# -*- coding: utf-8 -*-
"""Диагностика 18.10, часть 2:
- применилась ли загрузка Коммандера (Href, Title2, минус-слова кампании/групп)
- статусы/ставки ключей
- статистика показов 15–18.10
- баланс (v4 GetClientInfo)
- снят ли спецрежим записи (безвредный update)
"""
import json, os, sys, csv, io
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError

c = client()
CID = 40732207

print("=" * 70)
print("A. КАМПАНИЯ 40732207 — ПОЛНЫЕ ПОЛЯ (бюджет, расписание, минус-слова)")
print("=" * 70)
FIELDS = ['Id', 'Name', 'Status', 'State', 'StatusClarification', 'Currency',
          'DailyBudget', 'NegativeKeywords', 'TimeTargeting', 'ExcludedSites',
          'Funds', 'StartDate', 'EndDate', 'Notification']
try:
    r = c.call('campaigns', 'get', {'SelectionCriteria': {'Ids': [CID]},
                                    'FieldNames': FIELDS})
    camp = r['Campaigns'][0]
    for k in FIELDS:
        if k in camp:
            v = json.dumps(camp[k], ensure_ascii=False)
            if k == 'NegativeKeywords':
                toks = camp[k].get('Items', [])
                v = f"{len(toks)} токенов: {' '.join(toks[:40])}…"
            elif k == 'TimeTargeting':
                v = json.dumps(camp[k], ensure_ascii=False)[:400]
            elif k == 'ExcludedSites':
                v = f"{len(camp[k].get('Items', []))} шт"
            print(f"  {k}: {v[:420]}")
except DirectError as e:
    print("  ERR:", str(e)[:400])

print()
print("=" * 70)
print("B. ОБЪЯВЛЕНИЯ: Href + Title2 (применился ли XLSX?)")
print("=" * 70)
try:
    r = c.call('ads', 'get', {
        'SelectionCriteria': {'CampaignIds': [CID], 'States': ['ON']},
        'FieldNames': ['Id', 'AdGroupId', 'State', 'Status', 'StatusClarification',
                       'Type', 'TextAd']})
    ads = r.get('Ads', [])
    print(f"  активных объявлений: {len(ads)}")
    n_title2 = n_new_url = n_old_url = 0
    samples = []
    for a in ads:
        ta = a.get('TextAd') or {}
        href = ta.get('Href', '')
        t2 = ta.get('Title2')
        if t2:
            n_title2 += 1
        if 'buketi-cvetov' in href or 'po_cvetam' in href:
            n_new_url += 1
        else:
            n_old_url += 1
            if len(samples) < 6:
                samples.append((a['Id'], href, (ta.get('Title') or '')[:40], t2))
    print(f"  с заполненным Title2: {n_title2}/{len(ads)}")
    print(f"  URL новые (buketi-cvetov/po_cvetam): {n_new_url}, прочие: {n_old_url}")
    for s in samples:
        print(f"    ⚠ Ad {s[0]}: href={s[1][:110]}")
        print(f"       title='{s[2]}' title2={json.dumps(s[3], ensure_ascii=False) if s[3] else 'ПУСТО'}")
    # показать 5 любых href для контроля
    print("  первые 5 href:")
    for a in ads[:5]:
        ta = a.get('TextAd') or {}
        print(f"    Ad {a['Id']}: {ta.get('Href','')[:130]}  title2={'+' if ta.get('Title2') else '—'}")
except DirectError as e:
    print("  ads.get ERR:", str(e)[:300])

print()
print("=" * 70)
print("C. КЛЮЧИ: статусы и ставки")
print("=" * 70)
try:
    r = c.call('keywords', 'get', {
        'SelectionCriteria': {'CampaignIds': [CID]},
        'FieldNames': ['Id', 'AdGroupId', 'Keyword', 'State', 'Status',
                       'StatusClarification', 'Bid']})
    kws = r.get('Keywords', [])
    print(f"  ключей всего: {len(kws)}")
    from collections import Counter
    st = Counter((k.get('State'), k.get('Status')) for k in kws)
    for key, n in st.most_common(15):
        print(f"      State={key[0]} Status={key[1]}: {n}")
    on = [k for k in kws if k.get('State') == 'ON']
    print(f"  ON-ключей: {len(on)}")
    bids = [k.get('Bid') for k in on if k.get('Bid')]
    if bids:
        bids.sort()
        print(f"  ставки ON: min={bids[0]} med={bids[len(bids)//2]} max={bids[-1]} (руб)")
    st_on = Counter(k.get('Status') for k in on)
    print(f"  статусы ON-ключей: {dict(st_on)}")
    clar = Counter(k.get('StatusClarification') for k in on if k.get('StatusClarification'))
    print(f"  уточнения ON-ключей: {dict(list(clar.items())[:8])}")
except DirectError as e:
    print("  keywords.get ERR:", str(e)[:300])

print()
print("=" * 70)
print("D. ГРУППЫ: минус-слова (применился ли BM-патч?)")
print("=" * 70)
try:
    r = c.call('adgroups', 'get', {
        'SelectionCriteria': {'CampaignIds': [CID], 'Types': ['TEXT_AD_GROUP']},
        'FieldNames': ['Id', 'Name', 'Status', 'NegativeKeywords']})
    groups = r.get('AdGroups', [])
    acc = [g for g in groups if g.get('Status') == 'ACCEPTED']
    print(f"  групп ACCEPTED: {len(acc)} (из {len(groups)})")
    with_neg = 0
    for g in acc:
        nk = (g.get('NegativeKeywords') or {}).get('Items', [])
        if nk:
            with_neg += 1
    print(f"  групп с минус-словами: {with_neg}/{len(acc)}")
    for g in acc[:4]:
        nk = (g.get('NegativeKeywords') or {}).get('Items', [])
        print(f"    G{g['Id']} '{g.get('Name','')[:40]}' neg={len(nk)}: {' '.join(nk[:12])}")
except DirectError as e:
    print("  adgroups.get ERR:", str(e)[:300])

print()
print("=" * 70)
print("E. СТАТИСТИКА 15–18.10 (по дням, все кампании)")
print("=" * 70)
def rep(rtype, fields, dfrom, dto, filt=None):
    rd = {'SelectionCriteria': {'DateFrom': dfrom, 'DateTo': dto, 'Filter': filt or []},
          'FieldNames': fields, 'ReportName': 'diag2', 'ReportType': rtype,
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    tsv = c.report(rd, skip_report_header=True, skip_column_header=False,
                   skip_report_summary=True)
    return list(csv.DictReader(io.StringIO(tsv), delimiter='\t'))

try:
    rows = rep('CAMPAIGN_PERFORMANCE_REPORT',
               ['Date', 'CampaignId', 'CampaignName', 'Impressions', 'Clicks', 'Cost'],
               '2026-10-15', '2026-10-18')
    print(f"  строк: {len(rows)}")
    rows.sort(key=lambda x: (x.get('Date', ''), x.get('CampaignId', '')))
    for r_ in rows:
        print(f"    {r_.get('Date')}  id={r_.get('CampaignId')}  {r_.get('CampaignName','')[:38]:38}"
              f"  imp={r_.get('Impressions')}  clk={r_.get('Clicks')}  cost={r_.get('Cost')}")
except DirectError as e:
    print("  report ERR:", str(e)[:300])

print()
print("=" * 70)
print("F. БАЛАНС (v4 GetClientInfo)")
print("=" * 70)
import urllib.request
try:
    from cfg import CFG
    body = json.dumps({'method': 'GetClientInfo', 'param': 'skipor31'}).encode()
    req = urllib.request.Request('https://api.direct.yandex.com/live/v4/json',
                                 data=body, method='POST',
                                 headers={'Authorization': 'OAuth ' + CFG['token'],
                                          'Client-Login': 'skipor31',
                                          'Content-Type': 'application/json',
                                          'Accept-Language': 'ru'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode())
    arr = data.get('data') or []
    for cl in arr:
        print(f"  Login={cl.get('Login')}  Balance={cl.get('Balance')}  "
              f"Overdraft={cl.get('OverdraftSumAvailable')}  "
              f"StatusShow={cl.get('StatusShow')}  StatusActiv={cl.get('StatusActiv')}  "
              f"StatusModere={cl.get('StatusModere')}")
        print(f"  MoneyInBefore={cl.get('MoneyInBefore')}  ContextBalance? {cl.get('ContextBalance')}")
except Exception as e:
    print("  v4 ERR:", repr(e)[:300])

print()
print("=" * 70)
print("G. ТЕСТ ЗАПИСИ (спецрежим снят?): update имени кампании тем же именем")
print("=" * 70)
try:
    r = c.call('campaigns', 'update', {'Campaigns': [
        {'Id': CID, 'Name': '[ПОИСК] Доставка Раменское'}]})
    print("  ✅ campaigns.update ПРОШЁЛ:", json.dumps(r, ensure_ascii=False)[:200])
except DirectError as e:
    print("  ❌ campaigns.update:", str(e)[:300])
