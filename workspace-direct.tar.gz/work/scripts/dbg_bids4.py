import json, sys
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client
c = client()
IDS = [20363191489, 20363191694, 58167571692, 37517535140]
r = c.call('keywordbids', 'get', {
    'SelectionCriteria': {'KeywordIds': IDS},
    'FieldNames': ['KeywordId','ServingStatus','StrategyPriority','AdGroupId','CampaignId'],
})
print(json.dumps(r, ensure_ascii=False)[:1500])
