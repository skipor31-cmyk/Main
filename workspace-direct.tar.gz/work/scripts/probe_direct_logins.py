# -*- coding: utf-8 -*-
"""Проверка: работает ли ym:ad:* с параметром direct_client_logins."""
import json, os, sys, urllib.parse, urllib.request, urllib.error, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; BASE='https://api-metrika.yandex.net'
def q(p):
    url=BASE+'/stat/v1/data?'+urllib.parse.urlencode(p, doseq=True)
    for t in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=120) as r:
                return 'OK', json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            b=e.read().decode()
            if e.code in (502,503): time.sleep(6); continue
            return f'ERR{e.code}', b[:230]
        except Exception as e: time.sleep(4)
    return 'ERR','retries'

print("=== 1. ym:ad:visits С параметром direct_client_logins=skipor31 ===")
st,r=q({'ids':CID,'metrics':'ym:ad:visits,ym:ad:clicks','date1':'30daysAgo','date2':'today',
        'direct_client_logins':'skipor31'})
print(f"  {st}: {json.dumps(r,ensure_ascii=False)[:300] if st=='OK' else r}")

print("\n=== 2. подбор валидных имён измерений ym:ad:* ===")
for d in ['ym:ad:date','ym:ad:cross_device_last_significantDirectOrderName',
          'ym:ad:last_significantDirectOrderName','ym:ad:lastDirectOrderName',
          'ym:ad:directOrderName','ym:ad:campaignName','ym:ad:OrderName']:
    st,r=q({'ids':CID,'metrics':'ym:ad:visits','dimensions':d,'date1':'30daysAgo','date2':'today',
            'limit':5,'direct_client_logins':'skipor31'})
    if st=='OK':
        print(f"  ✅ {d:56} -> {[x['dimensions'][0]['name'][:44] for x in (r.get('data') or [])]}")
    else:
        print(f"  ❌ {d:56} {str(r)[:88]}")

print("\n=== 3. подбор валидных метрик ym:ad:* ===")
for m in ['ym:ad:visits','ym:ad:clicks','ym:ad:RUBConvertedAdCost','ym:ad:AdCost',
          'ym:ad:ecommercePurchases','ym:ad:ecommerceRUBConvertedRevenue','ym:ad:goalreaches',
          'ym:ad:CPC','ym:ad:CTR','ym:ad:impressions']:
    st,r=q({'ids':CID,'metrics':m,'date1':'30daysAgo','date2':'today','direct_client_logins':'skipor31'})
    v=(r.get('data') or [{}])[0].get('metrics') if st=='OK' else str(r)[:70]
    print(f"  {st:6} {m:42} {v}")
