# -*- coding: utf-8 -*-
"""Скоринг по методологии скилла direct (YD01-YD55), на данных 17.10.2026."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import OUT

SEV={'Critical':5.0,'High':3.0,'Medium':1.5,'Low':0.5}
CATW={'conv':0.25,'waste':0.20,'struct':0.15,'kw':0.15,'ads':0.15,'settings':0.10}
# (id, category, severity, result, evidence)
C=[
 ('YD01','conv','Critical','PASS','Счётчик 33595239 привязан к кампании и стоит на всех 16 посадочных нового сайта'),
 ('YD02','conv','Critical','PASS','После чистки 29.09: 10 приоритетных целей, шумовых и битых 0 (заказ 5500, звонок 2500, мессенджер 1500)'),
 ('YD03','conv','High','WARN','E-commerce цели есть (3033595239, 672187821), но срабатывают только с 12.10 (2 покупки / 4 корзины). Revenue в Метрику не передаётся → MaxProfit недоступен'),
 ('YD05','conv','Medium','FAIL','Оффлайн-конверсии (CRM/журнал заказов → yclid) не загружаются'),
 ('YD06','conv','Medium','WARN','AttributionModel=AUTO; с 11.10 Яндекс не связывает конверсии с кликами до 11.10 (специальный режим) — данные за октябрь частично неатрибутированы'),
 ('YD07','conv','Medium','PASS','Ценности целей назначены вручную (IsMetrikaSourceOfValue=NO)'),
 ('YD08','conv','Low','PASS','Автоцели работают: форма 80, контакты 65, мессенджер 34, начало чекаута 57 за 90 дней'),
 ('YD09','conv','Low','FAIL','Интеграции с CRM нет'),

 ('YD10','waste','Critical','WARN','900 минус-слов кампании, НО 7 из них убивают 10 собственных живых ключей («онлайн»×6, «101», «срочно», «сайт», «подмосковье», «цены», «расчет»)'),
 ('YD11','waste','High','FAIL','NegativeKeywordSharedSetIds пуст — общих наборов нет'),
 ('YD12','waste','Critical','WARN','Майнинг запросов выполнен в прошлых сессиях (90д); сейчас SEARCH_QUERY-отчёт API не отдаёт'),
 ('YD13','waste','High','PASS','Кросс-минусовка и перенос ключей выполнены 29.09 (220 ключей в SUSPENDED)'),
 ('YD15','waste','High','WARN','Бренд выделен в группу Б1 (CPC 45 ₽ — лучший в поиске), но не в отдельную кампанию'),
 ('YD16','waste','Medium','PASS','Информационные запросы заминусованы (faq, doc, download, jpeg, mp3 и т.п.)'),
 ('YD17','waste','High','FAIL','45 ключей с расходом 31 848 ₽ (35,5% бюджета) и НУЛЁМ целей за 90 дней'),
 ('YD18','waste','Medium','WARN','Дубли ключей между М2/М3-остатком и подгруппами есть, но старые приостановлены'),

 ('YD19','struct','Critical','PASS','Поиск (40732207), товарная (704504054) и РСЯ (704507321) разделены'),
 ('YD20','struct','High','PASS','Структура Д/К/М/Б по интентам и кластерам (после пересборки 29.09)'),
 ('YD21','struct','Medium','PASS','11 старых групп переименованы по схеме Д1/К1/М2/Б1'),
 ('YD22','struct','Medium','WARN','6 живых групп >15 ключей (К2=37, К1.3=33, М2.1=23, М1=20)'),
 ('YD23','struct','Medium','FAIL','473 группы в DRAFT с 1 076 ключами в статусе ON — мёртвый вес; 85 кампаний в архиве'),
 ('YD25','struct','Medium','WARN','Жуковский выделен группой Д5 (гео=1), но общая кампания; 17 гео-ID в одной корзине'),
 ('YD26','struct','Medium','WARN','Расписание 08:00–23:00; ночные и ранние заказы цветов отсекаются (не тестировалось)'),

 ('YD27','kw','High','PASS','Операторы применены (Раунд 3, 05.10): +с, +на дом, -!в и т.д.'),
 ('YD28','kw','Critical','PASS','Широкое соответствие только под автостратегией (AVERAGE_CPA_MULTIPLE_GOALS)'),
 ('YD29','kw','High','WARN','13 подгрупп с точечными посадочными созданы, но получили 37 показов и 0 кликов — связка «запрос→объявление→лендинг» фактически не проверена'),
 ('YD30','kw','Medium','PASS','НЧ-хвосты есть (М2.1–М3.7, деревенские запросы Д3)'),
 ('YD31','kw','High','FAIL','Поисковая кампания: 1 023 показа за 90 дней (~11/день) при 260 живых ключах — фактически «мало показов» на уровне кампании'),
 ('YD33','kw','Medium','FAIL','Ключи «букет пионов» и «купить пионы раменское» активны при закончившемся сезоне (объявление обещает пионы)'),
 ('YD34','kw','High','PASS','Все 260 живых ключей ServingStatus=ELIGIBLE; ключей с CTR<1% при >100 показах нет'),

 ('YD35','ads','Critical','WARN','53/59 ACCEPTED; 2 объявления REJECTED в группе «Ключи» кампании 704507321 (перед перезапуском РСЯ надо пересобрать)'),
 ('YD36','ads','High','FAIL','21 из 32 живых групп (66%) имеют ≤1 объявления — выбирать не из чего'),
 ('YD37','ads','High','PASS','Заголовок 1 содержит ключ и гео («Доставка цветов в Жуковском за 2 часа»)'),
 ('YD38','ads','Medium','FAIL','Заголовок 2 пуст у 49 из 49 активных объявлений — потеряно 30 символов оффера'),
 ('YD39','ads','High','PASS','Быстрые ссылки 49/49 (4 шт.); 3 из 4 URL требуют правки после переезда сайта'),
 ('YD40','ads','Medium','PASS','Уточнения 49/49 (12 callouts)'),
 ('YD41','ads','Medium','PASS','Отображаемая ссылка 48/49'),
 ('YD42','ads','Medium','PASS','Визитка/Яндекс Бизнес 49/49 (BusinessId 103128457869)'),
 ('YD43','ads','High','WARN','UTM на 48/49; без UTM объявление 17382035200 (РСЯ, группа «Ключи»)'),
 ('YD46','ads','Medium','FAIL','A/B-тесты не проводятся (следствие YD36)'),

 ('YD47','settings','Critical','PASS','Гео = Раменское + Жуковский + 15 населённых пунктов зоны доставки'),
 ('YD48','settings','High','WARN','ENABLE_AREA_OF_INTEREST_TARGETING=YES — показы за пределами зоны доставки не проверены'),
 ('YD49','settings','High','FAIL','AVERAGE_CPA_MULTIPLE_GOALS при 3 заказах за 90 дней: данных для обучения нет, алгоритм задирает CPC до 250–431 ₽'),
 ('YD50','settings','High','WARN','Недельный лимит 15 000 ₽, фактический расход ~3 500 ₽/нед — бюджет не осваивается (ограничение не в деньгах, а в охвате)'),
 ('YD51','settings','Medium','FAIL','BidCeiling 650 ₽ при целевом CPA 1 200 ₽ и 3 заказах — потолок не защищает бюджет'),
 ('YD55','settings','High','PASS','Автотаргетинг ограничен категориями (EXACT=YES, COMPETITOR/BROADER/ALTERNATIVE=NO) и WITHOUT_BRANDS'),
]
SCORE={'PASS':1.0,'WARN':0.5,'FAIL':0.0}
num=den=0.0; percat={}
for cid,cat,sev,res,ev in C:
    w=SEV[sev]*CATW[cat]
    num+=SCORE[res]*w; den+=w
    a=percat.setdefault(cat,[0.0,0.0,collections_counter:=[]])
    a[0]+=SCORE[res]*SEV[sev]; a[1]+=SEV[sev]; a[2].append((cid,sev,res))
total=num/den*100
grade='A' if total>=90 else 'B' if total>=75 else 'C' if total>=60 else 'D' if total>=40 else 'F'
print(f"ИТОГОВАЯ ОЦЕНКА: {total:.1f} / 100  — грейд {grade}")
NAMES={'conv':'Конверсии и Метрика (25%)','waste':'Слив бюджета / минус-слова (20%)',
       'struct':'Структура аккаунта (15%)','kw':'Ключевые слова и качество (15%)',
       'ads':'Объявления и расширения (15%)','settings':'Настройки и таргетинг (10%)'}
print(f"\n{'категория':36} {'балл':>7}  PASS/WARN/FAIL")
for cat in CATW:
    a=percat[cat]
    p=sum(1 for _,_,r in a[2] if r=='PASS'); w=sum(1 for _,_,r in a[2] if r=='WARN'); f=sum(1 for _,_,r in a[2] if r=='FAIL')
    print(f"{NAMES[cat]:36} {a[0]/a[1]*100:6.1f}%   {p}/{w}/{f}")
print(f"\nвсего проверок: {len(C)}  PASS {sum(1 for x in C if x[3]=='PASS')}  WARN {sum(1 for x in C if x[3]=='WARN')}  FAIL {sum(1 for x in C if x[3]=='FAIL')}")
json.dump({'score':round(total,1),'grade':grade,'checks':[{'id':c[0],'cat':c[1],'sev':c[2],'res':c[3],'evidence':c[4]} for c in C],
           'percat':{k:round(v[0]/v[1]*100,1) for k,v in percat.items()}},
          open(os.path.join(OUT,'audit_score_v3.json'),'w'), ensure_ascii=False, indent=1)
print("\n=== FAIL (срочно) ===")
for cid,cat,sev,res,ev in C:
    if res=='FAIL': print(f"  {cid} [{sev}] {ev[:150]}")
print("\n=== WARN ===")
for cid,cat,sev,res,ev in C:
    if res=='WARN': print(f"  {cid} [{sev}] {ev[:150]}")
