# -*- coding: utf-8 -*-
"""Выгрузка живого состояния аккаунта."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError

c = client()

def save(name, data):
    p = os.path.join(OUT, name)
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    print("  saved %-32s %7.1f KB" % (name, os.path.getsize(p)/1024))

def paged(svc, method, params, key, limit=10000):
    out, offset = [], 0
    while True:
        pr = dict(params); pr['Page'] = {'Limit': limit, 'Offset': offset}
        rows = c.call(svc, method, pr).get(key, [])
        out += rows
        if len(rows) < limit: return out
        offset += limit
        if offset > 200000: return out

CF = ['Id','Name','Status','State','StatusClarification','Funds','DailyBudget','Currency',
      'Type','StartDate','EndDate','NegativeKeywords','TimeTargeting','ClientInfo',
      'Statistics','StatusPayment','Notification','CreateTime','TimeZone']

print("[1] campaigns (ALL)")
camps = paged('campaigns','get',{'SelectionCriteria':{},'FieldNames':CF},'Campaigns')
save('live_campaigns_full.json', {'Campaigns': camps, 'count': len(camps)})
print("   total:", len(camps))
live = [x for x in camps if x.get('State') != 'ARCHIVED']
print("   non-archived:", len(live))
for x in live:
    f = x.get('Funds') or {}
    print("    %-10s state=%-9s status=%-11s %s" % (x['Id'], x.get('State'), x.get('Status'), x.get('Name')))
    print("        funds:", json.dumps(f, ensure_ascii=False)[:280])
    print("        dailyBudget:", x.get('DailyBudget'), "| startDate:", x.get('StartDate'), "| statusPayment:", x.get('StatusPayment'))
ids = [x['Id'] for x in live]

print("\n[2] adgroups")
ags = paged('adgroups','get',{'SelectionCriteria':{'CampaignIds':ids},
    'FieldNames':['Id','CampaignId','Name','Status','RegionIds','Type','NegativeKeywords','TrackingParams']},'AdGroups')
save('live_adgroups.json', {'AdGroups': ags, 'count': len(ags)})
print("   groups:", len(ags))

print("\n[3] ads +Href")
gids = [g['Id'] for g in ags]
ads = []
for i in range(0, len(gids), 1000):
    ads += paged('ads','get',{'SelectionCriteria':{'AdGroupIds':gids[i:i+1000]},
        'FieldNames':['Id','AdGroupId','CampaignId','Status','State','StatusClarification','Type'],
        'TextAdFieldNames':['Title','Title2','Text','Href','FinalUrl','Mobile','SitelinkSetId',
                            'AdExtensions','BusinessId','TrackingPhoneId','DisplayUrlPath',
                            'DisplayDomain']},'Ads')
save('live_ads_hrefs.json', {'Ads': ads, 'count': len(ads)})
print("   ads:", len(ads))

print("\n[4] sitelinks")
sl = sorted({(a.get('TextAd') or {}).get('SitelinkSetId') for a in ads if (a.get('TextAd') or {}).get('SitelinkSetId')})
print("   sets:", sl)
if sl:
    try:
        save('live_sitelinks.json', c.call('adextensions','get',{'SelectionCriteria':{'Ids':sl},
             'FieldNames':['Id','Sitelinks','Type']}))
    except DirectError as e: print("   err:", str(e)[:200])

print("\n[5] keywords")
kw = paged('keywords','get',{'SelectionCriteria':{'CampaignIds':ids},
    'FieldNames':['Id','AdGroupId','CampaignId','Keyword','Status','State','Bid','ContextBid','StrategyPriority','ServingStatus']},'Keywords')
save('live_keywords.json', {'Keywords': kw, 'count': len(kw)})
print("   keywords:", len(kw))

print("\n[6] campaign 76065880")
try:
    r7 = c.call('campaigns','get',{'SelectionCriteria':{'Ids':[76065880]},'FieldNames':CF})
    print("   ", json.dumps(r7.get('Campaigns',[]), ensure_ascii=False)[:350] or "NOT FOUND")
    save('campaign_76065880.json', r7)
except DirectError as e: print("   err:", str(e)[:200])
print("\nDONE")
