# -*- coding: utf-8 -*-
"""Диагностика 19.10, часть 5: конкретные ключи (пион/лилия/гортензия), свежие показы,
число кампаний (дубли?), статусы объявлений пион-группы."""
import json, os, sys, csv, io, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError

c = client()
CID = 40732207

IDS = {58168684647: 'пион-1', 58168684648: 'пион-2', 205806400169: 'пион-3(новый)',
       58168684649: 'гортензия', 58168298979: 'лилия'}

print("=" * 70)
print("A. КЛЮЧИ ГРУППЫ М2.4 (пион/гортензия/лилия) — применилась ли пауза из XLSX?")
print("=" * 70)
try:
    r = c.call('keywords', 'get', {'SelectionCriteria': {'Ids': list(IDS)},
                                   'FieldNames': ['Id', 'Keyword', 'State', 'Status', 'Bid']})
    for k in r.get('Keywords', []):
        print(f"  {k['Id']} ({IDS.get(k['Id'],'?')}): '{k.get('Keyword')}' "
              f"State={k.get('State')} Status={k.get('Status')} Bid={k.get('Bid')}")
    found = {k['Id'] for k in r.get('Keywords', [])}
    for i, n in IDS.items():
        if i not in found:
            print(f"  {i} ({n}): НЕ НАЙДЕН (возможно архивный)")
except DirectError as e:
    print("  ERR:", str(e)[:250])

print()
print("=" * 70)
print("B. ОБЪЯВЛЕНИЕ ПИОН-ГРУППЫ 5806400169")
print("=" * 70)
try:
    r = c.call('ads', 'get', {'SelectionCriteria': {'AdGroupIds': [5806400169]},
                              'FieldNames': ['Id', 'State', 'Status', 'StatusClarification']})
    for a in r.get('Ads', []):
        print(f"  Ad {a['Id']}: State={a.get('State')} Status={a.get('Status')} "
              f"Clar={a.get('StatusClarification')}")
except DirectError as e:
    print("  ERR:", str(e)[:250])

print()
print("=" * 70)
print("C. ЧИСЛО КАМПАНИЙ (нет ли дублей после Коммандера?)")
print("=" * 70)
try:
    r = c.call('campaigns', 'get', {'SelectionCriteria': {},
                                    'FieldNames': ['Id', 'Name', 'State', 'Status']})
    camps = r.get('Campaigns', [])
    print(f"  всего кампаний: {len(camps)} (было 88 на 17.10)")
    names = {}
    for cp in camps:
        names.setdefault(cp.get('Name'), []).append((cp['Id'], cp.get('State')))
    dups = {n: v for n, v in names.items() if len(v) > 1 and n}
    if dups:
        for n, v in dups.items():
            print(f"  ⚠ ДУБЛЬ: '{n}': {v}")
    else:
        print("  дублей по именам нет")
except DirectError as e:
    print("  ERR:", str(e)[:250])

print()
print("=" * 70)
print("D. СВЕЖИЙ ОТЧЁТ за сегодня, 19.10")
print("=" * 70)
time.sleep(11)
def rep(fields, dfrom, dto):
    rd = {'SelectionCriteria': {'DateFrom': dfrom, 'DateTo': dto, 'Filter': []},
          'FieldNames': fields, 'ReportName': 'diag5',
          'ReportType': 'CAMPAIGN_PERFORMANCE_REPORT',
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    tsv = c.report(rd, skip_report_header=True, skip_column_header=False,
                   skip_report_summary=True)
    return list(csv.DictReader(io.StringIO(tsv), delimiter='\t'))
try:
    rows = rep(['Date', 'CampaignId', 'Impressions', 'Clicks', 'Cost', 'AvgCpc'],
               '2026-10-18', '2026-10-19')
    if not rows:
        print("  ноль строк за 18–19.10")
    for r_ in sorted(rows, key=lambda x: x.get('Date', '')):
        print(f"  {r_.get('Date')} id={r_.get('CampaignId')} imp={r_.get('Impressions')} "
              f"clk={r_.get('Clicks')} cost={r_.get('Cost')} avgCpc={r_.get('AvgCpc')}")
except DirectError as e:
    print("  ERR:", str(e)[:250])
