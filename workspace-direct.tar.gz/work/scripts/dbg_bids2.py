import json, sys
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client
c = client()
try:
    r = c.call('keywordbids', 'get', {'SelectionCriteria': {'KeywordIds': [20363191489]}, 'FieldNames': ['XXX']})
except Exception as e:
    print('full field list err:', str(e)[:600])
try:
    r = c.call('keywordbids', 'get', {
        'SelectionCriteria': {'KeywordIds': [20363191489, 20363191694, 20363191696, 20363191491, 58167571692], 'CampaignIds': ['40732207']},
        'FieldNames': ['KeywordId','ServingStatus','StrategyPriority','Bid','AuctionBids'],
    })
    print(json.dumps(r, ensure_ascii=False, indent=1)[:3000])
except Exception as e:
    print('ERR2:', str(e)[:300])
    try:
        r = c.call('keywordbids', 'get', {
            'SelectionCriteria': {'KeywordIds': [20363191489, 20363191694, 20363191696, 20363191491, 58167571692], 'CampaignIds': ['40732207']},
            'FieldNames': ['KeywordId','ServingStatus','StrategyPriority','Bid'],
        })
        print(json.dumps(r, ensure_ascii=False, indent=1)[:2500])
    except Exception as e2:
        print('ERR3:', str(e2)[:300])
