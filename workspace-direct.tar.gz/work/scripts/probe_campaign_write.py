# -*- coding: utf-8 -*-
"""Безопасная проба: campaigns.suspend на УЖЕ приостановленной кампании 704507321 (no-op)."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, DirectError
c=client()
CID=704507321  # уже SUSPENDED — повторный suspend ничего не меняет
before=c.call('campaigns','get',{'SelectionCriteria':{'Ids':[CID]},'FieldNames':['Id','Name','State','Status']})
print("ДО:", json.dumps(before['Campaigns'], ensure_ascii=False))
try:
    r=c.call('campaigns','suspend',{'SelectionCriteria':{'Ids':[CID]}})
    print("\n✅ campaigns.suspend РАЗРЕШЁН:", json.dumps(r, ensure_ascii=False)[:300])
except DirectError as e:
    print("\n❌ campaigns.suspend запрещён:", str(e)[:250])
after=c.call('campaigns','get',{'SelectionCriteria':{'Ids':[CID]},'FieldNames':['Id','Name','State','Status']})
print("ПОСЛЕ:", json.dumps(after['Campaigns'], ensure_ascii=False))
print("\nИзменилось состояние:", before['Campaigns'][0].get('State') != after['Campaigns'][0].get('State'))
