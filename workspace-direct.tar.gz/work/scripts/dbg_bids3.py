import json, sys
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client
c = client()
IDS = [20363191489, 20363191694, 20363191696, 20363191491, 15740200960, 20363191502,
       20363191552, 20363191576, 20363191553, 20363191600,   # head Д1-Д4
       58167571692, 58167571683, 58167571664, 58167571756,   # контроль: К2 и Б1 (идут показы)
       37517535140]                                          # автотаргетинг Д1
r = c.call('keywordbids', 'get', {
    'SelectionCriteria': {'KeywordIds': IDS, 'CampaignIds': ['40732207']},
    'FieldNames': ['KeywordId','ServingStatus','StrategyPriority'],
})
for k in r.get('result',{}).get('KeywordBids',[]):
    print(k['KeywordId'], '|', k.get('ServingStatus'), '| prio:', k.get('StrategyPriority'))
