import json, os, sys, csv, io, datetime, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, CFG
c=client()
GOALS=[str(CFG['metrica']['primary_goal_id'])]+[str(g) for g in CFG['metrica']['secondary_goal_ids']]
def rep(fields, goals=None, tries=6, days=60):
    T=datetime.date(2026,10,17); df=(T-datetime.timedelta(days=days)).isoformat(); dt=T.isoformat()
    rd={'SelectionCriteria':{'DateFrom':df,'DateTo':dt,'Filter':[]},'FieldNames':fields,
        'ReportName':'sq','ReportType':'SEARCH_QUERY_PERFORMANCE_REPORT',
        'DateRangeType':'CUSTOM_DATE','Format':'TSV','IncludeVAT':'YES'}
    if goals: rd['Goals']=goals; rd['AttributionModels']=['LSC']
    for t in range(tries):
        try:
            tsv=c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
            return list(csv.DictReader(io.StringIO(tsv), delimiter='\t')), None
        except Exception as e:
            m=str(e)
            if '"56"' in m or 'лимит' in m: time.sleep(15); continue
            return None, m
    return None,'rate limit'
for fields in (['SearchPhrase','Impressions','Clicks','Cost','Conversions'],
               ['CampaignId','AdGroupId','SearchPhrase','Impressions','Clicks','Cost'],
               ['SearchPhrase','Impressions','Clicks','Cost']):
    rows,err=rep(fields, GOALS if 'Conversions' in fields else None)
    if err: print("❌",fields,err[:200]); time.sleep(12); continue
    print("✅",fields,"rows:",len(rows or []))
    if rows:
        p=os.path.join(OUT,'r_query_60d.tsv')
        cols=list(rows[0].keys())
        with open(p,'w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=cols,delimiter='\t',extrasaction='ignore'); w.writeheader(); w.writerows(rows)
        print("  saved", os.path.getsize(p)//1024,"KB")
        break
