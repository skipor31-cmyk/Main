import json, sys, os
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client
c = client()
r = c.call('campaigns', 'get', {
    'SelectionCriteria': {'Ids': [40732207]},
    'FieldNames': ['Id','Name','State','Status','Statistics','DailyBudget'],
    'TextCampaignFieldNames': ['BiddingStrategy','Settings','PriorityGoals'],
})
print(json.dumps(r, ensure_ascii=False)[:4000])
