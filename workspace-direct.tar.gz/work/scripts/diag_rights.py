# -*- coding: utf-8 -*-
import json, os, sys, urllib.request, urllib.error
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, CFG, DirectError
BASE='https://api.direct.yandex.com/json/v5/'
TOK=CFG['token']

def raw(headers, svc, method, params):
    body=json.dumps({'method':method,'params':params}, ensure_ascii=False).encode()
    req=urllib.request.Request(BASE+svc, data=body, headers=headers, method='POST')
    try:
        r=urllib.request.urlopen(req, timeout=30)
        return 'OK', r.read().decode()[:300]
    except urllib.error.HTTPError as e:
        return f'HTTP {e.code}', e.read().decode()[:300]
    except Exception as e:
        return 'ERR', str(e)[:200]

H_FULL={'Authorization':f'Bearer {TOK}','Accept-Language':'ru',
        'Content-Type':'application/json; charset=utf-8','Client-Login':'skipor31'}
H_NOLOGIN={k:v for k,v in H_FULL.items() if k!='Client-Login'}

tests=[
 ('READ campaigns.get', 'campaigns', 'get', {'SelectionCriteria':{'Ids':[40732207]},'FieldNames':['Id','Name']}),
 ('NO-OP campaigns.update (то же имя)', 'campaigns', 'update', {'Campaigns':[{'Id':40732207,'Name':'[ПОИСК] Доставка Раменское'}]}),
 ('WRITE keywords.suspend (пионы)', 'keywords', 'suspend', {'SelectionCriteria':{'Ids':[58168684647]}}),
 ('WRITE ads.suspend (пионы)', 'ads', 'suspend', {'SelectionCriteria':{'Ids':[1922758453206718169]}}),
]
for label,h in (('С Client-Login: skipor31', H_FULL), ('БЕЗ Client-Login', H_NOLOGIN)):
    print("\n" + "="*70); print(label); print("="*70)
    for name,svc,m,p in tests:
        code,msg=raw(h,svc,m,p)
        print(f"  {name:42} {code:10} {msg[:170]}")
