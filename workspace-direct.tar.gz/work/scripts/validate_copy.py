# -*- coding: utf-8 -*-
"""Валидация текстов по жёсткому гейту скилла (ads.py validate_ad)."""
import os, sys
SK=os.path.join(os.environ.get('ARENA_WORKSPACE','"$ARENA_WORKSPACE"'),
  'extract/workspace/skills_repo/extracted1/skill_for_claude_code_yandex_direct-main/scripts')
sys.path.insert(0, SK)
from ads import validate_ad, LIMITS

CANDS=[
 ("A (оффер из description сайта)", dict(
   title="Букеты с гортензией в Раменском",
   title2="Доставка 2 часа. От 2660 руб",
   text="Объёмные букеты с гортензией: один цветок заменяет охапку. Доставка за 2 часа!",
   display_path="Гортензии")),
 ("B (цена + фото до отправки)", dict(
   title="Букеты с гортензией в Раменском",
   title2="Доставка 2 часа. От 2660 руб",
   text="Гортензии в наличии. Объёмный букет от 2660 руб. Доставка 2 часа. Фото до отправки!",
   display_path="Гортензии")),
 ("C (под бюджет + открытка)", dict(
   title="Гортензия в Раменском — доставка 2 часа",
   title2="Объёмный букет. Фото до отправки",
   text="Соберём букет с гортензией под ваш бюджет. Доставка за 2 часа. Открытка в подарок!",
   display_path="Гортензии")),
]
print("ЛИМИТЫ:", LIMITS, "\n")
for name, ad in CANDS:
    errs=validate_ad(ad, 0)
    print(f"● {name}")
    print(f"   T1 ({len(ad['title'])}/{LIMITS['title']}): {ad['title']}")
    print(f"   T2 ({len(ad['title2'])}/{LIMITS['title2']}): {ad['title2']}")
    print(f"   TX ({len(ad['text'])}/{LIMITS['text']}): {ad['text']}")
    print(f"   DP ({len(ad['display_path'])}/{LIMITS['display_path']}): {ad['display_path']}")
    print("   " + ("✅ VALID" if not errs else "❌ " + "; ".join(errs)))
    print()

print("=== БЫСТРЫЕ ССЫЛКИ (лимиты 30 / 60) ===")
SL=[('Каталог букетов','Красивые букеты на любой случай, от 2000 руб.'),
    ('Доставка цветов','Быстрая доставка за 2 часа по Раменскому и району.'),
    ('Галерея работ','Авторские букеты и композиции наших флористов.'),
    ('Композиции в коробках','Элегантные композиции в стильных коробках.')]
for t,d in SL:
    ok = len(t)<=LIMITS['sitelink_title'] and len(d)<=LIMITS['sitelink_description']
    print(f"  {'✅' if ok else '❌'} {t!r} ({len(t)}/30) | {d!r} ({len(d)}/60)")

print("\n=== ЗАГОЛОВОК 2 для основных групп (сейчас пуст у 49/49) ===")
T2=[("Д1–Д5 Доставка","Привезём за 2 часа. От 2000 ₽"),
    ("К1–К2 Купить/заказать","Оплата картой. Открытка в дар"),
    ("М1 Магазин","150+ букетов в наличии"),
    ("Б1 Бренд","Свои флористы. Доставка 2 ч"),
    ("М2.x По видам","Соберём под ваш бюджет"),
    ("М3.x По поводам","Открытка в подарок"),
    ("М4 Коробки","Композиции со сладостями"),
    ("Д4 Область","Доставим в любой посёлок")]
for grp,t in T2:
    ok = len(t)<=LIMITS['title2'] and t.count('!')<=1
    print(f"  {'✅' if ok else '❌'} {grp:22} {t!r} ({len(t)}/30)")
