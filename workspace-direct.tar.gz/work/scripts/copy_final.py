# -*- coding: utf-8 -*-
import os, sys, json
SK=os.path.join(os.environ.get('ARENA_WORKSPACE','"$ARENA_WORKSPACE"'),
  'extract/workspace/skills_repo/extracted1/skill_for_claude_code_yandex_direct-main/scripts')
sys.path.insert(0,SK)
from ads import validate_ad
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import OUT

ADS=[
 dict(key='M2_REST', name='М2. По видам — остаток (убираем лилии)',
      title="Букеты орхидей и альстромерий", title2="Экзотика. Доставка за 2 часа",
      text="Редкие цветы в наличии и под заказ. Доставка за 2 часа. От 2500 руб.",
      display_path="Орхидеи-альстромерии", path='/buketi-cvetov/'),
 dict(key='M24_HYDR', name='М2.4 Гортензии (цена 2000 по JSON-LD)',
      title="Букеты с гортензией в Раменском", title2="Доставка 2 часа. От 2000 руб",
      text="Объёмные букеты с гортензией: один цветок заменяет охапку. Доставка за 2 часа!",
      display_path="Гортензии", path='/po_cvetam/bukety-s-gortenziej/'),
 dict(key='M27_ROM', name='М2.7 Ромашки',
      title="Букеты с ромашками в Раменском", title2="Доставка 2 часа. От 2600 руб",
      text="Нежные букеты с ромашками. Соберём за 2 часа. Доставка по Раменскому!",
      display_path="Ромашки", path='/po_cvetam/buketi-s-romashkami/'),
 dict(key='M28_RAN', name='М2.8 Ранункулюсы',
      title="Букеты с ранункулюсами — Раменское", title2="Премиум-цветы. От 4250 руб",
      text="Ранункулюсы в наличии и под заказ. Сборка букета за 2 часа. Открытка в дар!",
      display_path="Ранункулюсы", path='/po_cvetam/bukety-s-ranunkulyusami/'),
 dict(key='M29_ORH', name='М2.9 Орхидеи',
      title="Букеты с орхидеей в Раменском", title2="Доставка 2 часа. От 2500 руб",
      text="Экзотические букеты с орхидеей. Соберём за 2 часа. Открытка в подарок!",
      display_path="Орхидеи", path='/po_cvetam/bukety-s-orhideej/'),
 dict(key='M210_ALS', name='М2.10 Альстромерии',
      title="Букеты с альстромерией — Раменское", title2="Стойкие цветы. От 2500 руб",
      text="Альстромерии стоят до 3 недель. Соберём букет за 2 часа. Доставка по Раменскому!",
      display_path="Альстромерии", path='/po_cvetam/bukety-s-alstromeriej/'),
]
allok=True
for a in ADS:
    errs=validate_ad(a,0)
    ok=not errs; allok&=ok
    print(f"{'✅' if ok else '❌'} {a['name']}")
    print(f"    T1 {len(a['title']):2}/56  T2 {len(a['title2']):2}/30  TX {len(a['text']):2}/81  DP {len(a['display_path']):2}/20")
    if errs: print("    ", "; ".join(errs))
print("\nВСЕ ВАЛИДНЫ:", allok)
json.dump(ADS, open(os.path.join(OUT,'ad_copy_final.json'),'w'), ensure_ascii=False, indent=1)
print("сохранено: work/analysis/ad_copy_final.json")
