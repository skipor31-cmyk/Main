# -*- coding: utf-8 -*-
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
ads=json.load(open(os.path.join(OUT,'live_ads_hrefs.json')))['Ads']
sl=sorted({(a.get('TextAd') or {}).get('SitelinkSetId') for a in ads if (a.get('TextAd') or {}).get('SitelinkSetId')})
print("sitelink sets:", len(sl))
try:
    r=c.call('adextensions','get',{'SelectionCriteria':{'Ids':sl},
        'FieldNames':['Id','Type','State','Status','Associated'],
        'SitelinksFieldNames':['Sitelinks']})
    json.dump(r, open(os.path.join(OUT,'live_sitelinks.json'),'w'), ensure_ascii=False, indent=1)
    sets=r.get('AdExtensions') or r.get('SitelinksSets') or []
    print("got:", len(sets))
    print(json.dumps(sets[:2], ensure_ascii=False, indent=1)[:1500])
except DirectError as e:
    print("ERR:", str(e)[:600])
