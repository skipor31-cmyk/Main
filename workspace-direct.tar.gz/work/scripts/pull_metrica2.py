# -*- coding: utf-8 -*-
import json, os, sys, urllib.parse, urllib.request, urllib.error, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG, OUT
TOK=CFG['token']; CID=CFG['metrica']['counter_id']
M=CFG['metrica']; GOALS=[M['primary_goal_id']]+list(M['secondary_goal_ids'])
BASE='https://api-metrika.yandex.net'
def q(params, tries=4):
    for t in range(tries):
        url=BASE+'/stat/v1/data?'+urllib.parse.urlencode(params, doseq=True)
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=90) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            body=e.read().decode()[:200]
            if '56' in body or 'limit' in body.lower(): time.sleep(5); continue
            return {'_error':body}
        except Exception as e:
            time.sleep(4)
    return {'_error':'retries exhausted'}
def save(n,d):
    p=os.path.join(OUT,n); json.dump(d,open(p,'w'),ensure_ascii=False,indent=1)
    print(f"  saved {n:32} {os.path.getsize(p)/1024:6.1f} KB")

print("[A] цели: reaches за 90 и 30 дней")
gsum={}
for g in GOALS:
    r90=q({'ids':CID,'metrics':f'ym:s:goal{g}reaches','date1':'90daysAgo','date2':'today','accuracy':'full'})
    r30=q({'ids':CID,'metrics':f'ym:s:goal{g}reaches','date1':'30daysAgo','date2':'today','accuracy':'full'})
    r7 =q({'ids':CID,'metrics':f'ym:s:goal{g}reaches','date1':'7daysAgo','date2':'today','accuracy':'full'})
    def m(r): 
        if '_error' in r: return None
        return (r.get('data') or [{}])[0].get('metrics',[0])[0]
    gsum[str(g)]={'d90':m(r90),'d30':m(r30),'d7':m(r7)}
    print(f"  goal {g}: 90d={m(r90)} 30d={m(r30)} 7d={m(r7)}")
save('m_goal_totals.json', gsum)

names={str(g['id']):g['name'] for g in json.load(open(os.path.join(OUT,'m_goals.json'))).get('goals',[])}
print("\n  (названия целей из config):")
for g in GOALS: print(f"    {g}: {names.get(str(g),'?')}")

print("\n[B] визиты по источникам (sourceEngine) 60 дней")
d=q({'ids':CID,'metrics':'ym:s:visits','dimensions':'ym:s:sourceEngine','date1':'60daysAgo','date2':'today',
     'sort':'-ym:s:visits','limit':30,'accuracy':'full'})
save('m_source_60d.json', d)
for r in d.get('data',[])[:15]:
    print(f"   {r['dimensions'][0]['name'][:34]:36} {r['metrics'][0]:8.0f}")

print("\n[C] визиты по дням × sourceEngine (30 дней)")
d=q({'ids':CID,'metrics':'ym:s:visits','dimensions':'ym:s:date,ym:s:sourceEngine','date1':'30daysAgo',
     'date2':'today','limit':1000,'accuracy':'full'})
save('m_day_source_30d.json', d)
print("   строк:", len(d.get('data',[])))

print("\n[D] устройства 60 дней")
d=q({'ids':CID,'metrics':'ym:s:visits,ym:s:bounceRate','dimensions':'ym:s:deviceCategory',
     'date1':'60daysAgo','date2':'today','accuracy':'full'})
save('m_devices_60d.json', d)
for r in d.get('data',[]):
    print(f"   {r['dimensions'][0]['name']:12} visits={r['metrics'][0]:7.0f} bounce={r['metrics'][1]:5.1f}%")

print("\n[E] визиты по неделям 120 дней")
d=q({'ids':CID,'metrics':'ym:s:visits,ym:s:pageviews,ym:s:bounceRate','dimensions':'ym:s:date',
     'date1':'120daysAgo','date2':'today','sort':'ym:s:date','limit':200,'accuracy':'full'})
save('m_by_day_120.json', d)
print("   дней:", len(d.get('data',[])))
print("\nDONE")
