# -*- coding: utf-8 -*-
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
AID=1922742232187391646
B='https://flowerpoetry.ru'
UTM='?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}&utm_content={ad_id}&utm_term={keyword}'
r=c.call('ads','get',{'SelectionCriteria':{'Ids':[AID]},'FieldNames':['Id','Status','State'],
   'TextAdFieldNames':['Title','Title2','Text','Href','Mobile','SitelinkSetId','AdExtensions','BusinessId','TrackingPhoneId','DisplayUrlPath']})
ta=r['Ads'][0]['TextAd']
print("ДО Href:", ta['Href'][:100])
tests={
 'только Href': {'Href': B+'/buketi-cvetov/'+UTM},
 'Title+Text+Href': {'Title':ta['Title'],'Text':ta['Text'],'Href':B+'/buketi-cvetov/'+UTM},
}
for name,p in tests.items():
    try:
        res=c.call('ads','update',{'Ads':[{'Id':AID,'TextAd':p}]})
        print(f"  ✅ {name}: OK -> {json.dumps(res,ensure_ascii=False)[:200]}")
        break
    except DirectError as e:
        print(f"  ❌ {name}: {str(e)[:200]}")
r2=c.call('ads','get',{'SelectionCriteria':{'Ids':[AID]},'FieldNames':['Id','Status','State'],
   'TextAdFieldNames':['Title','Title2','Text','Href','Mobile','SitelinkSetId','AdExtensions','BusinessId','TrackingPhoneId','DisplayUrlPath']})
ta2=r2['Ads'][0]['TextAd']
print("\nПОСЛЕ:")
for f in ['Title','Title2','Text','Href','Mobile','SitelinkSetId','BusinessId','TrackingPhoneId','DisplayUrlPath']:
    same = ta.get(f)==ta2.get(f)
    print(f"  {'SAME' if same else 'CHG '} {f:18} {str(ta2.get(f))[:95]}")
print("  AdExtensions:", len(ta2.get('AdExtensions') or []), "шт (было", len(ta.get('AdExtensions') or []), ")")
print("  Status:", ta and r['Ads'][0].get('Status'), '->', r2['Ads'][0].get('Status'), '| State:', r['Ads'][0].get('State'),'->',r2['Ads'][0].get('State'))
json.dump({'before':ta,'after':ta2}, open(os.path.join(OUT,'test_one_ad.json'),'w'), ensure_ascii=False, indent=1)
