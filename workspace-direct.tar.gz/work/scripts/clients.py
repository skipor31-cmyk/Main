import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, DirectError
c=client()
for m,p in [('get',{'SelectionCriteria':{},'FieldNames':['AccountId','AccountStatus','AccountType','Login','CountryCode','Currency','Timezone','Grants','GrantPermissions']}),
            ('get',{'SelectionCriteria':{},'FieldNames':['Login','AccountType','CountryCode','Currency','Grants']})]:
    try:
        print(json.dumps(c.call('clients',m,p), ensure_ascii=False, indent=1)[:1500]); break
    except DirectError as e:
        print("ERR:", str(e)[:300])
