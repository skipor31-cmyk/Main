# -*- coding: utf-8 -*-
"""Статистика 13-21.10: кампании по дням, группы, ключи, поисковые запросы."""
import json, os, sys, csv, io, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, CFG

c = client()

def report(rtype, fields, dfrom, dto, goals=None, filt=None):
    sel = {'DateFrom': dfrom, 'DateTo': dto, 'Filter': filt or []}
    rd = {'SelectionCriteria': sel, 'FieldNames': fields,
          'ReportName': f"{rtype}_{dfrom}_{dto}", 'ReportType': rtype,
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    if goals:
        rd['Goals'] = goals
        rd['AttributionModels'] = ['LSC']
    tsv = c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
    return list(csv.DictReader(io.StringIO(tsv), delimiter='\t'))

DFROM, DTO = '2026-10-13', '2026-10-21'
GOALS = [str(CFG['metrica']['primary_goal_id'])] + [str(g) for g in CFG['metrica']['secondary_goal_ids']]

jobs = [
    ('r21_campaign_by_day.tsv', 'CAMPAIGN_PERFORMANCE_REPORT',
     ['Date', 'CampaignId', 'CampaignName', 'Impressions', 'Clicks', 'Ctr', 'Cost', 'AvgCpc'],
     None),
    ('r21_adgroup.tsv', 'ADGROUP_PERFORMANCE_REPORT',
     ['CampaignId', 'AdGroupId', 'AdGroupName', 'Impressions', 'Clicks', 'Ctr', 'Cost'],
     [{'Field': 'CampaignId', 'Operator': 'EQUALS', 'Values': ['40732207']}]),
    ('r21_keyword.tsv', 'CRITERIA_PERFORMANCE_REPORT',
     ['CampaignId', 'AdGroupId', 'CriteriaId', 'Criteria', 'Impressions', 'Clicks', 'Cost'],
     [{'Field': 'CampaignId', 'Operator': 'EQUALS', 'Values': ['40732207']}]),
    ('r21_query.tsv', 'SEARCH_QUERY_PERFORMANCE_REPORT',
     ['CampaignId', 'AdGroupId', 'CriteriaId', 'Criteria', 'SearchPhrase', 'Impressions', 'Clicks', 'Cost'],
     [{'Field': 'CampaignId', 'Operator': 'EQUALS', 'Values': ['40732207']}]),
]

for name, rt, fields, filt in jobs:
    try:
        rows = report(rt, fields, DFROM, DTO, filt=filt)
        p = os.path.join(OUT, name)
        with open(p, 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=fields, delimiter='\t')
            w.writeheader(); w.writerows(rows)
        print(f"OK {name:28} rows={len(rows)}")
    except Exception as e:
        print(f"FAIL {name:28} {str(e)[:250]}")
    time.sleep(8)
print('DONE')
