#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Глубокая диагностика групп «Доставка цветов» — 21.10.2026."""
import json, sys, os
sys.path.insert(0, os.path.join('"$ARENA_WORKSPACE"/work/scripts'))
from cfg import client, OUT, CFG

c = client()
HEAD_GROUPS = [3688099772, 4166852642, 4166852644, 4166852655, 4166852705,
               4166852706, 4166852729, 4166852738, 4166852753, 4166852847,
               4166852849, 5806224423, 5806224424, 5806224425]

# 1. Кампания: стратегия, настройки, статус
r = c.call('campaigns', 'get', {
    'SelectionCriteria': {'Ids': [40732207]},
    'FieldNames': ['Id','Name','State','Status','StatusPayment','Statistics',
                   'DailyBudget','Funds','Currency','TimeTargeting'],
    'TextCampaignFieldNames': ['BiddingStrategy','Settings','PriorityGoals','CounterIds'],
})
camp = r.get('result',{}).get('Campaigns',[{}])[0]
json.dump(camp, open(os.path.join(OUT,'deep_campaign.json'),'w'), ensure_ascii=False, indent=1)
print('=== CAMPAIGN 40732207 ===')
for k in ['State','Status','StatusPayment','Statistics','DailyBudget']:
    print(k, ':', json.dumps(camp.get(k), ensure_ascii=False))
tc = camp.get('TextCampaign', camp)
print('BiddingStrategy:', json.dumps(tc.get('BiddingStrategy'), ensure_ascii=False))
print('Settings:', json.dumps(tc.get('Settings'), ensure_ascii=False))
print('PriorityGoals:', json.dumps(tc.get('PriorityGoals'), ensure_ascii=False))
print('CounterIds:', json.dumps(tc.get('CounterIds'), ensure_ascii=False))
tt = camp.get('TimeTargeting') or {}
sch = (tt.get('Schedule') or {}).get('Items') or []
if sch:
    print('TimeTargeting Mon:', sch[0])
