# -*- coding: utf-8 -*-
"""18.10: проверка (1) снят ли спецрежим записи, (2) отдаётся ли SEARCH_QUERY-отчёт."""
import json, os, sys, csv, io, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()

print("=== 1. ПРАВА НА ЗАПИСЬ ===")
try:
    r=c.call('campaigns','suspend',{'SelectionCriteria':{'Ids':[704507321]}})  # уже SUSPENDED = no-op
    print("  campaigns.suspend:", json.dumps(r,ensure_ascii=False)[:160])
except DirectError as e: print("  campaigns.suspend ERR:", str(e)[:160])
try:
    c.call('keywords','suspend',{'SelectionCriteria':{'Ids':[58168684647]}})   # пион — и есть цель
    print("  keywords.suspend: ✅ РАЗРЕШЕНО (пион приостановлен!)")
except DirectError as e: print("  keywords.suspend:", str(e)[:140])

print("\n=== 2. SEARCH_QUERY_PERFORMANCE_REPORT: подбор полей ===")
T=datetime.date(2026,10,17)
def rep(fields, days=90, goals=None):
    rd={'SelectionCriteria':{'DateFrom':(T-datetime.timedelta(days=days)).isoformat(),
                             'DateTo':T.isoformat(),'Filter':[]},
        'FieldNames':fields,'ReportName':'sq','ReportType':'SEARCH_QUERY_PERFORMANCE_REPORT',
        'DateRangeType':'CUSTOM_DATE','Format':'TSV','IncludeVAT':'YES'}
    if goals: rd['Goals']=goals; rd['AttributionModels']=['LSC']
    tsv=c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
    return list(csv.DictReader(io.StringIO(tsv), delimiter='\t'))
CANDS=[
 ['CampaignId','AdGroupId','SearchPhrase','Impressions','Clicks','Cost'],
 ['CampaignId','SearchPhrase','Impressions','Clicks','Cost'],
 ['SearchPhrase','Impressions','Clicks','Cost'],
 ['CampaignId','AdGroupId','Criteria','SearchPhrase','Impressions','Clicks','Cost'],
 ['SearchPhrase','Clicks'],
 ['Date','CampaignId','SearchPhrase','Impressions','Clicks','Cost'],
]
ok=None
for f in CANDS:
    try:
        rows=rep(f)
        print(f"  ✅ {f} -> строк {len(rows)}")
        ok=(f,rows); break
    except Exception as e:
        m=str(e)
        d=m[m.find('error_detail'):m.find('error_detail')+180] if 'error_detail' in m else m[:160]
        print(f"  ❌ {f}: {d}")
if ok:
    f,rows=ok
    p=os.path.join(OUT,'r_query_90d.tsv')
    with open(p,'w',newline='',encoding='utf-8') as fh:
        w=csv.DictWriter(fh,fieldnames=f,delimiter='\t',extrasaction='ignore'); w.writeheader(); w.writerows(rows)
    print(f"  сохранено {p} ({os.path.getsize(p)/1024:.0f} КБ, {len(rows)} строк)")
    for r in rows[:5]: print("   ", r)
