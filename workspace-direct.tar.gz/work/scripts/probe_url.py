# -*- coding: utf-8 -*-
import json, os, sys, urllib.parse, urllib.request, urllib.error, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; BASE='https://api-metrika.yandex.net'
def q(p):
    url=BASE+'/stat/v1/data?'+urllib.parse.urlencode(p, doseq=True)
    for t in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=90) as r:
                return 'OK', json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            b=e.read().decode()
            if e.code in (502,503): time.sleep(6); continue
            return f'ERR{e.code}', b[:170]
        except Exception: time.sleep(4)
    return 'ERR','retries'
print("=== какие метрики работают с ym:pv:URL ===")
for m in ['ym:pv:pageviews','ym:pv:exits','ym:pv:bounceRate','ym:pv:avgDuration',
          'ym:s:visits','ym:s:goal36895733reaches','ym:pv:goal36895733reaches',
          'ym:pv:goalreaches','ym:pv:goal168348169reaches']:
    st,r=q({'ids':CID,'metrics':m,'dimensions':'ym:pv:URL','date1':'14daysAgo','date2':'today','limit':2})
    print(f"  {st:6} {m:30} {str(r)[:95] if st!='OK' else 'OK'}")
print("\n=== ym:pv:URL + несколько измерений ===")
for d in ['ym:pv:URL,ym:s:date','ym:pv:URL,ym:s:deviceCategory','ym:pv:URL,ym:s:sourceEngine']:
    st,r=q({'ids':CID,'metrics':'ym:pv:pageviews','dimensions':d,'date1':'14daysAgo','date2':'today','limit':2})
    print(f"  {st:6} {d:44} {str(r)[:80] if st!='OK' else 'OK'}")
print("\n=== объём данных: URL с utm_term за 90 дней ===")
st,r=q({'ids':CID,'metrics':'ym:pv:pageviews','dimensions':'ym:pv:URL','date1':'90daysAgo','date2':'today','limit':10000,'accuracy':'full'})
if st=='OK':
    data=r.get('data') or []
    print("  всего URL-строк:", len(data), "| total:", r.get('totals'))
    u=[x for x in data if 'utm_term' in (x['dimensions'][0]['name'] or '')]
    print("  из них с utm_term:", len(u))
    for x in u[:6]: print("   ", x['dimensions'][0]['name'][:150], x['metrics'])
else: print("  ", st, str(r)[:200])
