# -*- coding: utf-8 -*-
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, DirectError
c=client()
for svc, params in [
  ('sitelinks', {'SelectionCriteria':{'Ids':[1384724168]},'FieldNames':['Id','Sitelinks']}),
  ('adextensions', {'SelectionCriteria':{'Ids':[1384724168]},'FieldNames':['Id','Type','State','Status','Associated']}),
]:
    try:
        r=c.call(svc,'get',params)
        print(f"=== {svc} OK ==="); print(json.dumps(r, ensure_ascii=False, indent=1)[:2500])
    except DirectError as e:
        print(f"=== {svc} ERR: {str(e)[:300]}")
