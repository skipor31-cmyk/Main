# -*- coding: utf-8 -*-
"""18.10, повторная проверка: какие операции записи разрешены СЕЙЧАС."""
import json, os, sys, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
print("Время проверки:", datetime.datetime.now().strftime('%d.%m.%Y %H:%M:%S'))
r=c.call('campaigns','get',{'SelectionCriteria':{'Ids':[40732207]},'FieldNames':['Id','State','Status','StatusClarification','StatusPayment']})
print("Кампания 40732207:", json.dumps(r['Campaigns'], ensure_ascii=False))
print("\n" + "="*94)
print(f"{'операция':52}{'результат':42}")
print("="*94)

TESTS=[
 # (название, сервис, метод, параметры, безопасен ли как no-op)
 ("campaigns.suspend (704507321 уже SUSPENDED)", 'campaigns','suspend',{'SelectionCriteria':{'Ids':[704507321]}}, True),
 ("campaigns.resume  — НЕ ВЫПОЛНЯЕМ (запустит расход)", None,None,None, False),
 ("campaigns.update  (no-op: то же имя)", 'campaigns','update',
    {'Campaigns':[{'Id':40732207,'Name':'[ПОИСК] Доставка Раменское'}]}, True),
 ("campaigns.update  (минус-фразы E9)", 'campaigns','update',
    {'Campaigns':[{'Id':40732207,'NegativeKeywords':{'Items':['тест_не_применять']}}]}, False),
 ("ads.update        (Href объявления)", 'ads','update',
    {'Ads':[{'Id':1922742232187391646,'TextAd':{'Title':'Купить букет цветов в Раменском',
     'Text':'Свежие букеты в наличии и на заказ. Соберём по вашему бюджету. Оплата картой!',
     'Href':'https://flowerpoetry.ru/katalog/?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}&utm_content={ad_id}&utm_term={keyword}'}}]}, True),
 ("keywords.suspend  (пион 58168684647)", 'keywords','suspend',{'SelectionCriteria':{'Ids':[58168684647]}}, True),
 ("ads.suspend       (объявление пионов)", 'ads','suspend',{'SelectionCriteria':{'Ids':[1922758453206718169]}}, True),
 ("adgroups.update   (переименование М2.4)", 'adgroups','update',
    {'AdGroups':[{'Id':5806400169,'Name':'М2.4 Пионы и гортензии'}]}, True),
 ("adgroups.add      (новая группа)", 'adgroups','add',
    {'AdGroups':[{'CampaignId':40732207,'Name':'__ТЕСТ_НЕ_СОЗДАВАТЬ__','RegionIds':[10750]}]}, False),
 ("keywords.add      (новый ключ)", 'keywords','add',{'Keywords':[{'Keyword':'__тест__','AdGroupId':5806400169}]}, False),
 ("sitelinks.add     (новый набор ссылок)", 'sitelinks','add',
    {'SitelinksSets':[{'Sitelinks':[{'Title':'Каталог букетов','Href':'https://flowerpoetry.ru/buketi-cvetov',
      'Description':'Красивые букеты на любой случай, от 2000 руб.'}]}]}, False),
 ("ads.moderate      (отправка в модерацию)", 'ads','moderate',{'SelectionCriteria':{'Ids':[1922742232187391646]}}, False),
 ("negativekeywordsharedsets.add", 'negativekeywordsharedsets','add',
    {'NegativeKeywordSharedSets':[{'Name':'__ТЕСТ__','NegativeKeywords':{'Items':['тест']}}]}, False),
]
ok=[]
for name, svc, method, params, safe in TESTS:
    if svc is None or not safe:
        print(f"{name:52}{'— пропущено (не no-op / опасно)':42}")
        continue
    try:
        res=c.call(svc, method, params)
        txt=json.dumps(res, ensure_ascii=False)
        warn='Warnings' in txt or 'уже остановлен' in txt
        print(f"{name:52}{'✅ РАЗРЕШЕНО' + (' (no-op)' if warn else ''):42}")
        ok.append(name)
        if not warn: print(f"{'':52}  ответ: {txt[:110]}")
    except DirectError as e:
        m=str(e)
        code='54 «Нет прав»' if ('code 54' in m or 'Нет прав' in m) else ('55 «Операция не найдена»' if 'code 55' in m else m[:40])
        print(f"{name:52}{'⛔ '+code:42}")
print("\n" + "="*94)
print(f"РАЗРЕШЕНО операций записи: {len(ok)} из {sum(1 for t in TESTS if t[4])} безопасных")
for o in ok: print("   ✅", o)
