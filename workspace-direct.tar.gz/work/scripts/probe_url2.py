# -*- coding: utf-8 -*-
import json, os, sys, urllib.parse, urllib.request, urllib.error, time, re, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG, OUT
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; BASE='https://api-metrika.yandex.net'
def q(p):
    url=BASE+'/stat/v1/data?'+urllib.parse.urlencode(p, doseq=True)
    for t in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=120) as r:
                return json.loads(r.read().decode())
        except Exception as e: time.sleep(5)
    return {}
d=q({'ids':CID,'metrics':'ym:pv:pageviews','dimensions':'ym:pv:URL','date1':'90daysAgo','date2':'today','limit':10000,'accuracy':'full'})
data=d.get('data') or []
json.dump(data, open(os.path.join(OUT,'m_urls_90d.json'),'w'), ensure_ascii=False, indent=1)
print('URL-строк:', len(data), '| просмотров всего:', d.get('totals'))
urls=[(x['dimensions'][0]['name'] or '', x['metrics'][0]) for x in data]
print('\n=== есть ли utm вообще ===')
ut=[(u,m) for u,m in urls if 'utm' in u.lower()]
print('  с utm:', len(ut), '| просмотров:', sum(m for _,m in ut))
for u,m in sorted(ut,key=lambda x:-x[1])[:25]: print(f'   {m:6.0f}  {u[:165]}')
print('\n=== с yclid / openstat / _openstat ===')
for pat in ['yclid','openstat','from=direct','yandex','campaign']:
    n=[(u,m) for u,m in urls if pat in u.lower()]
    print(f'  {pat:14} {len(n):4} URL, {sum(m for _,m in n):7.0f} просмотров')
print('\n=== ТОП-25 URL по просмотрам ===')
for u,m in sorted(urls,key=lambda x:-x[1])[:25]: print(f'   {m:7.0f}  {u[:150]}')
print('\n=== URL со знаком "?" (query строка сохранена?) ===')
qm=[(u,m) for u,m in urls if '?' in u]
print('  таких:', len(qm), '| просмотров:', sum(m for _,m in qm))
for u,m in sorted(qm,key=lambda x:-x[1])[:12]: print(f'   {m:6.0f}  {u[:160]}')
