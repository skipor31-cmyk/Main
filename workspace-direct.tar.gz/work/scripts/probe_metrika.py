# -*- coding: utf-8 -*-
import json, os, sys, urllib.parse, urllib.request, urllib.error
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; G=CFG['metrica']['primary_goal_id']
BASE='https://api-metrika.yandex.net'
def q(params):
    url=BASE+'/stat/v1/data?' + urllib.parse.urlencode(params, doseq=True)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'Authorization':f'OAuth {TOK}'}), timeout=60) as r:
            return 'OK', json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return 'ERR', e.read().decode()[:180]
    except Exception as e: return 'ERR', str(e)[:120]

print("=== МЕТРИКИ ЦЕЛЕЙ ===")
for m in [f'ym:s:goal{G}conversion', f'ym:s:goalDimension', f'ym:s:goal{G}reaches', 'ym:s:goalreaches',
          'ym:s:goalconversion', f'ym:ad:goal{G}conversion', 'ym:s:visits']:
    st,r=q({'ids':CID,'metrics':m,'date1':'30daysAgo','date2':'today'})
    val = (r.get('data') or [{}])[0].get('metrics') if st=='OK' else r.replace('\n',' ')[:110]
    print(f"  {st:4} {m:34} {val}")

print("\n=== ИЗМЕРЕНИЯ ===")
for d in ['ym:s:date','ym:s:source','ym:s:lastSign','ym:s:refererSource','ym:s:sourceEngine',
          'ym:ad:directCampaign','ym:ad:directCampaignID','ym:ad:directCampaignName','ym:ad:campaign',
          'ym:s:utmSource','ym:s:utmCampaign','ym:s:utmContent','ym:s:landingPage','ym:s:deviceCategory',
          'ym:pv:URL','ym:s:pageViews']:
    st,r=q({'ids':CID,'metrics':'ym:s:visits','dimensions':d,'date1':'7daysAgo','date2':'today','limit':3})
    if st=='OK':
        names=[x['dimensions'][0]['name'] for x in (r.get('data') or [])]
        print(f"  OK   {d:32} -> {names}")
    else:
        print(f"  ERR  {d:32} -> {r.replace(chr(10),' ')[:95]}")
