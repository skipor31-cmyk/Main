# -*- coding: utf-8 -*-
"""Проба: какие поля отдаёт API для каждого сервиса."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, DirectError

c = client()

PROBES = {
    'campaigns': {
        'svc': 'campaigns', 'method': 'get', 'key': 'Campaigns',
        'sel': {'Ids': [40732207]},
        'fields': ['Id', 'Name', 'Status', 'State', 'StatusClarification', 'Funds',
                   'DailyBudget', 'Currency', 'Type', 'StartDate', 'EndDate',
                   'NegativeKeywords', 'TimeTargeting', 'ClientInfo', 'Statistics',
                   'StatusPayment', 'Strategy', 'WeeklyBudget', 'StateClarification',
                   'TrackingParams', 'Blocked', 'Notification', 'SourceId',
                   'NegativeKeywordSharedSetIds', 'CreateTime', 'TimeZone'],
    },
    'adgroups': {
        'svc': 'adgroups', 'method': 'get', 'key': 'AdGroups',
        'sel': {'CampaignIds': [40732207]},
        'fields': ['Id', 'CampaignId', 'Name', 'Status', 'RegionIds', 'Type',
                   'NegativeKeywords', 'TrackingParams', 'MobileBidAdjustment',
                   'AutotargetingCategories', 'AutotargetingBrandOptions',
                   'PreferablyBidding', 'MaxClicksPerWeek', 'AutotargetingSettings',
                   'AutotargetingNegativeKeywords'],
    },
    'ads': {
        'svc': 'ads', 'method': 'get', 'key': 'Ads',
        'sel': {'CampaignIds': [40732207]},
        'fields': ['Id', 'AdGroupId', 'CampaignId', 'Status', 'State',
                   'StatusClarification', 'Type'],
        'sub': {'TextAdFieldNames': ['Title', 'Title2', 'Text', 'Href', 'Mobile',
                                     'SitelinkSetId', 'AdExtensionIds', 'BusinessId',
                                     'TrackingPhoneId', 'DisplayUrlPath', 'TrackingToken',
                                     'HrefCondition', 'VideoExtension', 'Features',
                                     'PriceExtension', 'MobileFeatures']},
    },
    'keywords': {
        'svc': 'keywords', 'method': 'get', 'key': 'Keywords',
        'sel': {'CampaignIds': [40732207]},
        'fields': ['Id', 'AdGroupId', 'CampaignId', 'Keyword', 'Status', 'State',
                   'Bid', 'ContextBid', 'StrategyPriority', 'AutotargetingCategories',
                   'AutotargetingBrandOptions', 'ServingStatus', 'StatisticsSearch'],
    },
}

for name, p in PROBES.items():
    ok, bad = [], []
    for f in p['fields']:
        params = {'SelectionCriteria': p['sel'], 'FieldNames': [f],
                  'Page': {'Limit': 1, 'Offset': 0}}
        params.update(p.get('sub', {}))
        try:
            c.call(p['svc'], p['method'], params)
            ok.append(f)
        except DirectError as e:
            bad.append((f, str(e).split('|')[0][:80]))
    print(f"\n=== {name} ===")
    print("  OK :", ', '.join(ok))
    print("  BAD:", ', '.join(f"{f}" for f, _ in bad))
    for f, m in bad:
        print(f"      - {f}: {m}")
