# -*- coding: utf-8 -*-
import json, os, sys, urllib.parse, urllib.request, urllib.error, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import CFG, OUT
TOK=CFG['token']; CID=CFG['metrica']['counter_id']; BASE='https://api-metrika.yandex.net'
goals=json.load(open(os.path.join(OUT,'m_goals.json'))).get('goals',[])
def q(metrics, d1='90daysAgo'):
    url=BASE+'/stat/v1/data?'+urllib.parse.urlencode({'ids':CID,'metrics':metrics,'date1':d1,'date2':'today','accuracy':'full'})
    for t in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':f'OAuth {TOK}'}),timeout=60) as r:
                d=json.loads(r.read().decode()); return (d.get('data') or [{}])[0].get('metrics',[0]*len(metrics.split(',')))
        except Exception as e: time.sleep(3)
    return None
print(f"{'ID цели':>11} | {'90д':>5} {'30д':>5} {'7д':>4} | название")
res={}
for g in goals:
    gid=g['id']
    m90=q(f'ym:s:goal{gid}reaches'); m30=q(f'ym:s:goal{gid}reaches','30daysAgo'); m7=q(f'ym:s:goal{gid}reaches','7daysAgo')
    if m90 is None: continue
    a,b,cc=m90[0],m30[0] if m30 else 0,m7[0] if m7 else 0
    res[str(gid)]={'name':g['name'],'type':g.get('type'),'d90':a,'d30':b,'d7':cc}
    if a or b or cc:
        print(f"{gid:>11} | {a:5.0f} {b:5.0f} {cc:4.0f} | {g['name'][:52]} ({g.get('type')})")
json.dump(res, open(os.path.join(OUT,'m_all_goals_90-30-7.json'),'w'), ensure_ascii=False, indent=1)
