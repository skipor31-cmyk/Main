#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Регионы групп, статусы объявлений, запросы 1-8 окт."""
import json, sys, os, csv, io, time
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client, OUT
from direct_api import DirectError

c = client()
HEAD = [3688099772,4166852642,4166852644,4166852655,4166852705,4166852706,
        4166852729,4166852738,4166852753,4166852847,4166852849,5806224423,
        5806224424,5806224425,5806224426,5806224429]

# 1. Регионы и минус-слова групп
r = c.call('adgroups', 'get', {
    'SelectionCriteria': {'Ids': HEAD, 'CampaignIds': ['40732207']},
    'FieldNames': ['Id','Name','Status','RegionIds','NegativeKeywords'],
})
ags = r.get('result',{}).get('AdGroups',[])
json.dump(ags, open(os.path.join(OUT,'deep_adgroups_regions.json'),'w'), ensure_ascii=False, indent=1)
print("=== РЕГИОНЫ ГРУПП ===")
for g in ags:
    regs = (g.get('RegionIds') or {}).get('Items') if isinstance(g.get('RegionIds'),dict) else g.get('RegionIds')
    nk = ((g.get('NegativeKeywords') or {}).get('Items') or [])
    print(f"{g['Id']} {g['Name'][:34]:34s} | status={g.get('Status')} | regions={regs} | group_negs={len(nk)}: {' '.join(nk[:12])}")

time.sleep(2)
# 2. Объявления head-групп: статусы
r2 = c.call('ads', 'get', {
    'SelectionCriteria': {'AdGroupIds': HEAD, 'CampaignIds': ['40732207'],
                          'States': ['ON','OFF','SUSPENDED'], 'Statuses': ['ACCEPTED','MODERATION','REJECTED','PREACCEPTED']},
    'FieldNames': ['Id','AdGroupId','Status','State','Type','StatusClarification'],
})
ads = r2.get('result',{}).get('Ads',[])
json.dump(ads, open(os.path.join(OUT,'deep_ads_head.json'),'w'), ensure_ascii=False, indent=1)
print("\n=== ОБЪЯВЛЕНИЯ HEAD-ГРУПП ===")
for a in ads:
    print(f"ad {a['Id']} | grp {a['AdGroupId']} | {a.get('State')}/{a.get('Status')} | {a.get('Type')} | {a.get('StatusClarification','')}")

time.sleep(2)
# 3. Словарь регионов — что за ID
reg_ids = sorted({int(x) for g in ags for x in ((g.get('RegionIds') or {}).get('Items') or g.get('RegionIds') or [])})
if reg_ids:
    r3 = c.call('dictionaries', 'get', {
        'DictionaryNames': ['GeoRegions'],
        'GeoRegionsSelectionCriteria': {'Ids': reg_ids},
    })
    regs = r3.get('result',{}).get('GeoRegions',[])
    print("\n=== РЕГИОНЫ КАМПАНИИ ===")
    for x in regs:
        print(x.get('Id'), x.get('Name'), '| parent:', x.get('ParentId'), '| type:', x.get('Type'))
