# -*- coding: utf-8 -*-
"""
A3: Второй заголовок (вариант комбинаторного объявления) для всех живых объявлений
кампании 40732207 через API v501 (в v5 комбинаторные объявления не редактируются —
ошибка 3500). + resume 6 объявлений в состоянии OFF (лилийное + 5 новых).

    python3 rollout_titles_v501.py           # DRY-RUN
    python3 rollout_titles_v501.py --apply
"""
import sys, json, os, time, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError

STATE_F = os.path.join(OUT, 'apply_state_21-10.json')
CAMPAIGN = 40732207
PEONY_AD = 1922758453206718169
LILY_AD  = 1922742232187391648
DONE_AD  = 1922742228964443637           # уже с 2 заголовками (тест)
OFF_ADS  = [1922742232187391648, 1924766071241969991,
            1924766607039074768, 1924766607039074769, 1924766607039074770, 1924766607039074771]
LILY_SPLIT = ['Букеты орхидей и альстромерий', 'Соберём под ваш бюджет']
HYDRANGEA_AD_ID = 1924766071241969991
HYDRANGEA_T2 = 'Доставка 2 часа. От 2660 руб'
# новые группы: свой Заголовок 2 из ad_copy_final.json (не из общей таблицы префиксов)
NEW_GROUP_T2 = {'М2.7 Ромашки': 'M27_ROM', 'М2.8 Ранункулюсы': 'M28_RAN',
                'М2.9 Орхидеи': 'M29_ORH', 'М2.10 Альстромерии': 'M210_ALS'}
COPY = {x['key']: x for x in json.load(
    open(os.path.join(OUT, 'ad_copy_final.json'), encoding='utf-8'))}

TITLE2_BY_PREFIX = [
    ('Д4',  'Доставим в любой посёлок'),
    ('Д1',  'Привезём за 2 часа. От 2000 ₽'),
    ('Д2',  'Привезём за 2 часа. От 2000 ₽'),
    ('Д3',  'Доставим в любой посёлок'),
    ('Д5',  'Привезём за 2 часа. От 2000 ₽'),
    ('К1',  'Оплата картой. Открытка в дар'),
    ('К2',  'Оплата картой. Открытка в дар'),
    ('М1',  '150+ букетов в наличии'),
    ('М2',  'Соберём под ваш бюджет'),
    ('М3',  'Открытка в подарок'),
    ('М4',  'Композиции со сладостями'),
    ('Б1',  'Свои флористы. Доставка 2 ч'),
]

def title2_for(gname):
    for pfx, t2 in TITLE2_BY_PREFIX:
        if gname.startswith(pfx):
            return t2
    return None

def chunks(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i + n]

def main():
    apply_mode = '--apply' in sys.argv
    c = client()
    c501 = client(); c501.base = 'https://api.direct.yandex.com/json/v501/'

    state = json.load(open(STATE_F, encoding='utf-8')) if os.path.exists(STATE_F) else {'applied': []}
    if any(e['id'] == 'A3' for e in state.get('applied', [])):
        print('A3 уже выполнен ранее — выход.'); return

    groups = {g['Id']: g['Name'] for g in json.load(
        open(os.path.join(OUT, 'live_adgroups_21-10.json'), encoding='utf-8'))}
    # новые группы (созданы сегодня)
    ng = state.get('gid_by_name') or {}
    for name, gid in ng.items():
        groups.setdefault(gid, name)
    try:
        ng2 = json.load(open(os.path.join(OUT, 'apply_state_new_groups.json'), encoding='utf-8'))
        for name, gid in (ng2.get('gid_by_name') or {}).items():
            groups.setdefault(gid, name)
    except Exception:
        pass

    r = c501.call('ads', 'get', {'SelectionCriteria': {'CampaignIds': [CAMPAIGN],
                                                       'States': ['ON', 'OFF']},
                  'FieldNames': ['Id', 'AdGroupId', 'State', 'Status'],
                  'ResponsiveAdFieldNames': ['Titles']})
    ads = r.get('Ads', [])
    print('Объявлений ON/OFF:', len(ads))

    upd, rb = [], []
    for a in ads:
        aid = a['Id']
        if aid in (PEONY_AD, DONE_AD):
            continue
        ra = a.get('ResponsiveAd') or {}
        cur = [t['Title'] for t in (ra.get('Titles') or [])]
        gname = groups.get(a['AdGroupId'], '')
        if aid == LILY_AD:
            new_titles = LILY_SPLIT
        elif aid == HYDRANGEA_AD_ID:
            t2 = HYDRANGEA_T2
            if len(cur) >= 2 or t2 in cur:
                print(f'  = {aid}: уже ≥2 заголовков, пропуск'); continue
            new_titles = cur + [t2]
        else:
            if gname in NEW_GROUP_T2:
                t2 = COPY[NEW_GROUP_T2[gname]]['title2']
            else:
                t2 = title2_for(gname)
            if not t2:
                print(f'  ?? нет правила T2 для {aid} / {gname!r}'); continue
            if len(cur) >= 2 or t2 in cur:
                print(f'  = {aid}: уже ≥2 заголовков, пропуск'); continue
            new_titles = cur + [t2]
        if not cur:
            print(f'  !! {aid}: нет текущих заголовков, пропуск'); continue
        upd.append({'Id': aid, 'ResponsiveAd': {'Titles': new_titles}})
        rb.append({'Id': aid, 'ResponsiveAd': {'Titles': cur}})

    print(f'\nК обновлению: {len(upd)} объявлений')
    for u in upd[:5]:
        print('  ', u['Id'], u['ResponsiveAd']['Titles'])
    print('   ...')

    if not apply_mode:
        print('\n--- DRY-RUN ---'); return

    errs = []
    for batch in chunks(upd, 10):
        res = c501.call('ads', 'update', {'Ads': batch})
        for x in (res.get('UpdateResults') or []):
            if x.get('Errors'):
                errs.append((x.get('Id'), x['Errors']))
        time.sleep(1.0)
    if errs:
        print('ОШИБКИ:', errs[:6]); sys.exit(2)
    state.setdefault('applied', []).append(
        {'id': 'A3', 'desc': f'Второй заголовок (v501) у {len(upd)} объявлений',
         'ts': datetime.datetime.now().isoformat(),
         'rollback': {'svc501': 'ads', 'method': 'update', 'params': {'Ads': rb}}})
    json.dump(state, open(STATE_F, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'[A3] ✅ второй заголовок добавлен: {len(upd)} объявлений')

    # resume OFF-объявлений
    try:
        res = c.call('ads', 'resume', {'SelectionCriteria': {'Ids': OFF_ADS}})
        print('[R1] resume (v5):', json.dumps(res, ensure_ascii=False)[:400])
    except DirectError as e:
        print('[R1] v5 resume fail:', str(e)[:200], '→ пробую v501')
        res = c501.call('ads', 'resume', {'SelectionCriteria': {'Ids': OFF_ADS}})
        print('[R1] resume (v501):', json.dumps(res, ensure_ascii=False)[:400])
    state['applied'].append({'id': 'R1', 'desc': f'resume {len(OFF_ADS)} объявлений',
                             'ts': datetime.datetime.now().isoformat(),
                             'rollback': {'svc': 'ads', 'method': 'suspend',
                                          'params': {'SelectionCriteria': {'Ids': OFF_ADS}}}})
    json.dump(state, open(STATE_F, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('✅ ГОТОВО')

if __name__ == '__main__':
    main()
