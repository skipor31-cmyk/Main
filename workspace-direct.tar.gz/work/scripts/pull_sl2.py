# -*- coding: utf-8 -*-
import json, os, sys, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
ads=json.load(open(os.path.join(OUT,'live_ads_hrefs.json')))['Ads']
ags=json.load(open(os.path.join(OUT,'live_adgroups.json')))['AdGroups']
gname={g['Id']:g['Name'] for g in ags}
sl=sorted({(a.get('TextAd') or {}).get('SitelinkSetId') for a in ads if (a.get('TextAd') or {}).get('SitelinkSetId')})
out=[]
for i in range(0,len(sl),50):
    out += c.call('sitelinks','get',{'SelectionCriteria':{'Ids':sl[i:i+50]},
                  'FieldNames':['Id','Sitelinks']}).get('SitelinksSets',[])
json.dump({'SitelinksSets':out}, open(os.path.join(OUT,'live_sitelinks.json'),'w'), ensure_ascii=False, indent=1)
print("наборов получено:", len(out))

act=[a for a in ads if a.get('State')!='ARCHIVED']
used=collections.Counter((a.get('TextAd') or {}).get('SitelinkSetId') for a in act)
print("\n=== НАБОРЫ, ИСПОЛЬЗУЕМЫЕ НЕАРХИВНЫМИ ОБЪЯВЛЕНИЯМИ ===")
byid={s['Id']:s for s in out}
for sid,n in used.most_common():
    s=byid.get(sid)
    print(f"\n● набор {sid} — используется в {n} неархивных объявлениях")
    if not s: print("   (не получен)"); continue
    for l in s.get('Sitelinks') or []:
        print(f"   {l.get('Title')!r:32} -> {l.get('Href')}")
    grps=sorted({gname.get(a['AdGroupId']) for a in act if (a.get('TextAd') or {}).get('SitelinkSetId')==sid})
    print("   группы:", ', '.join(str(x) for x in grps[:12]) + (' …' if len(grps)>12 else ''))
