# -*- coding: utf-8 -*-
"""Диагностика 19.10, часть 4: статистика включая сегодня + Метрика + v4 баланс."""
import json, os, sys, csv, io, urllib.request, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, CFG, DirectError

c = client()
CID = 40732207
TOK = CFG['token']
COUNTER = str(CFG['metrica']['counter_id'])

def rep(rtype, fields, dfrom, dto, filt=None):
    rd = {'SelectionCriteria': {'DateFrom': dfrom, 'DateTo': dto, 'Filter': filt or []},
          'FieldNames': fields, 'ReportName': 'diag4', 'ReportType': rtype,
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    tsv = c.report(rd, skip_report_header=True, skip_column_header=False,
                   skip_report_summary=True)
    return list(csv.DictReader(io.StringIO(tsv), delimiter='\t'))

print("=" * 70)
print("A. ОТЧЁТ 16–19.10 (включая СЕГОДНЯ) по всем кампаниям")
print("=" * 70)
try:
    rows = rep('CAMPAIGN_PERFORMANCE_REPORT',
               ['Date', 'CampaignId', 'CampaignName', 'Impressions', 'Clicks', 'Cost'],
               '2026-10-16', '2026-10-19')
    if not rows:
        print("  *** НОЛЬ СТРОК — ни одного показа/клика/расхода 16–19.10 ***")
    for r_ in sorted(rows, key=lambda x: x.get('Date', '')):
        print(f"  {r_.get('Date')} id={r_.get('CampaignId')} imp={r_.get('Impressions')} "
              f"clk={r_.get('Clicks')} cost={r_.get('Cost')}")
except DirectError as e:
    print("  ERR:", str(e)[:250])

print()
print("A2. Тот же отчёт за 09–19.10 (последний день с данными):")
try:
    rows = rep('CAMPAIGN_PERFORMANCE_REPORT',
               ['Date', 'CampaignId', 'Impressions', 'Clicks', 'Cost'],
               '2026-10-09', '2026-10-19')
    if not rows:
        print("  *** НОЛЬ СТРОК за 09–19.10 ***")
    for r_ in sorted(rows, key=lambda x: (x.get('Date', ''), x.get('CampaignId', ''))):
        print(f"  {r_.get('Date')} id={r_.get('CampaignId')} imp={r_.get('Impressions')} "
              f"clk={r_.get('Clicks')} cost={r_.get('Cost')}")
except DirectError as e:
    print("  ERR:", str(e)[:250])

def met(q):
    p = dict(q)
    p.setdefault('ids', COUNTER)
    p.setdefault('direct_client_logins', 'skipor31')
    p.setdefault('accuracy', 'full')
    url = 'https://api-metrika.yandex.net/stat/v1/data?' + urllib.parse.urlencode(p, doseq=True)
    try:
        with urllib.request.urlopen(urllib.request.Request(
                url, headers={'Authorization': f'OAuth {TOK}'}), timeout=90) as r:
            return json.loads(r.read().decode()), None
    except Exception as e:
        body = ''
        try:
            body = e.read().decode()[:250]
        except Exception:
            pass
        return None, f"{e!r} {body}"

print()
print("=" * 70)
print("B. МЕТРИКА: визиты с Директа по дням, 12–19.10")
print("=" * 70)
d, err = met({'metrics': 'ym:ad:visits,ym:ad:clicks,ym:ad:RUBConvertedAdCost',
              'dimensions': 'ym:ad:date',
              'date1': '2026-10-12', 'date2': '2026-10-19'})
if err:
    print("  ERR:", err[:300])
else:
    rows = d.get('data') or []
    if not rows:
        print("  *** нет строк: с Директа не было НИ ОДНОГО визита 12–19.10 ***")
    for r_ in rows:
        m = r_['metrics']
        print(f"  {r_['dimensions'][0]['name']}: визиты={m[0]:.0f} клики={m[1]:.0f} расход={m[2]:.2f}")
    print("  totals:", d.get('totals'))

print()
print("=" * 70)
print("C. МЕТРИКА: ВСЕ визиты на сайт по дням + источники, 12–19.10")
print("=" * 70)
d, err = met({'metrics': 'ym:s:visits', 'dimensions': 'ym:s:date',
              'date1': '2026-10-12', 'date2': '2026-10-19'})
if err:
    print("  ERR:", err[:300])
else:
    for r_ in (d.get('data') or []):
        print(f"  {r_['dimensions'][0]['name']}: визитов={r_['metrics'][0]:.0f}")

d, err = met({'metrics': 'ym:s:visits', 'dimensions': 'ym:s:source,ym:s:medium',
              'date1': '2026-10-16', 'date2': '2026-10-19', 'limit': 30,
              'sort': '-ym:s:visits'})
if err:
    print("  источники ERR:", err[:300])
else:
    print("  источники 16–19.10:")
    for r_ in (d.get('data') or []):
        dims = [x['name'] for x in r_['dimensions']]
        print(f"    {dims[0]} / {dims[1]}: {r_['metrics'][0]:.0f}")

print()
print("=" * 70)
print("D. v4 GetClientInfo — сырой ответ (баланс)")
print("=" * 70)
for body in [{'method': 'GetClientInfo', 'param': 'skipor31'},
             {'method': 'GetClientInfo', 'param': None}]:
    try:
        req = urllib.request.Request(
            'https://api.direct.yandex.com/live/v4/json',
            data=json.dumps(body).encode(), method='POST',
            headers={'Authorization': 'OAuth ' + TOK, 'Client-Login': 'skipor31',
                     'Content-Type': 'application/json', 'Accept-Language': 'ru'})
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode()
        print(f"  param={body.get('param')!r}: {raw[:600]}")
    except Exception as e:
        det = ''
        try:
            det = e.read().decode()[:300]
        except Exception:
            pass
        print(f"  param={body.get('param')!r} ERR: {e!r} {det}")
