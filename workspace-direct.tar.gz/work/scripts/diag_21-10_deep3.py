#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Таймлайн ключа 20363191489 + по дням окт 1-12 по группам + запросы сентября."""
import json, sys, os, csv, io, time
sys.path.insert(0, '"$ARENA_WORKSPACE"/work/scripts')
from cfg import client, OUT
from direct_api import DirectError

c = client()

def rep(rtype, fields, dfrom, dto, tag, filt=None):
    fn = os.path.join(OUT, f'deep_{tag}.tsv')
    if os.path.exists(fn) and os.path.getsize(fn) > 50:
        print(tag, 'exists, skip'); return
    sel = {'DateFrom': dfrom, 'DateTo': dto, 'Filter': filt or []}
    rd = {'SelectionCriteria': sel, 'FieldNames': fields,
          'ReportName': f'deep_{tag}', 'ReportType': rtype,
          'DateRangeType': 'CUSTOM_DATE', 'Format': 'TSV', 'IncludeVAT': 'YES'}
    for attempt in range(8):
        try:
            tsv = c.report(rd, skip_report_header=True, skip_column_header=False, skip_report_summary=True)
            open(fn,'w').write(tsv)
            print(tag, 'rows:', len(tsv.splitlines())); return
        except DirectError as e:
            if '56' in str(getattr(e,'code','')) or 'Превышен лимит' in str(e):
                print(tag, 'rate-limit wait 15s'); time.sleep(15); continue
            raise

# 1. Таймлайн главного ключа Д1 (15 авг — 21 окт), по дням
rep('CRITERIA_PERFORMANCE_REPORT',
    ['Date','CriteriaId','Criteria','Impressions','Clicks','Cost'],
    '2026-08-15','2026-10-21','key20363_timeline',
    [{'Field':'CampaignId','Operator':'EQUALS','Values':['40732207']},
     {'Field':'AdGroupId','Operator':'EQUALS','Values':['4166852642']}])
# 2. Группы по дням 1-12 окт (всплеск)
rep('ADGROUP_PERFORMANCE_REPORT',
    ['Date','AdGroupName','Impressions','Clicks','Cost'],
    '2026-10-01','2026-10-12','agday_oct1',
    [{'Field':'CampaignId','Operator':'EQUALS','Values':['40732207']}])
# 3. Поисковые запросы сентября (что реально матчил Д1)
rep('SEARCH_QUERY_PERFORMANCE_REPORT',
    ['Query','MatchedKeyword','AdGroupName','Impressions','Clicks','Cost'],
    '2026-09-01','2026-09-30','query_sep',
    [{'Field':'CampaignId','Operator':'EQUALS','Values':['40732207']}])
