# -*- coding: utf-8 -*-
"""Проверка реального спроса (keywordsresearch.hasSearchVolume) по кандидатам в ключи."""
import json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cfg import client, OUT, DirectError
c=client()
SEEDS=['ромашки','ромашек','ранункулюсы','ранункулюсов','лютики','орхидеи','орхидея','орхидей',
       'альстромерия','альстромерии','альстромерий','гортензия','гортензии','сухоцветы']
REGIONS={'Раменское':[10750],'Жуковский':[20571],'Москва':[213],'Россия':[1]}
CAND=[]
for b in SEEDS:
    CAND += [f'букет {b}', f'купить {b}', f'{b} купить', f'букет из {b}', f'{b} с доставкой',
             f'купить {b} раменское', f'букет {b} раменское', f'{b} цена', f'{b} недорого',
             f'доставка {b} раменское', f'{b} раменское', f'цветы {b}', f'заказать {b}',
             f'{b} доставка', f'букет {b} купить', f'{b} жуковский']
CAND=list(dict.fromkeys(CAND))
print(f"кандидатов: {len(CAND)}")

def probe(rids):
    out={}
    for i in range(0,len(CAND),100):
        try:
            r=c.call('keywordsresearch','hasSearchVolume',{
                'SelectionCriteria':{'RegionIds':rids,'Keywords':CAND[i:i+100]},
                'FieldNames':['Keyword','AllDevices']})
            for x in (r.get('HasSearchVolumeResults') or []):
                out[x.get('Keyword')]=x.get('AllDevices')
        except DirectError as e:
            print("   ERR:", str(e)[:180]); return out
        time.sleep(1)
    return out

res={}
for name,rids in REGIONS.items():
    res[name]=probe(rids)
    yes=sum(1 for v in res[name].values() if v=='YES')
    print(f"  {name:12} id={rids}: ответов {len(res[name])}, со спросом {yes}")
json.dump(res, open(os.path.join(OUT,'demand_new_groups.json'),'w'), ensure_ascii=False, indent=1)

RA,MSK,RF,ZH=res['Раменское'],res['Москва'],res['Россия'],res['Жуковский']
Y=lambda d,k: d.get(k)=='YES'
print("\n=== ✅ ЕСТЬ СПРОС В РАМЕНСКОМ (брать в работу) ===")
n=0
for k in CAND:
    if Y(RA,k):
        n+=1
        print(f"  {k:40} Раменское=YES  Жуковский={'YES' if Y(ZH,k) else 'нет':5}  Москва={'YES' if Y(MSK,k) else 'нет':5}  Россия={'YES' if Y(RF,k) else 'нет'}")
print(f"  итого: {n}")
print("\n=== 🟡 НЕТ в Раменском, но ЕСТЬ в Москве или России ===")
m=0
for k in CAND:
    if not Y(RA,k) and (Y(MSK,k) or Y(RF,k)):
        m+=1
        if m<=28: print(f"  {k:40} Москва={'YES' if Y(MSK,k) else 'нет':5} Россия={'YES' if Y(RF,k) else 'нет'}")
print(f"  итого: {m}")
print("\n=== ⬜ НЕТ СПРОСА НИГДЕ (не создавать) ===")
z=[k for k in CAND if not any(Y(res[g],k) for g in REGIONS)]
print(f"  итого: {len(z)}  напр.: {z[:10]}")
