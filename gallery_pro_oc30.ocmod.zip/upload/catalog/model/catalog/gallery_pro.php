<?php
class ModelCatalogGalleryPro extends Model {
	public function updateViewed($gallery_pro_id) {
		$this->db->query("UPDATE " . DB_PREFIX . "gallery_pro SET viewed = (viewed + 1) WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");
	}
	public function getGalleryPro($gallery_pro_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "gallery_pro gp 
		LEFT JOIN " . DB_PREFIX . "gallery_pro_description gpd 
		ON (gp.gallery_pro_id = gpd.gallery_pro_id) 
		LEFT JOIN " . DB_PREFIX . "gallery_pro_to_store gps 
		ON (gp.gallery_pro_id = gps.gallery_pro_id) 
		WHERE gp.gallery_pro_id = '" . (int)$gallery_pro_id . "' 
		AND gpd.language_id = '" . (int)$this->config->get('config_language_id') . "' 
		AND gps.store_id = '" . (int)$this->config->get('config_store_id') . "' 
		AND gp.status = '1'");

		return $query->row;
	}

	public function getGalleryPros($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "gallery_pro gp 
		LEFT JOIN " . DB_PREFIX . "gallery_pro_description gpd 
		ON (gp.gallery_pro_id = gpd.gallery_pro_id) 
		LEFT JOIN " . DB_PREFIX . "gallery_pro_to_store gps 
		ON (gp.gallery_pro_id = gps.gallery_pro_id) 
		WHERE gpd.language_id = '" . (int)$this->config->get('config_language_id') . "' 
		AND gps.store_id = '" . (int)$this->config->get('config_store_id') . "' 
		AND gp.status = '1'";

		$sort_data = array(
			'gpd.name',
			'gp.sort_order', 
			'gp.date_added',
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			if ($data['sort'] == 'gpd.name' || $data['sort'] == 'gp.date_added') {
				$sql .= " ORDER BY LCASE(" . $data['sort'] . ")";
			} else {
				$sql .= " ORDER BY " . $data['sort'];
			}
		} else {
			$sql .= " ORDER BY gp.sort_order";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}


	public function getGalleryGroup($gallery_pro_id) {
		$gallery_group_data = array();
		

			$gallery_group_query = $this->db->query("SELECT gpg.gallery_pro_group_id, gpg.type, gpg.carousel, gpg.style, gpgd.name, gpgd.description
				FROM " . DB_PREFIX . "gallery_pro_image gpi 
				LEFT JOIN " . DB_PREFIX . "gallery_pro_group gpg 
				ON (gpi.gallery_pro_group_id = gpg.gallery_pro_group_id) 
				LEFT JOIN " . DB_PREFIX . "gallery_pro_group_description gpgd 
				ON (gpg.gallery_pro_group_id = gpgd.gallery_pro_group_id)
				WHERE gpi.gallery_pro_id = '" . (int)$gallery_pro_id . "' 
				AND gpgd.language_id = '" . (int)$this->config->get('config_language_id') . "'
				AND gpg.status = '1'
				GROUP BY gpg.gallery_pro_group_id 
				ORDER BY gpg.sort_order");

		foreach ($gallery_group_query->rows as $gallery_pro_group) {
			$product_gallery_data = array();
			
				$product_gallery_query = $this->db->query("SELECT gpg.gallery_pro_group_id, gpg.img_width, gpg.img_height, gpg.img_width_big, gpg.img_height_big, gpi.text, gpi.video, gpi.photo, gpi.dislikes, gpi.likes, gpi.id 
				FROM " . DB_PREFIX . "gallery_pro_image gpi 
				LEFT JOIN " . DB_PREFIX . "gallery_pro_group gpg 
				ON (gpi.gallery_pro_group_id = gpg.gallery_pro_group_id) 
				WHERE gpi.gallery_pro_id = '" . (int)$gallery_pro_id . "' 
				AND gpi.gallery_pro_group_id = '" . (int)$gallery_pro_group['gallery_pro_group_id'] . "' 
				ORDER BY gpi.sort_order");

				foreach ($product_gallery_query->rows as $product_gallery) {
					$photo_uns = unserialize($product_gallery['text']);
					
					if ($photo_uns) {
						$text = $photo_uns[$this->config->get('config_language_id')];
					}
					if ($this->config->get('module_gallery_pro_like') == 3){
						$like_info = $product_gallery['likes'] - $product_gallery['dislikes'];
					} else {
						$like_info = $product_gallery['likes'];
					}
					
					$product_gallery_data[] = array(
						'id' 				=> $product_gallery['id'],
						'img_width'			=> $product_gallery['img_width'],
						'img_height'		=> $product_gallery['img_height'],
						'img_width_big'		=> $product_gallery['img_width_big'],
						'img_height_big'	=> $product_gallery['img_height_big'],
						'text'				=> $text,
						'gallery_pro_group_id' 	=> $product_gallery['gallery_pro_group_id'],
						'likes'         	=> $like_info,
						'video'         	=> $product_gallery['video'],
						'photo'         	=> $product_gallery['photo']
					);
				}
				
			$gallery_group_data[] = array(
				'gallery_pro_group_id'	=> $gallery_pro_group['gallery_pro_group_id'],
				'product_gallery_data'=> $product_gallery_data,
				'description'		=> $gallery_pro_group['description'],
				'name'				=> $gallery_pro_group['name'],
				'type'				=> $gallery_pro_group['type'],
				'style'         	=> $gallery_pro_group['style'],
				'carousel'         	=> $gallery_pro_group['carousel']				
			);
		}
		return $gallery_group_data;
	}
	
	public function getGalleryProLayoutId($gallery_pro_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_to_layout WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "' AND store_id = '" . (int)$this->config->get('config_store_id') . "'");

		if ($query->num_rows) {
			return $query->row['layout_id'];
		} else {
			return 0;
		}
	}
	
	public function getTotalGallery() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro gp LEFT JOIN " . DB_PREFIX . "gallery_pro_description gpd ON (gp.gallery_pro_id = gpd.gallery_pro_id) LEFT JOIN " . DB_PREFIX . "gallery_pro_to_store gps ON (gp.gallery_pro_id = gps.gallery_pro_id) WHERE gpd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND gps.store_id = '" . (int)$this->config->get('config_store_id') . "' AND gp.status = '1'");

		return $query->row['total'];
	}
	
	public function getGalleryRelatedProd($gallery_pro_id) {
		$product_data = array();
		
		$this->load->model('catalog/product');
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_product gpp LEFT JOIN " . DB_PREFIX . "product p ON (gpp.product_id = p.product_id) LEFT JOIN " . DB_PREFIX . "gallery_pro gp ON (gpp.gallery_pro_id = gp.gallery_pro_id) LEFT JOIN " . DB_PREFIX . "product_to_store gps ON (p.product_id = gps.product_id) WHERE gpp.gallery_pro_id = '" . (int)$gallery_pro_id . "' AND p.status = '1' AND gp.status_product = '1' AND p.date_available <= NOW() AND gps.store_id = '" . (int)$this->config->get('config_store_id') . "'");
		
		foreach ($query->rows as $result) { 
			$product_data[$result['product_id']] = $this->model_catalog_product->getProduct($result['product_id']);
		}

		return $product_data;
	}
	
	
	public function getGalleryInfo($id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "gallery_pro_image WHERE id = '" . (int)$id . "' ");

		return $query->row;
	}
	
	public function checkGalleryGuard($ip, $id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_guard WHERE ip = '" . $this->db->escape($ip) . "' AND id = '" . (int)$id . "'");

		return $query->rows;
	}

	public function addGalleryLike($data = array()) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_guard SET id = '" . (int)$data['id'] . "', ip = '" . $this->db->escape($data['ip']) . "'");

		$this->db->query("UPDATE " . DB_PREFIX . "gallery_pro_image SET likes = (likes + 1) WHERE id = '" . (int)$data['id'] . "'");
	}
	
	public function addGalleryDislike($data = array()) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_guard SET id = '" . (int)$data['id'] . "', ip = '" . $this->db->escape($data['ip']) . "'");

		$this->db->query("UPDATE " . DB_PREFIX . "gallery_pro_image SET dislikes = (dislikes + 1) WHERE id = '" . (int)$data['id'] . "'");
	}
	
	public function getGalleryProduct($data) {
		$gallery_data = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_product gpp LEFT JOIN " . DB_PREFIX . "gallery_pro gp ON (gpp.gallery_pro_id = gp.gallery_pro_id) LEFT JOIN " . DB_PREFIX . "gallery_pro_to_store gps ON (gp.gallery_pro_id = gps.gallery_pro_id) WHERE gpp.product_id = '" . (int)$data['product_id'] . "' AND gp.status = '1' AND gps.store_id = '" . (int)$this->config->get('config_store_id') . "'"); 

		foreach ($query->rows as $result) { 
			$gallery_data[$result['gallery_pro_id']] = $this->getGalleryPro($result['gallery_pro_id']);
		}

		return $gallery_data;

	}
	
	public function getGalleryTotalProduct($gallery_pro_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_product WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		return $query->row['total'];
	}
	
	public function getGalleryTotalImage($gallery_pro_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "' AND (photo <> '' AND photo <> 'no_image.png' AND photo <> 'no_image.jpg' AND photo IS NOT NULL) AND (video = '' OR video IS NULL)");

		return $query->row['total'];
	}
	
	public function getGalleryTotalVideo($gallery_pro_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "' AND (video <> '' AND video IS NOT NULL) ");

		return $query->row['total'];
	}
	
	public function getGalleryShort($gallery_pro_id, $gallery_pro_group_id) {
		$gallery_group_data = array();
		

			$gallery_group_query = $this->db->query("SELECT gpg.gallery_pro_group_id, gpg.type, gpg.carousel, gpg.style, gpgd.name, gpgd.description
				FROM " . DB_PREFIX . "gallery_pro_image gpi 
				LEFT JOIN " . DB_PREFIX . "gallery_pro_group gpg 
				ON (gpi.gallery_pro_group_id = gpg.gallery_pro_group_id) 
				LEFT JOIN " . DB_PREFIX . "gallery_pro_group_description gpgd 
				ON (gpg.gallery_pro_group_id = gpgd.gallery_pro_group_id)
				WHERE gpi.gallery_pro_id = '" . (int)$gallery_pro_id . "' 
				AND gpgd.language_id = '" . (int)$this->config->get('config_language_id') . "'
				AND gpg.status = '1'
				AND gpi.gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "'");

		foreach ($gallery_group_query->rows as $gallery_pro_group) {
			$product_gallery_data = array();
			
				$product_gallery_query = $this->db->query("SELECT gpg.gallery_pro_group_id, gpg.img_width, gpg.style, gpg.carousel, gpg.img_height, gpg.img_width_big, gpg.img_height_big, gpi.text, gpi.video, gpi.photo, gpi.dislikes, gpi.likes, gpi.id 
				FROM " . DB_PREFIX . "gallery_pro_image gpi 
				LEFT JOIN " . DB_PREFIX . "gallery_pro_group gpg 
				ON (gpi.gallery_pro_group_id = gpg.gallery_pro_group_id) 
				WHERE gpi.gallery_pro_id = '" . (int)$gallery_pro_id . "' 
				AND gpi.gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "' 
				ORDER BY gpi.sort_order");

				foreach ($product_gallery_query->rows as $product_gallery) {
					$photo_uns = unserialize($product_gallery['text']);
					
					if ($photo_uns) {
						$text = $photo_uns[$this->config->get('config_language_id')];
					}
					if ($this->config->get('module_gallery_pro_like') == 3){
						$like_info = $product_gallery['likes'] - $product_gallery['dislikes'];
					} else {
						$like_info = $product_gallery['likes'];
					}
					
					$product_gallery_data[] = array(
						'id' 				=> $product_gallery['id'],
						'img_width'			=> $product_gallery['img_width'],
						'img_height'		=> $product_gallery['img_height'],
						'img_width_big'		=> $product_gallery['img_width_big'],
						'img_height_big'	=> $product_gallery['img_height_big'],
						'text'				=> $text,
						'gallery_pro_group_id' 	=> $product_gallery['gallery_pro_group_id'],
						'likes'         	=> $like_info,
						'video'         	=> $product_gallery['video'],
						'photo'         	=> $product_gallery['photo']
					);
				}
				
			$gallery_group_data[] = array(
				'gallery_pro_group_id'	=> $gallery_pro_group['gallery_pro_group_id'],
				'product_gallery_data'=> $product_gallery_data,
				'description'		=> $gallery_pro_group['description'],
				'name'				=> $gallery_pro_group['name'],
				'type'				=> $gallery_pro_group['type'],
				'style'				=> $gallery_pro_group['style'],
				'carousel'			=> $gallery_pro_group['carousel']
				
			);
		}
		return $gallery_group_data;
	}
}