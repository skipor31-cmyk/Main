function like(id) {
	$.ajax({
		url: 'index.php?route=information/gallery_pro/like&id='+id,
		dataType: 'json',
		success: function(json) {
			$('.alert-gallery-info').remove();
			if (json['error']) {
				$('#likes-gallery_info-'+ id).parent().before('<div class="alert-gallery-info"></div>');
			setTimeout(function(object) {
					$('.alert-gallery-info').remove();
				}, 200, this);
			}
			
			if (json['success']) {
				$('#likes-gallery_info-'+ id).fadeOut(500, function() {
					$(this).text('' + json['likes'] + '').fadeToggle(500);
				});
			}
		}
	});
}
function dislike(id) {
	$.ajax({
		url: 'index.php?route=information/gallery_pro/dislike&id='+id,
		dataType: 'json',
		success: function(json) {
			$('.alert-gallery-info').remove();
			if (json['error']) {
				$('#likes-gallery_info-'+ id).parent().before('<div class="alert-gallery-info"></div>');
			setTimeout(function(object) {
					$('.alert-gallery-info').remove();
				}, 200, this);
			}
			
			if (json['success']) {
				$('#likes-gallery_info-'+ id).fadeOut(500, function() {
					$(this).text('' + json['likes'] + '').fadeToggle(500);
				});
			}
		}
	});
}