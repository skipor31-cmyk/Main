<?php
class ControllerInformationGalleryCode extends Controller {
	public function index($setting = array()) {
		if($this->config->get('module_gallery_pro_status')){
			$this->load->language('module/gallery_pro_product');
			
			$this->load->model('tool/image');

			$this->load->model('catalog/gallery_pro');


			if($this->config->get('module_gallery_pro_thumb_info_resize') == 1){
				$image_crop_thumb_info = 'resize';
			} else {
				$image_crop_thumb_info = 'cropsize';
			}
			if($this->config->get('module_gallery_pro_short_group_img_description')){
				$data['img_desc_status'] = true;
			} else {
				$data['img_desc_status'] = false;
			}
			if ($this->config->get('module_gallery_pro_like') == 3){
				$data['gallery_dislided'] = true;
			} else {
				$data['gallery_dislided'] = false;
			}
				
			if ($this->config->get('module_gallery_pro_like') != 1){
				$data['gallery_like'] = true;
				$this->document->addScript('catalog/view/theme/default/js/gallery_pro.js');
			} else {
				$data['gallery_like'] = false;
			}

			if (isset($setting['gallery_id'])) {
				$gallery_pro_id = (int)$setting['gallery_id'];
				$gallery_pro_group_id = (int)$setting['group_id'];
			} else {
				$gallery_pro_id = 0;
				$gallery_pro_id = 0;
			}
			
			
			$data['gallery'] = array();

			$gallery_result = $this->model_catalog_gallery_pro->getGalleryShort($gallery_pro_id, $gallery_pro_group_id);

			foreach ($gallery_result as $gallery) {
				$this->document->addStyle('catalog/view/theme/default/stylesheet/gallery_pro.css');
				$this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');
				$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');
				
				$product_gallery_data = array();

					foreach ($gallery['product_gallery_data'] as $product_gallery) {
							if ($product_gallery['video']) {
								$data['gallery_img'] 	= '//img.youtube.com/vi/' . $product_gallery['video'] . '/mqdefault.jpg';
								$data['gallery_big'] 	= 'https://www.youtube.com/watch?v='.$product_gallery['video'].'';
								$data['video'] 			= true;
							} else if ($product_gallery['photo']) {
								$data['gallery_img'] 	= $this->model_tool_image->$image_crop_thumb_info($product_gallery['photo'], $product_gallery['img_width'], $product_gallery['img_height']);
								$data['gallery_big'] 	= $this->model_tool_image->$image_crop_thumb_info($product_gallery['photo'], $product_gallery['img_width_big'], $product_gallery['img_height_big']);
								$data['video'] 			= false;
							} else {
								$data['gallery_img'] 	= '';
								$data['gallery_big'] 	= '';
								$data['video'] 		 	= false;
							}
							
						$product_gallery_data[] = array(
							'id'			=> $product_gallery['id'],
							'gallery_big'	=> $data['gallery_big'],
							'video'			=> $data['video'],
							'gallery_img' 	=> $data['gallery_img'],
							'text' 			=> $product_gallery['text'],
							'likes' 		=> $product_gallery['likes'],
						);
					}
					if($gallery['type'] == 0){
						$this->document->addStyle('catalog/view/javascript/jquery/owl-carousel/owl.carousel.css');
						$this->document->addScript('catalog/view/javascript/jquery/owl-carousel/owl.carousel.min.js');
					}
					if ($gallery['style']) {
						$style = $gallery['style'];
					} else {
						$style = 'col-sm-3';
					}
					if ($gallery['carousel']) {
						$carousel = $gallery['carousel'];
					} else {
						$carousel = '4';
					}
				$data['gallery'][] = array(
					'product_gallery_data' 		=> $product_gallery_data,
					'gallery_pro_group_id' 		=> $gallery['gallery_pro_group_id'],
					'type'                 		=> $gallery['type'],
					'style'                 	=> $style,
					'carousel'                 	=> $carousel,
					'name'                		=> $this->config->get('module_gallery_pro_short_group_name') ? '' . $gallery['name'] . '' : '',
					'description'           	=> $this->config->get('module_gallery_pro_short_group_description') ? '' . strip_tags(html_entity_decode($gallery['description'], ENT_QUOTES, 'UTF-8')) . '' : '',
				);

				return $this->load->view('information/gallery_code', $data);
			}
		}
	}
}