<?php
class ControllerInformationGalleryPro extends Controller {
	public function index() {
		
			$this->load->language('information/gallery_pro');
			
			if (isset($this->request->get['sort'])) {
				$sort = $this->request->get['sort'];
			} else {
				$sort = 'gp.sort_order';
			}

			if (isset($this->request->get['order'])) {
				$order = $this->request->get['order'];
			} else {
				$order = 'DESC';
			}

			if (isset($this->request->get['page'])) {
				$page = $this->request->get['page'];
			} else {
				$page = 1;
			}
			
			if ($this->config->get('module_gallery_pro_limited')) {
				$limited = $this->config->get('module_gallery_pro_limited');
			} else {
				$limited = $this->config->get('config_product_limit');
			}
			
			if (isset($this->request->get['limit'])) {
				$limit = (int)$this->request->get['limit'];
			} else {
				$limit = $limited;
			}

			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/home')
			);
			
			
			$this->load->model('catalog/gallery_pro');
			$this->load->model('tool/image');
			
			$this->document->addStyle('catalog/view/theme/default/stylesheet/gallery_pro.css');
			
				
			$filter_data = array(
				'start' => ($page - 1) * $limit,
				'limit' => $limit
			);
			
			if($this->config->get('module_gallery_pro_status')){
				$gallerys = $this->model_catalog_gallery_pro->getGalleryPros($filter_data);
			} else {
				$gallerys = false;
			}
			if($gallerys) {
					
				$lang = $this->config->get('config_language_id');

				if($this->config->get('module_gallery_pro_html')[$lang]['meta_title']){
					$this->document->setTitle($this->config->get('module_gallery_pro_html')[$lang]['meta_title'], ENT_QUOTES, 'UTF-8');
				} else { 
					$this->document->setTitle($this->language->get('heading_title'));
				}
				$this->document->setDescription($this->config->get('module_gallery_pro_html')[$lang]['meta_description'], ENT_QUOTES, 'UTF-8');
				$this->document->setKeywords($this->config->get('module_gallery_pro_html')[$lang]['meta_keyword'], ENT_QUOTES, 'UTF-8');

				if($this->config->get('module_gallery_pro_cms') == 1){
					
					if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
						$server = $this->config->get('config_ssl');
					} else {
						$server = $this->config->get('config_url');
					}
					
					if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
						$this->document->setOgImage($server . 'image/' . $this->config->get('config_logo'));
					} else {
						$data['logo'] = '';
					}
				}
			
				if($this->config->get('module_gallery_pro_html')[$lang]['meta_h1']){
					$data['heading_title'] = $this->config->get('module_gallery_pro_html')[$lang]['meta_h1'];
				} else { 
					$data['heading_title'] = $this->language->get('heading_title');
				}
				
				if($this->config->get('module_gallery_pro_html')[$lang]['description']){
					$data['description'] = html_entity_decode($this->config->get('module_gallery_pro_html')[$lang]['description'], ENT_QUOTES, 'UTF-8');
				} else { 
					$data['description'] = false;
				}	


				$data['breadcrumbs'][] = array(
					'text' => $data['heading_title'],
					'href' => $this->url->link('information/gallery_pro')
				);
				
				$data['gallery_pros'] = array();

				
				if($this->config->get('module_gallery_pro_thumb_info_resize') == 1){
					$image_crop_thumb_info = 'resize';
				} else {
					$image_crop_thumb_info = 'cropsize';
				}				
				
				foreach ($gallerys as $result) {
					if ($result['image']) {
						$image = $this->model_tool_image->$image_crop_thumb_info($result['image'], $this->config->get('module_gallery_pro_list_width'), $this->config->get('module_gallery_pro_list_height'));
					} else {
						$image = $this->model_tool_image->$image_crop_thumb_info('placeholder.png', $this->config->get('module_gallery_pro_list_width'), $this->config->get('module_gallery_pro_list_height'));
					}
					
					
					if($this->config->get('module_gallery_pro_gal_list_image')){
						$total_image = $this->model_catalog_gallery_pro->getGalleryTotalImage($result['gallery_pro_id']);
					} else {
						$total_image = false;
					}
					if($this->config->get('module_gallery_pro_gal_list_video')){
						$total_video = $this->model_catalog_gallery_pro->getGalleryTotalVideo($result['gallery_pro_id']);
					} else {
						$total_video = false;
					}	
					if($this->config->get('module_gallery_pro_gal_list_product')){
						$total_product = $this->model_catalog_gallery_pro->getGalleryTotalProduct($result['gallery_pro_id']);
					} else {
						$total_product = false;
					}	
					if($this->config->get('module_gallery_pro_gal_list_viewed')){
						$total_viewed 	= $result['viewed'];
					} else {
						$total_viewed 	= false;
					}
					
					$data['gallery_pros'][] = array(
						'name' 			=> $result['name'],
						'image' 		=> $image,
						'total_image' 	=> $total_image,
						'total_video'	=> $total_video,
						'total_product'	=> $total_product,
						'total_viewed'	=> $total_viewed,
						'description' 	=> utf8_substr(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8')), 0, 200) . '..',
						'image_alt' 	=> $result['image_alt'],
						'image_title' 	=> $result['image_title'],
						'href'  		=> $this->url->link('information/gallery_pro/info', 'gallery_pro_id=' . $result['gallery_pro_id'])
					);
				}
				
				
				$gallery_total = $this->model_catalog_gallery_pro->getTotalGallery();
				$url = '';
				$pagination = new Pagination();
				$pagination->total = $gallery_total;
				$pagination->page = $page;
				$pagination->limit = $limit;
				$pagination->url = $this->url->link('information/gallery_pro', $url . '&page={page}');

				$data['pagination'] = $pagination->render();

				$data['results'] = sprintf($this->language->get('text_pagination'), ($gallery_total) ? (($page - 1) * $limit) + 1 : 0, ((($page - 1) * $limit) > ($gallery_total - $limit)) ? $gallery_total : ((($page - 1) * $limit) + $limit), $gallery_total, ceil($gallery_total / $limit));

				if ($page == 1) {
					$this->document->addLink($this->url->link('information/gallery_pro', '', 'SSL'), 'canonical');
				} elseif ($page == 2) {
					$this->document->addLink($this->url->link('information/gallery_pro', '', 'SSL'), 'prev');
				} else {
					$this->document->addLink($this->url->link('information/gallery_pro', 'page='. ($page - 1), 'SSL'), 'prev');
				}

				if ($limit && ceil($gallery_total / $limit) > $page) {
					$this->document->addLink($this->url->link('information/gallery_pro', 'page='. ($page + 1), 'SSL'), 'next');
				}

				$data['column_left'] = $this->load->controller('common/column_left');
				$data['column_right'] = $this->load->controller('common/column_right');
				$data['content_top'] = $this->load->controller('common/content_top');
				$data['content_bottom'] = $this->load->controller('common/content_bottom');
				$data['footer'] = $this->load->controller('common/footer');
				$data['header'] = $this->load->controller('common/header');

				$this->response->setOutput($this->load->view('information/gallery_pro', $data));
			} else {
				$this->load->language('information/information');
				$data['breadcrumbs'][] = array(
					'text' => $this->language->get('text_error'),
					'href' => $this->url->link('information/gallery_pro')
				);

				$this->document->setTitle($this->language->get('text_error'));

				$data['heading_title'] = $this->language->get('text_error');

				$data['text_error'] = $this->language->get('text_error');

				$data['button_continue'] = $this->language->get('button_continue');

				$data['continue'] = $this->url->link('common/home');

				$this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');

				$data['column_left'] = $this->load->controller('common/column_left');
				$data['column_right'] = $this->load->controller('common/column_right');
				$data['content_top'] = $this->load->controller('common/content_top');
				$data['content_bottom'] = $this->load->controller('common/content_bottom');
				$data['footer'] = $this->load->controller('common/footer');
				$data['header'] = $this->load->controller('common/header');

				$this->response->setOutput($this->load->view('error/not_found', $data));
			}
		
	}
	
	public function info() {
		$this->load->language('information/gallery_pro');

		$this->load->model('catalog/product');
		$this->load->model('catalog/gallery_pro');
		$this->load->model('tool/image');
		
		$lang = $this->config->get('config_language_id');
		
		if($this->config->get('module_gallery_pro_html')[$lang]['meta_h1']){
			$data['heading_title_o'] = $this->config->get('module_gallery_pro_html')[$lang]['meta_h1'];
		} else { 
			$data['heading_title_o'] = $this->language->get('heading_title');
		}	
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $data['heading_title_o'],
			'href' => $this->url->link('information/gallery_pro')
		);
		
		$data['text_product'] = $this->language->get('text_product');
		$data['text_video'] = $this->language->get('text_video');
		$data['text_image'] = $this->language->get('text_image');
		$data['text_viewed'] = $this->language->get('text_viewed');


		if (isset($this->request->get['gallery_pro_id'])) {
			$gallery_pro_id = (int)$this->request->get['gallery_pro_id'];
		} else {
			$gallery_pro_id = 0;
		}
		if($this->config->get('module_gallery_pro_status')){
			$gallery_pro_info = $this->model_catalog_gallery_pro->getGalleryPro($gallery_pro_id);
		} else {
			$gallery_pro_info = false;
		}
		
		if ($gallery_pro_info) {
			$this->document->setTitle($gallery_pro_info['meta_title']);
			$this->document->setDescription($gallery_pro_info['meta_description']);
			$this->document->setKeywords($gallery_pro_info['meta_keyword']);
			$this->document->addLink($this->url->link('information/gallery_pro/info', 'gallery_pro_id=' . $gallery_pro_id), 'canonical');

			$data['breadcrumbs'][] = array(
				'text' => $gallery_pro_info['name'],
				'href' => $this->url->link('information/gallery_pro/info', 'gallery_pro_id=' .  $gallery_pro_id)
			);
			
			if($this->config->get('module_gallery_pro_gal_info_image')){
				$data['total_gallery_image'] = $this->model_catalog_gallery_pro->getGalleryTotalImage($gallery_pro_id);
			} else {
				$data['total_gallery_image'] = false;
			}
			if($this->config->get('module_gallery_pro_gal_info_video')){
				$data['total_gallery_video'] = $this->model_catalog_gallery_pro->getGalleryTotalVideo($gallery_pro_id);
			} else {
				$data['total_gallery_video'] = false;
			}	
			if($this->config->get('module_gallery_pro_gal_info_product')){
				$data['total_gallery_product'] = $this->model_catalog_gallery_pro->getGalleryTotalProduct($gallery_pro_id);
			} else {
				$data['total_gallery_product'] = false;
			}	
			if($this->config->get('module_gallery_pro_gal_info_viewed')){
				$data['total_gallery_viewed'] 	= $gallery_pro_info['viewed'];
			} else {
				$data['total_gallery_viewed'] 	= false;
			}
			
			if($this->config->get('module_gallery_pro_thumb_info_resize') == 1){
				$image_crop_thumb_info = 'resize';
			} else {
				$image_crop_thumb_info = 'cropsize';
			}
			
			if ($gallery_pro_info['image']) {
				$data['image'] = $this->model_tool_image->$image_crop_thumb_info($gallery_pro_info['image'], $this->config->get('module_gallery_pro_thumb_width'), $this->config->get('module_gallery_pro_thumb_height'));
				if($this->config->get('module_gallery_pro_cms') == 1){
					$this->document->setOgImage($data['image']);
				}
			} else {
				$data['image'] = $this->model_tool_image->$image_crop_thumb_info('placeholder.png', $this->config->get('module_gallery_pro_thumb_width'), $this->config->get('module_gallery_pro_thumb_height'));
			}

			$data['image_alt'] 	= $gallery_pro_info['image_alt'];
			$data['image_title'] 	= $gallery_pro_info['image_title'];
			
			$data['heading_title'] = $gallery_pro_info['name'];

			$data['button_continue'] = $this->language->get('button_continue');

			$data['description'] = html_entity_decode($gallery_pro_info['description'], ENT_QUOTES, 'UTF-8');

		
			$this->load->language('product/product');
			$data['text_tax'] = $this->language->get('text_tax');

			$data['button_cart'] = $this->language->get('button_cart');
			$data['button_wishlist'] = $this->language->get('button_wishlist');
			$data['button_compare'] = $this->language->get('button_compare');
			
			if($this->config->get('module_gallery_pro_prod_name')[$lang]['title']){
				$data['text_product_gallery'] = $this->config->get('module_gallery_pro_prod_name')[$lang]['title'];
			} else { 
				$data['text_product_gallery'] = $this->language->get('text_product_gallery');
			}
			
			$data['products'] = array();

			$results = $this->model_catalog_gallery_pro->getGalleryRelatedProd($this->request->get['gallery_pro_id']);

			foreach ($results as $product_info) {
				$product_info = $this->model_catalog_product->getProduct($product_info['product_id']);

				if ($product_info['image']) {
					$image = $this->model_tool_image->resize($product_info['image'], $this->config->get('module_gallery_pro_prod_width'), $this->config->get('module_gallery_pro_prod_height'));
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $this->config->get('module_gallery_pro_prod_width'), $this->config->get('module_gallery_pro_prod_height'));
				}

				if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($product_info['price'], $product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$product_info['special']) {
					$special = $this->currency->format($this->tax->calculate($product_info['special'], $product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$special = false;
				}

				if ($this->config->get('config_tax')) {
					$tax = $this->currency->format((float)$product_info['special'] ? $product_info['special'] : $product_info['price'], $this->session->data['currency']);
				} else {
					$tax = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = $product_info['rating'];
				} else {
					$rating = false;
				}
				if ($product_info) {
					$data['products'][] = array(
						'product_id'  => $product_info['product_id'],
						'thumb'       => $image,
						'name'        => $product_info['name'],
						'description' => utf8_substr(strip_tags(html_entity_decode($product_info['description'], ENT_QUOTES, 'UTF-8')), 0, $this->config->get($this->config->get('config_theme') . '_product_description_length')) . '..',
						'price'       => $price,
						'special'     => $special,
						'tax'         => $tax,
						'minimum'     => $product_info['minimum'] > 0 ? $product_info['minimum'] : 1,
						'rating'      => $rating,
						'href'        => $this->url->link('product/product', 'product_id=' . $product_info['product_id'])
					);
				}
			}	

			$this->load->model('catalog/gallery_pro');
			$this->load->model('tool/image');
			
			if($this->config->get('module_gallery_pro_thumb_info_resize') == 1){
				$image_crop_thumb_info = 'resize';
			} else {
				$image_crop_thumb_info = 'cropsize';
			}
			if ($this->config->get('module_gallery_pro_like') == 3){
				$data['gallery_dislided'] = true;
			} else {
				$data['gallery_dislided'] = false;
			}
				
			if ($this->config->get('module_gallery_pro_like') != 1){
				$data['gallery_like'] = true;
				$this->document->addScript('catalog/view/theme/default/js/gallery_pro.js');
			} else {
				$data['gallery_like'] = false;
			}
			$data['gallery'] = array();

			$gallery_result = $this->model_catalog_gallery_pro->getGalleryGroup($this->request->get['gallery_pro_id']);

			foreach ($gallery_result as $gallery) {
				$this->document->addStyle('catalog/view/theme/default/stylesheet/gallery_pro.css');
				$this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');
				$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');
			
				$product_gallery_data = array();
					foreach ($gallery['product_gallery_data'] as $product_gallery) {
							if ($product_gallery['video']) {
								$data['gallery_img'] 	= '//img.youtube.com/vi/' . $product_gallery['video'] . '/mqdefault.jpg';
								$data['gallery_big'] 	= 'https://www.youtube.com/watch?v='.$product_gallery['video'].'';
								$data['video'] 			= true;
							} else if ($product_gallery['photo']) {
								$data['gallery_img'] 	= $this->model_tool_image->$image_crop_thumb_info($product_gallery['photo'], $product_gallery['img_width'], $product_gallery['img_height']);
								$data['gallery_big'] 	= $this->model_tool_image->$image_crop_thumb_info($product_gallery['photo'], $product_gallery['img_width_big'], $product_gallery['img_height_big']);
								$data['video'] 			= false;
							} else {
								$data['gallery_img'] 	= '';
								$data['gallery_big'] 	= '';
								$data['video'] 		 	= false;
							} 
							
						$product_gallery_data[] = array(
							'id'			=> $product_gallery['id'],
							'gallery_big'	=> $data['gallery_big'],
							'video'			=> $data['video'],
							'gallery_img' 	=> $data['gallery_img'],
							'text' 			=> $product_gallery['text'],
							'likes' 		=> $product_gallery['likes'],
						);
					}
					if($gallery['type'] == 0){
						$this->document->addStyle('catalog/view/javascript/jquery/owl-carousel/owl.carousel.css');
						$this->document->addScript('catalog/view/javascript/jquery/owl-carousel/owl.carousel.min.js');
					}
					if ($gallery['style']) {
						$style = $gallery['style'];
					} else {
						$style = 'col-sm-3';
					}
					if ($gallery['carousel']) {
						$carousel = $gallery['carousel'];
					} else {
						$carousel = '4';
					}
				$data['gallery'][] = array(
					'product_gallery_data' 		=> $product_gallery_data,
					'gallery_pro_group_id' 		=> $gallery['gallery_pro_group_id'],
					'type'                 		=> $gallery['type'],
					'style'                 	=> $style,
					'carousel'                 	=> $carousel,
					'name'                		=> $gallery['name'],
					'description'           	=> strip_tags(html_entity_decode($gallery['description'], ENT_QUOTES, 'UTF-8')),
				);
			}
			
			$this->model_catalog_gallery_pro->updateViewed($this->request->get['gallery_pro_id']);
			
			$data['continue'] = $this->url->link('common/home');

			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');

			$this->response->setOutput($this->load->view('information/gallery_info', $data));
		} else {
			$this->load->language('information/information');
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_error'),
				'href' => $this->url->link('information/gallery_pro', 'gallery_pro_id=' . $gallery_pro_id)
			);

			$this->document->setTitle($this->language->get('text_error'));

			$data['heading_title'] = $this->language->get('text_error');

			$data['text_error'] = $this->language->get('text_error');

			$data['button_continue'] = $this->language->get('button_continue');

			$data['continue'] = $this->url->link('common/home');

			$this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');

			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');

			$this->response->setOutput($this->load->view('error/not_found', $data));
		}
	
	}

	public function like() {
		$json = array();

		if (isset($this->request->get['id'])) {
			$this->load->model('catalog/gallery_pro');

			$check_ip = $this->model_catalog_gallery_pro->checkGalleryGuard($this->request->server['REMOTE_ADDR'], $this->request->get['id']);
			
			if ($check_ip) {
				$json['error'] = $this->language->get('error_ip');
			}
			
			if (!isset($json['error'])) {
				$filter_data = array(
					'id' 	=> (int)$this->request->get['id'],
					'ip' 	=> $this->request->server['REMOTE_ADDR']
				);
				
				$this->model_catalog_gallery_pro->addGalleryLike($filter_data);
				
				$info_gallery = $this->model_catalog_gallery_pro->getGalleryInfo($this->request->get['id']);

				if ($this->config->get('module_gallery_pro_like') == 3){
					$total_likes = $info_gallery['likes'] - $info_gallery['dislikes'];
				} else {
					$total_likes = $info_gallery['likes'];
				}
				$json['likes'] = $total_likes;
				$json['success'] = $this->language->get('text_success');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function dislike() {
		$json = array();

		if (isset($this->request->get['id'])) {
			$this->load->model('catalog/gallery_pro');

			$check_ip = $this->model_catalog_gallery_pro->checkGalleryGuard($this->request->server['REMOTE_ADDR'], $this->request->get['id']);
			
			if ($check_ip) {
				$json['error'] = $this->language->get('error_ip');
			}
			
			if (!isset($json['error'])) {
				$filter_data = array(
					'id' 	=> (int)$this->request->get['id'],
					'ip' 	=> $this->request->server['REMOTE_ADDR']
				);
				
				$this->model_catalog_gallery_pro->addGalleryDislike($filter_data);
				
				$info_gallery = $this->model_catalog_gallery_pro->getGalleryInfo($this->request->get['id']);

				if ($this->config->get('module_gallery_pro_like') == 3){
					$total_likes = $info_gallery['likes'] - $info_gallery['dislikes'];
				} else {
					$total_likes = $info_gallery['likes'];
				}
				$json['likes'] = $total_likes;
				$json['success'] = $this->language->get('text_success');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}