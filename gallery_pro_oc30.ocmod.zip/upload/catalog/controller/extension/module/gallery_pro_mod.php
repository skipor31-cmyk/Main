<?php
class ControllerExtensionModuleGalleryProMod extends Controller {
	public function index($setting) {
		if($this->config->get('module_gallery_pro_status')){
			$this->load->language('extension/module/gallery_pro');
			
			$this->load->model('tool/image');
			
			
			if (isset($setting['module_description'][$this->config->get('config_language_id')])) {
				$data['heading_title'] = html_entity_decode($setting['module_description'][$this->config->get('config_language_id')]['title'], ENT_QUOTES, 'UTF-8');
			}
				
			if($this->config->get('gallery_pro_thumb_info_resize') == 1){
				$image_crop_thumb_info = 'resize';
			} else {
				$image_crop_thumb_info = 'cropsize';
			}
			
			if (!$setting['limit']) {
				$setting['limit'] = 4;
			}
			if ($setting['style']) {
				$data['style'] = $setting['style'];
			} else {
				$data['style'] = 'col-sm-12 col-sm-12 col-lg-6';
			}
			if ($setting['list'] == 0) {
				$data['list'] = true;
			} else {
				$data['list'] = false;
			}		
			$this->load->model('catalog/gallery_pro');

			$data['gallery_rps'] = array();

			if ($setting['type'] == 1) {
				$filter_data = array(
					'start'  		=> 0,
					'sort'  		=> 'gp.date_added',
					'order' 		=> 'ASC',
					'limit' 		=> $setting['limit'],
				); 
					
				$gallerys = $this->model_catalog_gallery_pro->getGalleryPros($filter_data);
				
				$results = array_slice($gallerys, 0, (int)$setting['limit']);
			} else {
				if (isset($this->request->get['product_id'])) {
					$filter_data = array(
						'product_id'  => $this->request->get['product_id'],
						'limit' => $setting['limit']
					);
					
					$gallerys = $this->model_catalog_gallery_pro->getGalleryProduct($filter_data);
					
					$results = array_slice($gallerys, 0, (int)$setting['limit']);
				} else {
					$results = false;
				}
			}

			
			if ($results) {
				$this->document->addStyle('catalog/view/theme/default/stylesheet/gallery_pro.css');
				foreach ($gallerys as $result) {
					if ($result['image']) {
						$image = $this->model_tool_image->$image_crop_thumb_info($result['image'], $setting['width'], $setting['height']);
					} else {
						$image = $this->model_tool_image->$image_crop_thumb_info('placeholder.png', $$setting['width'], $setting['height']);
					}
					
					
					if($this->config->get('gallery_pro_gal_mod_image')){
						$total_image = $this->model_catalog_gallery_pro->getGalleryTotalImage($result['gallery_pro_id']);
					} else {
						$total_image = false;
					}
					if($this->config->get('gallery_pro_gal_mod_video')){
						$total_video = $this->model_catalog_gallery_pro->getGalleryTotalVideo($result['gallery_pro_id']);
					} else {
						$total_video = false;
					}	
					if($this->config->get('gallery_pro_gal_mod_product')){
						$total_product = $this->model_catalog_gallery_pro->getGalleryTotalProduct($result['gallery_pro_id']);
					} else {
						$total_product = false;
					}	
					if($this->config->get('gallery_pro_gal_mod_viewed')){
						$total_viewed 	= $result['viewed'];
					} else {
						$total_viewed 	= false;
					}
					
					$data['gallery_pros'][] = array(
						'name' 			=> $result['name'],
						'image' 		=> $image,
						'total_image' 	=> $total_image,
						'total_video'	=> $total_video,
						'total_product'	=> $total_product,
						'total_viewed'	=> $total_viewed,
						'description' 	=> utf8_substr(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8')), 0, 200) . '..',
						'image_alt' 	=> $result['image_alt'],
						'image_title' 	=> $result['image_title'],
						'href'  		=> $this->url->link('information/gallery_pro/info', 'gallery_pro_id=' . $result['gallery_pro_id'])
					);
				}

				return $this->load->view('extension/module/gallery_pro_mod', $data);
			}
		}
	}
}