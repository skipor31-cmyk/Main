<?php
// Text
$_['heading_title']        				= 'Галерея';

$_['text_product_gallery']        		= 'Товары';
$_['text_product'] 						= 'Товаров:';
$_['text_video'] 						= 'Видео:';
$_['text_image'] 						= 'Фото:';
$_['text_viewed'] 						= 'Просмотров:';