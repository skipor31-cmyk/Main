<?php
// Text
$_['heading_title']        				= 'Gallery';

$_['text_product_gallery']        		= 'Product';
$_['text_product'] 						= 'Product:';
$_['text_video'] 						= 'Video:';
$_['text_image'] 						= 'Photo:';
$_['text_viewed'] 						= 'Views:';