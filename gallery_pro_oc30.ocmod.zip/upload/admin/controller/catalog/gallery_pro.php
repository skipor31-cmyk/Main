<?php
class ControllerCatalogGalleryPro extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/gallery_pro');

		$this->document->setTitle($this->language->get('text_gallery_pro'));

		$this->load->model('catalog/gallery_pro');

		$this->getList();
	}

	public function add() {
		$this->load->language('catalog/gallery_pro');

		$this->document->setTitle($this->language->get('text_gallery_pro'));

		$this->load->model('catalog/gallery_pro');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_catalog_gallery_pro->addGalleryPro($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['filter_status_product'])) {
				$url .= '&filter_status_product=' . $this->request->get['filter_status_product'];
			}
			
			if (isset($this->request->get['filter_image'])) {
				$url .= '&filter_image=' . $this->request->get['filter_image'];
			}
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->load->language('catalog/gallery_pro');

		$this->document->setTitle($this->language->get('text_gallery_pro'));

		$this->load->model('catalog/gallery_pro');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_catalog_gallery_pro->editGalleryPro($this->request->get['gallery_pro_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['filter_image'])) {
				$url .= '&filter_image=' . $this->request->get['filter_image'];
			}
			
			if (isset($this->request->get['filter_status_product'])) {
				$url .= '&filter_status_product=' . $this->request->get['filter_status_product'];
			}
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->load->language('catalog/gallery_pro');

		$this->document->setTitle($this->language->get('text_gallery_pro'));

		$this->load->model('catalog/gallery_pro');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $gallery_pro_id) {
				$this->model_catalog_gallery_pro->deleteGalleryPro($gallery_pro_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['filter_image'])) {
				$url .= '&filter_image=' . $this->request->get['filter_image'];
			}
			
			if (isset($this->request->get['filter_status_product'])) {
				$url .= '&filter_status_product=' . $this->request->get['filter_status_product'];
			}
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = null;
		}
		if (isset($this->request->get['filter_image'])) {
			$filter_image = $this->request->get['filter_image'];
		} else {
			$filter_image = null;
		}
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = null;
		}
		if (isset($this->request->get['filter_status_product'])) {
			$filter_status_product = $this->request->get['filter_status_product'];
		} else {
			$filter_status_product = null;
		}
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'gpd.name';
		}
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_image'])) {
			$url .= '&filter_image=' . $this->request->get['filter_image'];
		}
		
		if (isset($this->request->get['filter_status_product'])) {
			$url .= '&filter_status_product=' . $this->request->get['filter_status_product'];
		}
		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['user_token'] = $this->session->data['user_token'];

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_gallery_pro'),
			'href' => $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['setting'] = $this->url->link('extension/module/gallery_pro', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['add'] = $this->url->link('catalog/gallery_pro/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('catalog/gallery_pro/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$this->load->model('tool/image');
		
		$this->load->model('catalog/gallery_pro_group');
		
		$filter_data_group = array(
			'sort'        => 'name',
			'order'       => 'ASC'
		);
		$data['gallery_pro_groups'] = $this->model_catalog_gallery_pro_group->getGalleryProGroups($filter_data_group);


		$data['gallery_pros'] = array();

		$filter_data = array(
			'filter_name'	  => $filter_name,
			'filter_image'	  => $filter_image,
			'filter_status'   => $filter_status,
			'filter_status_product'   => $filter_status_product,
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$gallery_pro_total = $this->model_catalog_gallery_pro->getTotalGalleryPros($filter_data);

		$results = $this->model_catalog_gallery_pro->getGalleryPros($filter_data);

		foreach ($results as $result) {
			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $this->model_tool_image->resize($result['image'], 50, 50);
			} else {
				$image = $this->model_tool_image->resize('no_image.png', 50, 50);
			}
			$total_product 		= $this->model_catalog_gallery_pro->getGalleryTotalProduct($result['gallery_pro_id']);
			$total_video 		= $this->model_catalog_gallery_pro->getGalleryTotalVideoSelect($result['gallery_pro_id']);
			$total_photo 		= $this->model_catalog_gallery_pro->getGalleryTotalImageSelect($result['gallery_pro_id']);
			$gallery_pro_group 	= $this->model_catalog_gallery_pro->getGalleryGroupTo($result['gallery_pro_id']);
			
			$data['gallery_pros'][] = array(
				'gallery_pro_id' 	=> $result['gallery_pro_id'],
				'name'          	=> $result['name'],
				'sort_order'     	=> $result['sort_order'],
				'image'      		=> $image,
				'total_product'		=> $total_product,
				'total_video'		=> $total_video,
				'gallery_pro_group'	=> $gallery_pro_group,
				'total_photo'		=> $total_photo,
				'status'     		=> $result['status'],
				'viewed'     		=> $result['viewed'],
				'status_product' 	=> $result['status_product'],
				'href'  			=> HTTP_CATALOG . 'index.php?route=information/gallery_pro/info&gallery_pro_id=' . $result['gallery_pro_id'],
				'edit'           	=> $this->url->link('catalog/gallery_pro/edit', 'user_token=' . $this->session->data['user_token'] . '&gallery_pro_id=' . $result['gallery_pro_id'] . $url, true)
			);
		}

		$data['text_gallery_pro'] = $this->language->get('text_gallery_pro');

		$data['text_list'] = $this->language->get('text_list');
		$data['text_copy'] = $this->language->get('text_copy');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_select'] = $this->language->get('text_select');
		$data['text_filter_name'] = $this->language->get('text_filter_name');
		$data['text_filter_image'] = $this->language->get('text_filter_image');
		$data['text_filter_product'] = $this->language->get('text_filter_product');
		$data['text_filter_status'] = $this->language->get('text_filter_status');
		
		$data['column_name'] = $this->language->get('column_name');	
		$data['column_viewed'] = $this->language->get('column_viewed');
		$data['column_status'] = $this->language->get('column_status');
		$data['column_sort_order'] = $this->language->get('column_sort_order');
		$data['column_action'] = $this->language->get('column_action');
		$data['column_product'] = $this->language->get('column_product');

		$data['button_add'] = $this->language->get('button_add');
		$data['button_edit'] = $this->language->get('button_edit');
		$data['button_setting'] = $this->language->get('button_setting');
		$data['button_delete'] = $this->language->get('button_delete');
		$data['button_filter'] = $this->language->get('button_filter');
		$data['button_clear'] = $this->language->get('button_clear');
		$data['button_href'] = $this->language->get('button_href');
		$data['column_video'] = $this->language->get('column_video');
		$data['column_photo'] = $this->language->get('column_photo');
		$data['column_images'] = $this->language->get('column_images');
		
		$data['entry_stat_prod'] = $this->language->get('entry_stat_prod');
		
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}
		
		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_image'])) {
			$url .= '&filter_image=' . $this->request->get['filter_image'];
		}
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_status_product'])) {
			$url .= '&filter_status_product=' . $this->request->get['filter_status_product'];
		}
		
		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . '&sort=gpd.name' . $url, true);
		$data['sort_video'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . '&sort=video' . $url, true);
		$data['sort_photo'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . '&sort=photo' . $url, true);
		$data['sort_viewed'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . '&sort=gp.viewed' . $url, true);
		$data['sort_product'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . '&sort=product' . $url, true);
		$data['sort_gallery_id'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . '&sort=gp.gallery_pro_id' . $url, true);
		$data['sort_sort_order'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . '&sort=gp.sort_order' . $url, true);
		$data['sort_status'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . '&sort=gp.status' . $url, true);

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_image'])) {
			$url .= '&filter_image=' . $this->request->get['filter_image'];
		}
		
		if (isset($this->request->get['filter_status_product'])) {
			$url .= '&filter_status_product=' . $this->request->get['filter_status_product'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $gallery_pro_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($gallery_pro_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($gallery_pro_total - $this->config->get('config_limit_admin'))) ? $gallery_pro_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $gallery_pro_total, ceil($gallery_pro_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_image'] = $filter_image;
		$data['filter_status'] = $filter_status;
		$data['filter_status_product'] = $filter_status_product;
		
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/gallery_pro_list', $data));
	}

	protected function getForm() {
		//CKEditor
		if ($this->config->get('config_editor_default')) {
			$this->document->addScript('view/javascript/ckeditor/ckeditor.js');
			$this->document->addScript('view/javascript/ckeditor/ckeditor_init.js');
		}
		
		if ($this->config->get('module_litemanager_status')) {
			$data['litemanager'] = true;
		} else {
			$data['litemanager'] = false;
		}
		if($this->config->get('gallery_pro_cms') == 1){
			$data['my_cms'] = true;
		} else {
			$data['my_cms'] = false;
		}
		

		$data['text_form'] = !isset($this->request->get['gallery_pro_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');


		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}

		if (isset($this->error['meta_title'])) {
			$data['error_meta_title'] = $this->error['meta_title'];
		} else {
			$data['error_meta_title'] = array();
		}

		if (isset($this->error['keyword'])) {
			$data['error_keyword'] = $this->error['keyword'];
		} else {
			$data['error_keyword'] = '';
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_gallery_pro'),
			'href' => $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['gallery_pro_id'])) {
			$data['action'] = $this->url->link('catalog/gallery_pro/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('catalog/gallery_pro/edit', 'user_token=' . $this->session->data['user_token'] . '&gallery_pro_id=' . $this->request->get['gallery_pro_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('catalog/gallery_pro', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['gallery_pro_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$gallery_pro_info = $this->model_catalog_gallery_pro->getGalleryPro($this->request->get['gallery_pro_id']);
		}

		$data['user_token'] = $this->session->data['user_token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
		$data['lang'] = $this->language->get('lang');
		
		$data['lan_forest'] = $this->config->get('config_admin_language');

		if (isset($this->request->post['gallery_pro_description'])) {
			$data['gallery_pro_description'] = $this->request->post['gallery_pro_description'];
		} elseif (isset($this->request->get['gallery_pro_id'])) {
			$data['gallery_pro_description'] = $this->model_catalog_gallery_pro->getGalleryProDescriptions($this->request->get['gallery_pro_id']);
		} else {
			$data['gallery_pro_description'] = array();
		}

		$this->load->model('setting/store');

		$data['stores'] = $this->model_setting_store->getStores();

		if (isset($this->request->post['gallery_pro_store'])) {
			$data['gallery_pro_store'] = $this->request->post['gallery_pro_store'];
		} elseif (isset($this->request->get['gallery_pro_id'])) {
			$data['gallery_pro_store'] = $this->model_catalog_gallery_pro->getGalleryProStores($this->request->get['gallery_pro_id']);
		} else {
			$data['gallery_pro_store'] = array(0);
		}

		if (isset($this->request->post['gallery_pro_seo_url'])) {
			$data['gallery_pro_seo_url'] = $this->request->post['gallery_pro_seo_url'];
		} elseif (isset($this->request->get['gallery_pro_id'])) {
			$data['gallery_pro_seo_url'] = $this->model_catalog_gallery_pro->getGallerySeoUrls($this->request->get['gallery_pro_id']);
		} else {
			$data['gallery_pro_seo_url'] = array();
		}
		
		if (isset($this->request->post['image'])) {
			$data['image'] = $this->request->post['image'];
		} elseif (!empty($gallery_pro_info)) {
			$data['image'] = $gallery_pro_info['image'];
		} else {
			$data['image'] = '';
		}

		$this->load->model('tool/image');

		if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
		} elseif (!empty($gallery_pro_info) && is_file(DIR_IMAGE . $gallery_pro_info['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($gallery_pro_info['image'], 100, 100);
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}

		$this->load->model('catalog/product');
		if (isset($this->request->post['gallery_product'])) {
			$products = $this->request->post['gallery_product'];
		} elseif (isset($this->request->get['gallery_pro_id'])) {
			$products = $this->model_catalog_gallery_pro->getGalleryProduct($this->request->get['gallery_pro_id']);
		} else {
			$products = array();
		}

		$data['gallery_products'] = array();

		foreach ($products as $product_id) {
			$related_info = $this->model_catalog_product->getProduct($product_id);

			if ($related_info) {
				$data['gallery_products'][] = array(
					'product_id' => $related_info['product_id'],
					'name'       => $related_info['name']
				);
			}
		}
		
		if (isset($this->request->post['status_product'])) {
			$data['status_product'] = $this->request->post['status_product'];
		} elseif (!empty($gallery_pro_info)) {
			$data['status_product'] = $gallery_pro_info['status_product'];
		} else {
			$data['status_product'] = true;
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($gallery_pro_info)) {
			$data['status'] = $gallery_pro_info['status'];
		} else {
			$data['status'] = true;
		}

		if (isset($this->request->post['sort_order'])) {
			$data['sort_order'] = $this->request->post['sort_order'];
		} elseif (!empty($gallery_pro_info)) {
			$data['sort_order'] = $gallery_pro_info['sort_order'];
		} else {
			$data['sort_order'] = '';
		}

		if (isset($this->request->post['gallery_pro_layout'])) {
			$data['gallery_pro_layout'] = $this->request->post['gallery_pro_layout'];
		} elseif (isset($this->request->get['gallery_pro_id'])) {
			$data['gallery_pro_layout'] = $this->model_catalog_gallery_pro->getGalleryProLayouts($this->request->get['gallery_pro_id']);
		} else {
			$data['gallery_pro_layout'] = array();
		}
		
		$this->load->model('setting/store');

		$data['stores'] = array();
		
		$data['stores'][] = array(
			'store_id' => 0,
			'name'     => $this->language->get('text_default')
		);
		
		$stores = $this->model_setting_store->getStores();

		foreach ($stores as $store) {
			$data['stores'][] = array(
				'store_id' => $store['store_id'],
				'name'     => $store['name']
			);
		}

		$data['tab_gallery'] 		= $this->language->get('tab_gallery');
		$data['entry_image_video'] 	= $this->language->get('entry_image_video');
		$data['entry_alt_title'] 	= $this->language->get('entry_alt_title');
		$data['entry_group_image'] 	= $this->language->get('entry_group_image');
		$data['entry_like'] 		= $this->language->get('entry_like');
		$data['entry_likes'] 		= $this->language->get('entry_likes');
		$data['entry_dislikes'] 	= $this->language->get('entry_dislikes');
		$data['entry_video'] 		= $this->language->get('entry_video');
		
		$data['text_none_hide'] 	= $this->language->get('text_none_hide');
		$data['text_alt'] 			= $this->language->get('text_alt');
		$data['text_title'] 		= $this->language->get('text_title');
		$data['text_des_gal'] 		= $this->language->get('text_des_gal');
		$data['text_des_alt'] 		= $this->language->get('text_des_alt');
		$data['text_des_title'] 	= $this->language->get('text_des_title');
		
		$data['button_gallery_add'] = $this->language->get('button_gallery_add');
		$data['button_remove'] 		= $this->language->get('button_remove');
		
		$this->load->model('catalog/gallery_pro_group');
		
		$data['gallery_groups'] = array();
		
		$data['gallery_groups'] = $this->model_catalog_gallery_pro_group->getGalleryProGroups();
		
		// Gallery Image
		if (isset($this->request->post['gallery_pro_image'])) {
			$gallery_pro_images = $this->request->post['gallery_pro_image'];
		} elseif (isset($this->request->get['gallery_pro_id'])) {
			$gallery_pro_images = $this->model_catalog_gallery_pro->getGalleryImg($this->request->get['gallery_pro_id']);
		} else {
			$gallery_pro_images = array();
		}
		
		$this->load->model('tool/image');
		
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		$data['gallery_pro_images'] = array();

		foreach ($gallery_pro_images as $gallery_pro_image) {
			if (is_file(DIR_IMAGE . $gallery_pro_image['photo'])) {
				$photo = $gallery_pro_image['photo'];
				$thumb = $gallery_pro_image['photo'];
			} else {
				$photo = '';
				$thumb = 'no_image.png';
			}
			$data['gallery_pro_images'][] = array(
				'id' 				=> $gallery_pro_image['id'],
				'photo'      		=> $photo,
				'thumb'      		=> $this->model_tool_image->resize($thumb, 100, 100),
				'gallery_pro_group_id' 	=> $gallery_pro_image['gallery_pro_group_id'],
				'video' 			=> $gallery_pro_image['video'],
				'likes' 			=> $gallery_pro_image['likes'],
				'dislikes' 			=> $gallery_pro_image['dislikes'],
				'sort_order' 		=> $gallery_pro_image['sort_order'],
				'text' 				=> $gallery_pro_image['text'],
			);
		}
		
		$this->load->model('design/layout');

		$data['layouts'] = $this->model_design_layout->getLayouts();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/gallery_pro_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'catalog/gallery_pro')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->request->post['gallery_pro_description'] as $language_id => $value) {
			if ((utf8_strlen($value['name']) < 3) || (utf8_strlen($value['name']) > 64)) {
				$this->error['name'][$language_id] = $this->language->get('error_name');
			}

			if ((utf8_strlen($value['meta_title']) < 3) || (utf8_strlen($value['meta_title']) > 255)) {
				$this->error['meta_title'][$language_id] = $this->language->get('error_meta_title');
			}
		}

		if ($this->request->post['gallery_pro_seo_url']) {
			$this->load->model('design/seo_url');
			
			foreach ($this->request->post['gallery_pro_seo_url'] as $store_id => $language) {
				foreach ($language as $language_id => $keyword) {
					if (!empty($keyword)) {
						if (count(array_keys($language, $keyword)) > 1) {
							$this->error['keyword'][$store_id][$language_id] = $this->language->get('error_unique');
						}

						$seo_urls = $this->model_design_seo_url->getSeoUrlsByKeyword($keyword);
	
						foreach ($seo_urls as $seo_url) {
							if (($seo_url['store_id'] == $store_id) && (!isset($this->request->get['gallery_pro_id']) || ($seo_url['query'] != 'gallery_pro_id=' . $this->request->get['gallery_pro_id']))) {		
								$this->error['keyword'][$store_id][$language_id] = $this->language->get('error_keyword');
				
								break;
							}
						}
					}
				}
			}
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'catalog/gallery_pro')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}
	
	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			$this->load->model('catalog/gallery_pro');

			$filter_data = array(
				'filter_name' => $this->request->get['filter_name'],
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_catalog_gallery_pro->getGalleryPros($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'gallery_pro_id' 	=> $result['gallery_pro_id'],
					'name'            	=> strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}