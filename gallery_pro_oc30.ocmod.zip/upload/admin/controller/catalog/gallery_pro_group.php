<?php
class ControllerCatalogGalleryProGroup extends Controller {
	private $error = array();

	public function index() {
		$this->language->load('catalog/gallery_pro_group');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/gallery_pro_group');

		$this->getList();
	}

	public function add() {
		$this->language->load('catalog/gallery_pro_group');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/gallery_pro_group');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_catalog_gallery_pro_group->addGalleryProGroup($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['filter_type'])) {
				$url .= '&filter_type=' . $this->request->get['filter_type'];
			}
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}
      
			$this->response->redirect($this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function edit() {
		$this->language->load('catalog/gallery_pro_group');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/gallery_pro_group');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_catalog_gallery_pro_group->editGalleryProGroup($this->request->get['gallery_pro_group_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['filter_type'])) {
				$url .= '&filter_type=' . $this->request->get['filter_type'];
			}
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}
      
			$this->response->redirect($this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getForm();
	}

	public function delete() {
		$this->language->load('catalog/gallery_pro_group');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/gallery_pro_group');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $gallery_pro_group_id) {
				$this->model_catalog_gallery_pro_group->deleteGalleryProGroup($gallery_pro_group_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}
			
			if (isset($this->request->get['filter_type'])) {
				$url .= '&filter_type=' . $this->request->get['filter_type'];
			}
			
			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}
      
			$this->response->redirect($this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {

		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = null;
		}
		
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = null;
		}

		if (isset($this->request->get['filter_type'])) {
			$filter_type = $this->request->get['filter_type'];
		} else {
			$filter_type = null;
		}
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'gsgd.name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_type'])) {
			$url .= '&filter_type=' . $this->request->get['filter_type'];
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('catalog/gallery_pro_group/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('catalog/gallery_pro_group/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);


		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
      
		$data['gallery_pro_groups'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'filter_status'	=> $filter_status,
			'filter_type'	=> $filter_type,
			'filter_name' 	=> $filter_name,
			'order' 		=> $order,
			'start' 		=> ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' 		=> $this->config->get('config_limit_admin')
		);

		$gallery_pro_group_total = $this->model_catalog_gallery_pro_group->getTotalGalleryProGroups($filter_data);

		$results = $this->model_catalog_gallery_pro_group->getGalleryProGroups($filter_data);

		foreach ($results as $result) {
			$data['gallery_pro_groups'][] = array(
				'gallery_pro_group_id' => $result['gallery_pro_group_id'],
				'name'           	=> $result['name'],
				'sort_order'       	=> $result['sort_order'],
				'img_width'			=> $result['img_width'],
				'img_height'		=> $result['img_height'],
				'img_width_big'		=> $result['img_width_big'],
				'img_height_big'	=> $result['img_height_big'],
				'type'     			=> ($result['type']) ? $this->language->get('text_block') : $this->language->get('text_slider'),
				'status'     		=> $result['status'],
				'edit'           	=> $this->url->link('catalog/gallery_pro_group/edit', 'user_token=' . $this->session->data['user_token'] . '&gallery_pro_group_id=' . $result['gallery_pro_group_id'] . $url, true)
			);
		}

		$data['heading_title'] 		= $this->language->get('heading_title');

		$data['text_list'] 			= $this->language->get('text_list');

		$data['entry_names'] 		= $this->language->get('entry_names');
		$data['text_filter'] 		= $this->language->get('text_filter');
		$data['text_clear'] 		= $this->language->get('text_clear');
		$data['entry_status'] 		= $this->language->get('entry_status');
		$data['entry_type'] 		= $this->language->get('entry_type');
      
		$data['text_no_results'] 	= $this->language->get('text_no_results');
		$data['text_confirm'] 		= $this->language->get('text_confirm');
		$data['text_block'] 		= $this->language->get('text_block');
		$data['text_slider'] 		= $this->language->get('text_slider');
		$data['text_enabled'] 		= $this->language->get('text_enabled');
		$data['text_disabled'] 		= $this->language->get('text_disabled');
		$data['text_select'] 		= $this->language->get('text_select');

		$data['column_name'] 		= $this->language->get('column_name');
		$data['column_status'] 		= $this->language->get('column_status');
		$data['column_type'] 		= $this->language->get('column_type');
		$data['column_sort_order'] 	= $this->language->get('column_sort_order');
		$data['column_action'] 		= $this->language->get('column_action');
		$data['column_image_big'] 	= $this->language->get('column_image_big');
		$data['column_image'] 		= $this->language->get('column_image');

		$data['button_add'] 		= $this->language->get('button_add');
		$data['button_edit'] 		= $this->language->get('button_edit');
		$data['button_delete'] 		= $this->language->get('button_delete');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_type'])) {
			$url .= '&filter_type=' . $this->request->get['filter_type'];
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
      
		$data['sort_name'] = $this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . '&sort=gsgd.name' . $url, true);
		$data['sort_sort_order'] = $this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . '&sort=gsg.sort_order' . $url, true);
		$data['sort_type'] = $this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . '&sort=gsg.type' . $url, true);
		$data['sort_status'] = $this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . '&sort=gsg.status' . $url, true);
		
		$url = '';

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_type'])) {
			$url .= '&filter_type=' . $this->request->get['filter_type'];
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $gallery_pro_group_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($gallery_pro_group_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($gallery_pro_group_total - $this->config->get('config_limit_admin'))) ? $gallery_pro_group_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $gallery_pro_group_total, ceil($gallery_pro_group_total / $this->config->get('config_limit_admin')));


		$data['filter_name'] 	= $filter_name;
		$data['filter_status'] 	= $filter_status;
		$data['filter_type'] 	= $filter_type;
		
		$data['user_token'] = $this->session->data['user_token'];
      
		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/gallery_pro_group_list', $data));
	}

	protected function getForm() {
		//CKEditor
		if ($this->config->get('config_editor_default')) {
			$this->document->addScript('view/javascript/ckeditor/ckeditor.js');
			$this->document->addScript('view/javascript/ckeditor/ckeditor_init.js');
		}

		if($this->config->get('gallery_pro_cms') == 1){
			$data['my_cms'] = true;
		} else {
			$data['my_cms'] = false;
		}
		
		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_form'] = !isset($this->request->get['gallery_pro_group_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['text_block'] = $this->language->get('text_block');
		$data['text_slider'] = $this->language->get('text_slider');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_select'] = $this->language->get('text_select');
		
		$data['entry_name'] = $this->language->get('entry_name');
		$data['entry_type'] = $this->language->get('entry_type');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_image'] = $this->language->get('entry_image');
		$data['entry_description'] = $this->language->get('entry_description');
		$data['entry_image_big'] = $this->language->get('entry_image_big');
		$data['entry_image_hei'] = $this->language->get('entry_image_hei');
		$data['entry_image_wid'] = $this->language->get('entry_image_wid');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$data['entry_carousel'] = $this->language->get('entry_carousel');
		$data['entry_style'] = $this->language->get('entry_style');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}
		
		if (isset($this->error['error_img_width'])) {
			$data['error_img_width'] = $this->error['error_img_width'];
		} else {
			$data['error_img_width'] = '';
		}
		if (isset($this->error['error_img_height'])) {
			$data['error_img_height'] = $this->error['error_img_height'];
		} else {
			$data['error_img_height'] = '';
		}
		if (isset($this->error['error_img_width_big'])) {
			$data['error_img_width_big'] = $this->error['error_img_width_big'];
		} else {
			$data['error_img_width_big'] = '';
		}
		if (isset($this->error['error_img_height_big'])) {
			$data['error_img_height_big'] = $this->error['error_img_height_big'];
		} else {
			$data['error_img_height_big'] = '';
		}

		$url = '';

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_type'])) {
			$url .= '&filter_type=' . $this->request->get['filter_type'];
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
		
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);


		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
		
		if (isset($this->request->get['filter_type'])) {
			$url .= '&filter_type=' . $this->request->get['filter_type'];
		}

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}
      
		if (!isset($this->request->get['gallery_pro_group_id'])) {
			$data['action'] = $this->url->link('catalog/gallery_pro_group/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('catalog/gallery_pro_group/edit', 'user_token=' . $this->session->data['user_token'] . '&gallery_pro_group_id=' . $this->request->get['gallery_pro_group_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('catalog/gallery_pro_group', 'user_token=' . $this->session->data['user_token'] . $url, true);

		if (isset($this->request->get['gallery_pro_group_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$gallery_pro_group_info = $this->model_catalog_gallery_pro_group->getGalleryProGroup($this->request->get['gallery_pro_group_id']);
		}
		
		$data['user_token'] = $this->session->data['user_token'];
		$data['ckeditor'] = $this->config->get('config_editor_default');
		$data['lang'] = $this->language->get('lang');
		
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->post['gallery_pro_group_description'])) {
			$data['gallery_pro_group_description'] = $this->request->post['gallery_pro_group_description'];
		} elseif (isset($this->request->get['gallery_pro_group_id'])) {
			$data['gallery_pro_group_description'] = $this->model_catalog_gallery_pro_group->getGalleryProGroupDescriptions($this->request->get['gallery_pro_group_id']);
		} else {
			$data['gallery_pro_group_description'] = array();
		}

		if (isset($this->request->post['sort_order'])) {
			$data['sort_order'] = $this->request->post['sort_order'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['sort_order'] = $gallery_pro_group_info['sort_order'];
		} else {
			$data['sort_order'] = '';
		}
		
		if (isset($this->request->post['carousel'])) {
			$data['carousel'] = $this->request->post['carousel'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['carousel'] = $gallery_pro_group_info['carousel'];
		} else {
			$data['carousel'] = '4';
		}
		
		if (isset($this->request->post['style'])) {
			$data['style'] = $this->request->post['style'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['style'] = $gallery_pro_group_info['style'];
		} else {
			$data['style'] = 'col-sm-3';
		}	
		
		if (isset($this->request->post['type'])) {
			$data['type'] = $this->request->post['type'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['type'] = $gallery_pro_group_info['type'];
		} else {
			$data['type'] = 1;
		}
		
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['status'] = $gallery_pro_group_info['status'];
		} else {
			$data['status'] = true;
		}
		
		if (isset($this->request->post['img_width'])) {
			$data['img_width'] = $this->request->post['img_width'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['img_width'] = $gallery_pro_group_info['img_width'];
		} else {
			$data['img_width'] = 200;
		}
		
		if (isset($this->request->post['img_height'])) {
			$data['img_height'] = $this->request->post['img_height'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['img_height'] = $gallery_pro_group_info['img_height'];
		} else {
			$data['img_height'] = 200;
		}
		
		if (isset($this->request->post['img_width_big'])) {
			$data['img_width_big'] = $this->request->post['img_width_big'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['img_width_big'] = $gallery_pro_group_info['img_width_big'];
		} else {
			$data['img_width_big'] = 400;
		}
		
		if (isset($this->request->post['img_height_big'])) {
			$data['img_height_big'] = $this->request->post['img_height_big'];
		} elseif (!empty($gallery_pro_group_info)) {
			$data['img_height_big'] = $gallery_pro_group_info['img_height_big'];
		} else {
			$data['img_height_big'] = 400;
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/gallery_pro_group_form', $data));
	}


	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			$this->load->model('catalog/gallery_pro_group');

			$filter_data = array(
				'filter_name' => $this->request->get['filter_name'],
				'start'       => 0,
				'limit'       => 10
			);

			$results = $this->model_catalog_gallery_pro_group->getGalleryProGroups($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'gallery_pro_group_id'    => $result['gallery_pro_group_id'],
					'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
      
	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'catalog/gallery_pro_group')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['img_width']) < 2) || (utf8_strlen($this->request->post['img_width']) > 64)) {
			$this->error['error_img_width'] = $this->language->get('error_image');
		}
		if ((utf8_strlen($this->request->post['img_height']) < 2) || (utf8_strlen($this->request->post['img_height']) > 64)) {
			$this->error['error_img_height'] = $this->language->get('error_image');
		}
		if ((utf8_strlen($this->request->post['img_width_big']) < 2) || (utf8_strlen($this->request->post['img_width_big']) > 64)) {
			$this->error['error_img_width_big'] = $this->language->get('error_image');
		}
		if ((utf8_strlen($this->request->post['img_height_big']) < 2) || (utf8_strlen($this->request->post['img_height_big']) > 64)) {
			$this->error['error_img_height_big'] = $this->language->get('error_image');
		}
		
		foreach ($this->request->post['gallery_pro_group_description'] as $language_id => $value) {
			if ((utf8_strlen($value['name']) < 3) || (utf8_strlen($value['name']) > 64)) {
				$this->error['name'][$language_id] = $this->language->get('error_name');
			}
		}
		
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'catalog/gallery_pro_group')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$this->load->model('catalog/gallery_pro_group');

		foreach ($this->request->post['selected'] as $gallery_pro_group_id) {
			$gallery_image_total = $this->model_catalog_gallery_pro_group->getTotalGalleryGropDel($gallery_pro_group_id);

			if ($gallery_image_total) {
				$this->error['warning'] = sprintf($this->language->get('error_delite_group'), $gallery_image_total);
			}
		}

		return !$this->error;
	}
}
