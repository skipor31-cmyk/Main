<?php
class ControllerExtensionModuleGalleryPro extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/gallery_pro');

		$this->document->setTitle($this->language->get('heading_titled'));

		$this->load->model('setting/setting');
		$this->load->model('localisation/language');
		$this->load->model('catalog/gallery_pro');
		
		$data['heading_title'] 		= $this->language->get('heading_title');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_gallery_pro', $this->request->post);
						
			$this->session->data['success'] = $this->language->get('text_success');
						
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}

		if (isset($this->error['keyword'])) {
			$data['error_keyword'] = $this->error['keyword'];
		} else {
			$data['error_keyword'] = '';
		}
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/gallery_pro', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/module/gallery_pro', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		if (isset($this->request->post['module_gallery_pro_status'])) {
			$data['module_gallery_pro_status'] = $this->request->post['module_gallery_pro_status'];
		} else {
			$data['module_gallery_pro_status'] = $this->config->get('module_gallery_pro_status');
		}
	
		if (isset($this->request->post['module_gallery_pro_cms'])) {
			$data['module_gallery_pro_cms'] = $this->request->post['module_gallery_pro_cms'];
		} else {
			$data['module_gallery_pro_cms'] = $this->config->get('module_gallery_pro_cms');
		}
		
		if (isset($this->request->post['module_gallery_pro_description_status'])) {
			$data['module_gallery_pro_description_status'] = $this->request->post['module_gallery_pro_description_status'];
		} else {
			$data['module_gallery_pro_description_status'] = $this->config->get('module_gallery_pro_description_status');
		}
		
		if (isset($this->request->post['module_gallery_pro_like'])) {
			$data['module_gallery_pro_like'] = $this->request->post['module_gallery_pro_like'];
		} else {
			$data['module_gallery_pro_like'] = $this->config->get('module_gallery_pro_like');
		}
		
		if (isset($this->request->post['module_gallery_pro_html'])) {
			$data['module_gallery_pro_html'] = $this->request->post['module_gallery_pro_html'];
		} else {
			$data['module_gallery_pro_html'] = $this->config->get('module_gallery_pro_html');
		}
	
		if (isset($this->request->post['module_gallery_pro_thumb_info_resize'])) {
			$data['module_gallery_pro_thumb_info_resize'] = $this->request->post['module_gallery_pro_thumb_info_resize'];
		} else {
			$data['module_gallery_pro_thumb_info_resize'] = $this->config->get('module_gallery_pro_thumb_info_resize');
		}
		if (isset($this->request->post['module_gallery_pro_gal_list_viewed'])) {
			$data['module_gallery_pro_gal_list_viewed'] = $this->request->post['module_gallery_pro_gal_list_viewed'];
		} else {
			$data['module_gallery_pro_gal_list_viewed'] = $this->config->get('module_gallery_pro_gal_list_viewed');
		}
		if (isset($this->request->post['module_gallery_pro_gal_info_viewed'])) {
			$data['module_gallery_pro_gal_info_viewed'] = $this->request->post['module_gallery_pro_gal_info_viewed'];
		} else {
			$data['module_gallery_pro_gal_info_viewed'] = $this->config->get('module_gallery_pro_gal_info_viewed');
		}
		if (isset($this->request->post['module_gallery_pro_gal_mod_viewed'])) {
			$data['module_gallery_pro_gal_mod_viewed'] = $this->request->post['module_gallery_pro_gal_mod_viewed'];
		} else {
			$data['module_gallery_pro_gal_mod_viewed'] = $this->config->get('module_gallery_pro_gal_mod_viewed');
		}
		if (isset($this->request->post['module_gallery_pro_gal_list_image'])) {
			$data['module_gallery_pro_gal_list_image'] = $this->request->post['module_gallery_pro_gal_list_image'];
		} else {
			$data['module_gallery_pro_gal_list_image'] = $this->config->get('module_gallery_pro_gal_list_image');
		}
		if (isset($this->request->post['module_gallery_pro_gal_info_image'])) {
			$data['module_gallery_pro_gal_info_image'] = $this->request->post['module_gallery_pro_gal_info_image'];
		} else {
			$data['module_gallery_pro_gal_info_image'] = $this->config->get('module_gallery_pro_gal_info_image');
		}
		if (isset($this->request->post['module_gallery_pro_gal_mod_image'])) {
			$data['module_gallery_pro_gal_mod_image'] = $this->request->post['module_gallery_pro_gal_mod_image'];
		} else {
			$data['module_gallery_pro_gal_mod_image'] = $this->config->get('module_gallery_pro_gal_mod_image');
		}		
		if (isset($this->request->post['module_gallery_pro_gal_list_video'])) {
			$data['module_gallery_pro_gal_list_video'] = $this->request->post['module_gallery_pro_gal_list_video'];
		} else {
			$data['module_gallery_pro_gal_list_video'] = $this->config->get('module_gallery_pro_gal_list_video');
		}
		if (isset($this->request->post['module_gallery_pro_gal_info_video'])) {
			$data['module_gallery_pro_gal_info_video'] = $this->request->post['module_gallery_pro_gal_info_video'];
		} else {
			$data['module_gallery_pro_gal_info_video'] = $this->config->get('module_gallery_pro_gal_info_video');
		}
		if (isset($this->request->post['module_gallery_pro_gal_mod_video'])) {
			$data['module_gallery_pro_gal_mod_video'] = $this->request->post['module_gallery_pro_gal_mod_video'];
		} else {
			$data['module_gallery_pro_gal_mod_video'] = $this->config->get('module_gallery_pro_gal_mod_video');
		}			
		if (isset($this->request->post['module_gallery_pro_gal_list_product'])) {
			$data['module_gallery_pro_gal_list_product'] = $this->request->post['module_gallery_pro_gal_list_product'];
		} else {
			$data['module_gallery_pro_gal_list_product'] = $this->config->get('module_gallery_pro_gal_list_product');
		}
		if (isset($this->request->post['module_gallery_pro_gal_info_product'])) {
			$data['module_gallery_pro_gal_info_product'] = $this->request->post['module_gallery_pro_gal_info_product'];
		} else {
			$data['module_gallery_pro_gal_info_product'] = $this->config->get('module_gallery_pro_gal_info_product');
		}
		if (isset($this->request->post['module_gallery_pro_gal_mod_product'])) {
			$data['module_gallery_pro_gal_mod_product'] = $this->request->post['module_gallery_pro_gal_mod_product'];
		} else {
			$data['module_gallery_pro_gal_mod_product'] = $this->config->get('module_gallery_pro_gal_mod_product');
		}	
		if (isset($this->request->post['module_gallery_pro_short_group_name'])) {
			$data['module_gallery_pro_short_group_name'] = $this->request->post['module_gallery_pro_short_group_name'];
		} else {
			$data['module_gallery_pro_short_group_name'] = $this->config->get('module_gallery_pro_short_group_name');
		}	
		if (isset($this->request->post['module_gallery_pro_short_group_description'])) {
			$data['module_gallery_pro_short_group_description'] = $this->request->post['module_gallery_pro_short_group_description'];
		} else {
			$data['module_gallery_pro_short_group_description'] = $this->config->get('module_gallery_pro_short_group_description');
		}	
		if (isset($this->request->post['module_gallery_pro_short_group_img_description'])) {
			$data['module_gallery_pro_short_group_img_description'] = $this->request->post['module_gallery_pro_short_group_img_description'];
		} else {
			$data['module_gallery_pro_short_group_img_description'] = $this->config->get('module_gallery_pro_short_group_img_description');
		}			
		if (isset($this->request->post['module_gallery_pro_limited'])) {
			$data['module_gallery_pro_limited'] = $this->request->post['module_gallery_pro_limited'];
		} elseif ($this->config->get('module_gallery_pro_limited')) {
			$data['module_gallery_pro_limited'] = $this->config->get('module_gallery_pro_limited');
		} else {
			$data['module_gallery_pro_limited'] = '20';
		}
		
		if (isset($this->request->post['module_gallery_pro_prod_width'])) {
			$data['module_gallery_pro_prod_width'] = $this->request->post['module_gallery_pro_prod_width'];
		} elseif ($this->config->get('module_gallery_pro_prod_width')) {
			$data['module_gallery_pro_prod_width'] = $this->config->get('module_gallery_pro_prod_width');
		} else {
			$data['module_gallery_pro_prod_width'] = '200';
		}
		
		if (isset($this->request->post['module_gallery_pro_list_width'])) {
			$data['module_gallery_pro_list_width'] = $this->request->post['module_gallery_pro_list_width'];
		} elseif ($this->config->get('module_gallery_pro_list_width')) {
			$data['module_gallery_pro_list_width'] = $this->config->get('module_gallery_pro_list_width');
		} else {
			$data['module_gallery_pro_list_width'] = '200';
		}
		
		if (isset($this->request->post['module_gallery_pro_list_height'])) {
			$data['module_gallery_pro_list_height'] = $this->request->post['module_gallery_pro_list_height'];
		} elseif ($this->config->get('module_gallery_pro_list_height')) {
			$data['module_gallery_pro_list_height'] = $this->config->get('module_gallery_pro_list_height');
		} else {
			$data['module_gallery_pro_list_height'] = '200';
		}
		
		if (isset($this->request->post['module_gallery_pro_prod_height'])) {
			$data['module_gallery_pro_prod_height'] = $this->request->post['module_gallery_pro_prod_height'];
		} elseif ($this->config->get('module_gallery_pro_prod_height')) {
			$data['module_gallery_pro_prod_height'] = $this->config->get('module_gallery_pro_prod_height');
		} else {
			$data['module_gallery_pro_prod_height'] = '200';
		}
		
		if (isset($this->request->post['module_gallery_pro_thumb_width'])) {
			$data['module_gallery_pro_thumb_width'] = $this->request->post['module_gallery_pro_thumb_width'];
		} elseif ($this->config->get('module_gallery_pro_thumb_width')) {
			$data['module_gallery_pro_thumb_width'] = $this->config->get('module_gallery_pro_thumb_width');
		} else {
			$data['module_gallery_pro_thumb_width'] = '280';
		}
		if (isset($this->request->post['module_gallery_pro_thumb_height'])) {
			$data['module_gallery_pro_thumb_height'] = $this->request->post['module_gallery_pro_thumb_height'];
		} elseif ($this->config->get('module_gallery_pro_thumb_height')) {
			$data['module_gallery_pro_thumb_height'] = $this->config->get('module_gallery_pro_thumb_height');
		} else {
			$data['module_gallery_pro_thumb_height'] = '220';
		}
		
		if (isset($this->request->post['module_gallery_pro_prod_name'])) {
			$data['module_gallery_pro_prod_name'] = $this->request->post['module_gallery_pro_prod_name'];
		} else {
			$data['module_gallery_pro_prod_name'] = $this->config->get('module_gallery_pro_prod_name');
		}
		
		if($this->config->get('module_gallery_pro_cms') == 1){
			$data['my_cms'] = true;
		} else {
			$data['my_cms'] = false;
		}
		$data['user_token'] 		= $this->session->data['user_token'];
		$data['languages'] 	= $this->model_localisation_language->getLanguages();
		$data['lang'] = $this->language->get('lang');


		$this->load->model('setting/store');

		$data['stores'] = array();
		
		$data['stores'][] = array(
			'store_id' => 0,
			'name'     => $this->language->get('text_default')
		);
		
		$stores = $this->model_setting_store->getStores();

		foreach ($stores as $store) { 
			$data['stores'][] = array(
				'store_id' => $store['store_id'],
				'name'     => $store['name']
			);
		}
		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/gallery_pro', $data));
	}
	
	public function install() {
		$this->load->model('catalog/gallery_pro');
		$this->model_catalog_gallery_pro->InsallGalleryPro();
		
		$this->load->model('user/user_group');
 
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'catalog/gallery_pro');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'catalog/gallery_pro_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'catalog/gallery_pro_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'catalog/gallery_pro');
	}
	
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/gallery_pro')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}
		
		return !$this->error;
	}
}