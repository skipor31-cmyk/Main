<?php
// Heading
$_['heading_title']    		= '<b class="text-primary">Gallery Pro</b> - Галерея модуль';
$_['heading_titled']   		= 'Галерея модуль';
 
// Text
$_['text_extension']   		= 'Расширения';
$_['text_success']     		= 'Настройки успешно изменены!';
$_['text_edit']        		= 'Настройки модуля';
$_['text_module']        	= 'Модули';
$_['text_modules']        	= 'Модулем';
$_['text_block']        	= 'Блоком';
$_['text_list']        		= 'Списком (Боковые позиции)';
$_['text_product']        	= 'В товаре (Связанные)';

$_['entry_title'] 	   		= 'Заголовок';
$_['entry_type'] 	   		= 'Вывод';
$_['entry_name']	   		= 'Название';
$_['entry_style']	   		= 'Стиль блока';
$_['entry_list']	   		= 'Вид';
$_['entry_width']   		= 'Ширина';
$_['entry_height']  		= 'Высота';
$_['entry_status']     		= 'Статус';
$_['entry_limit']  			= 'Лимит';

// Error
$_['error_permission'] 		= 'У Вас нет прав для управления данным модулем!';
$_['error_name']       		= 'Название должно быть от 3 до 64 символа!';
$_['error_width']      		= 'Необходимо указать ширину!';
$_['error_height']     		= 'Необходимо указать высоту!';