<?php
// Heading
$_['heading_title']    				= '<b class="text-primary">Gallery Pro</b> - Галерея настройки';
$_['heading_titled']   				= 'Галерея настройки';
 
 
// Tab
$_['tab_seo']   					= 'Seo';
$_['tab_shortcode']   				= 'Шорт код';

// Text
$_['text_extension']   				= 'Расширения';
$_['text_success']     				= 'Настройки успешно изменены!';
$_['text_edit']        				= 'Настройки модуля';
$_['text_block']       				= 'Блок';
$_['text_slider']      				= 'Слайдер';
$_['text_like']      				= 'Оценки';
$_['text_liked']      				= 'Лайк';
$_['text_like_disliked'] 			= 'Лайк + Дизлайк';
$_['text_limite'] 					= 'Кол-во с списке галереи';
$_['text_resizes']					= 'Обрезка фото';
$_['text_resize']					= 'Resize';
$_['text_cropsize']					= 'Cropsize';
$_['text_img_w']					= 'Ширина';
$_['text_img_h']					= 'Высота';
$_['text_img_info']					= 'Фото в галереи';
$_['text_img_list']					= 'Фото в списке';
$_['text_prod_image']				= 'Фото в товаре';
$_['text_description']				= 'Описание';
$_['text_alias'] 					= 'Seo url галереи';
$_['text_alias_help'] 				= 'Уникальная на всю систему';
$_['text_meta_title']          		= 'HTML-тег Title';
$_['text_meta_h1']             		= 'HTML-тег H1';
$_['text_meta_keyword']        		= 'Мета-тег Keywords:';
$_['text_meta_description']    		= 'Мета-тег Description:';

// Entry
$_['entry_gal_stats']				= 'Статистика';
$_['entry_gal_stat_viewed']			= 'Кол-во просмотов';
$_['entry_gal_stat_image']			= 'Кол-во фото';
$_['entry_gal_stat_video']			= 'Кол-во видео';
$_['entry_gal_stat_product']		= 'Кол-во товаров';
$_['entry_prod_name']				= 'Название блока товары';
$_['entry_stat_mod'] 				= 'в модулях';
$_['entry_stat_info'] 				= 'В информации';
$_['entry_stat_list'] 				= 'В списке';
$_['entry_cms'] 					= 'Ваша версия ';
$_['entry_short_name'] 				= 'Название группы';
$_['entry_short_description'] 		= 'Описание группы';
$_['entry_short_description_img'] 	= 'Описание фото';
$_['entry_status'] 					= 'Статус';


// Error
$_['error_permission'] 				= 'У Вас нет прав для управления данным модулем!';