<?php
// Heading
$_['text_gallery_pro']   		= 'Галерея';
$_['text_gallery_pro_list']   = 'Список галерей';
$_['text_gallery_pro_group']  = 'Группы галереи';

// Text
$_['text_success']          	= 'Список галерей обновлен!';
$_['text_list']          		= 'Галереи';
$_['text_add']          		= 'Добавление галереи';
$_['text_edit']          		= 'Редактирование галереи';
$_['text_default']          	= 'Основной магазин';
$_['text_filter_name']          = 'Название';
$_['text_filter_status']      	= 'Статус';
$_['text_filter_image']      	= 'Фото';
$_['text_filter_product']      	= 'Показ товаров';
$_['text_image_multi']      	= 'Мультизагрузка';
$_['text_none_hide']      		= '-- Не выбрано --';
$_['text_des_gal'] 				= 'Описание';
$_['text_des_alt'] 				= 'Alt';
$_['text_des_title'] 			= 'Title';
$_['text_copy'] 				= 'Копировать в буфер';
$_['text_keyword'] 				= 'SEO URL - должен быть уникален на весь магазин';

// Button
$_['button_setting']          	= 'Настройки';
$_['button_href']          		= 'Перейти в галерею';
$_['button_gallery_add']        = 'Добавить';

// Column
$_['column_name']          		= 'Название';
$_['column_video']          	= 'Видео';
$_['column_viewed']          	= 'Просмотры';
$_['column_photo']          	= 'Фото';
$_['column_status']          	= 'Статус';
$_['column_sort_order']         = 'Сортировка';
$_['column_action']          	= 'Действие';
$_['column_product']          	= 'Товары';
$_['column_images']          	= 'Фото';

// Entry
$_['entry_name']          		= 'Название';
$_['entry_store']          		= 'Магазины:';
$_['entry_status']          	= 'Статус:';
$_['entry_keyword']          	= 'SEO URL:';
$_['entry_images']          	= 'Изображение';
$_['entry_sort_order']          = 'Сортировка';
$_['entry_type']          		= 'Тип:';
$_['entry_description']         = 'Описание';
$_['entry_meta_title']          = 'HTML-тег Title';
$_['entry_stat_prod']           = 'Показать товары';
$_['entry_meta_h1']          	= 'HTML-тег H1';
$_['entry_product']          	= 'Связанные товары';
$_['entry_meta_keyword']        = 'Мета-тег Keywords';
$_['entry_meta_description']    = 'Мета-тег Description';
$_['entry_image_video']    		= 'Фото или видео';
$_['entry_image_alt_title']   	= 'Alt / Title';
$_['entry_alt_title']    		= 'Alt / Title / Описание';
$_['entry_video']    			= 'YouTube ID';
$_['entry_group_image']    		= 'Группа';
$_['entry_likes']    			= 'Лайки';
$_['entry_like']    			= '+';
$_['entry_dislikes']    		= '-';
$_['entry_layout']  			= 'Переопределить схему';


// Help
$_['help_keyword']          	= 'Замените пробелы на тире. Должно быть уникальным на всю систему.';
$_['help_product']          	= 'Товары привязанные к галереи';

// Error
$_['error_permission']          = 'У Вас нет прав для изменения галереи!';
$_['error_name']          		= 'Название галереи должно быть от 3 до 64 символов!';
$_['error_keyword']          	= 'Этот SEO keyword уже используется!';
$_['error_warning']          	= 'Внимательно проверьте форму на ошибки!';