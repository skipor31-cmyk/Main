<?php
// Heading
$_['heading_title']  			= 'Группы галереи';

// Text
$_['text_success']          	= 'Список галерей обновлен!';
$_['text_list']          		= 'Список групп';
$_['text_add']          		= 'Добавление группы';
$_['text_edit']          		= 'Редактирование группы';
$_['text_default']          	= 'Основной магазин';
$_['text_filter_name']          = 'Названия';
$_['text_filter_status']      	= 'Статус';
$_['text_block']      			= 'Блок';
$_['text_slider']      			= 'Слайдер';

// Button
$_['button_setting']          	= 'Настройки';

// Column
$_['column_name']          		= 'Название';
$_['column_sort_order']         = 'Порядок сортировки';
$_['column_action']          	= 'Действие';
$_['column_status']          	= 'Статус';
$_['column_type']          		= 'Тип';
$_['column_image_big']         	= 'Увеличенное';
$_['column_image']          	= 'Фото';

// Entry
$_['entry_name']          		= 'Название';
$_['entry_status']          	= 'Статус';
$_['entry_style']          		= 'Стиль для блока';
$_['entry_carousel']          	= 'Кол-во в карусели';
$_['entry_sort_order']          = 'Порядок сортировки:';
$_['entry_names']          		= 'Название';
$_['entry_filter']          	= 'Фильтр';
$_['entry_clear']          		= 'Сбросить';
$_['entry_type']          		= 'Тип';
$_['entry_image']          		= 'Размеры фото';
$_['entry_image_big']       	= 'Увеличенное фото';
$_['entry_description']         = 'Описание';
$_['entry_image_wid']         	= 'Ширина';
$_['entry_image_hei']         	= 'Высота';

// Error
$_['error_permission']          = 'У Вас нет прав для изменения группы галереи!';
$_['error_name']          		= 'Название группы должно быть от 3 до 64 символов!';
$_['error_warning']          	= 'Внимательно проверьте форму на ошибки!';
$_['error_image']          		= 'Размеры фото обязательны';
$_['error_delite_group']        = 'Эта группа не может быть удалена, так как привязана к %s фото!';