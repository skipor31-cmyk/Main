<?php
// Heading
$_['heading_title']  			= 'Gallery Group';

// Text
$_['text_success']           	= 'Success: You have modified Group Gallery!';
$_['text_list']          		= 'List group';
$_['text_add']          		= 'Add group';
$_['text_edit']          		= 'Edit group';
$_['text_default']          	= 'Default store';
$_['text_filter_name']          = 'Group name';
$_['text_filter_status']      	= 'Status';
$_['text_block']      			= 'Block';
$_['text_slider']      			= 'Slider';
$_['text_filter']      	    	= 'Filter';
$_['text_clear']          		= 'Clear';

// Column
$_['column_name']          		= 'Group name';
$_['column_sort_order']         = 'Sort order';
$_['column_action']          	= 'Action';
$_['column_status']          	= 'Status';
$_['column_type']          		= 'Type';
$_['column_image_big']         	= 'PopUp';
$_['column_image']          	= 'Photo';

// Entry
$_['entry_name']          		= 'Group Name';
$_['entry_status']          	= 'Statys';
$_['entry_style']          		= 'Name css style';
$_['entry_carousel']          	= 'Carousel quantity';
$_['entry_sort_order']          = 'Sort order';
$_['entry_names']          		= 'Group name';
$_['entry_type']          		= 'Type';
$_['entry_image']          		= 'Photo size';
$_['entry_image_big']       	= 'PopUp photo';
$_['entry_description']         = 'Description';
$_['entry_image_width'] 		= 'Width';
$_['entry_image_hei'] 			= 'Height';

// Error
$_['error_permission'] 			= 'You dont have rights to change the gallery group!';
$_['error_name'] 				= 'the group Name must be between 3 and 64 characters!';
$_['error_warning'] 			= 'Check the form carefully for errors!';
$_['error_image'] 				= 'The size of photo required';
$_['error_delete_group'] 		= 'This group cannot be deleted because it is linked to %s photos!';