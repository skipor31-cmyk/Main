<?php
// Heading
$_['text_gallery_pro']   		= 'Gallery';
$_['text_gallery_pro_list']   	= 'Gallery List';
$_['text_gallery_pro_group']  	= 'Gallery Group';

// Text
$_['text_success']           	= 'Success: You have modified Gallery!';
$_['text_list']          		= 'Gallery';
$_['text_add']          		= 'Add Gallery';
$_['text_edit']          		= 'Edit Gallery';
$_['text_default']          	= 'Default store';
$_['text_filter_name']          = 'Name';
$_['text_filter_status']      	= 'Status';
$_['text_filter_image']      	= 'Image';
$_['text_filter_product']      	= 'Show product';
$_['text_none_hide']      		= '-- No Select --';
$_['text_des_gal'] 				= 'Description';
$_['text_des_alt'] 				= 'Alt';
$_['text_des_title'] 			= 'Title';
$_['text_copy'] 				= 'Copy to buffer';

// Button
$_['button_setting']          	= 'Setting';
$_['button_href']          		= 'Go to gallery';
$_['button_gallery_add']        = 'Add Gallery';

// Column
$_['column_name']          		= 'Name gallery';
$_['column_video']          	= 'Video';
$_['column_viewed']          	= 'Views';
$_['column_photo']          	= 'Photo';
$_['column_status']          	= 'Status';
$_['column_sort_order']         = 'Sort order';
$_['column_action']          	= 'Action';
$_['column_product']          	= 'Product';
$_['column_images']          	= 'image';

// Entry
$_['entry_name']          		= 'Name gallery';
$_['entry_store']          		= 'Store:';
$_['entry_status']          	= 'Status:';
$_['entry_keyword']          	= 'SEO URL:';
$_['entry_images']          	= 'Image';
$_['entry_sort_order']          = 'Sort order';
$_['entry_description']         = 'Description';
$_['entry_meta_title']          = 'Meta tag Title';
$_['entry_stat_prod']           = 'Show product gallery';
$_['entry_meta_h1']          	= 'Meta tag H1';
$_['entry_product']          	= 'Related product';
$_['entry_meta_keyword']        = 'Meta tag Keywords';
$_['entry_meta_description']    = 'Meta tag Description';
$_['entry_image_video']    		= 'Photo in Video';
$_['entry_image_alt_title']   	= 'Alt / Title';
$_['entry_alt_title']    		= 'Alt / Title / Description';
$_['entry_video']    			= 'YouTube ID';
$_['entry_group_image']    		= 'Group';
$_['entry_likes']    			= 'Likes';
$_['entry_like']    			= '+';
$_['entry_dislikes']    		= '-';
$_['entry_layout']           	= 'Layout Override';


// Help
$_['help_keyword']          	= 'Unique for the entire system';
$_['help_product']          	= 'Products linked to the gallery';

// Error
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify!';
$_['error_name']             = 'Category Name must be between 2 and 255 characters!';
$_['error_meta_title']       = 'Meta Title must be greater than 3 and less than 255 characters!';
$_['error_keyword']          = 'SEO keyword already in use!';