<?php
// Heading
$_['heading_title']    				= '<b class="text-primary">Gallery Pro</b> - Setting gallery';
$_['heading_titled']   				= 'Setting gallery';
 
 
// Tab
$_['tab_seo']   					= 'Seo';
$_['tab_shortcode']   				= 'Short code';

// Text
$_['text_module']   				= 'Modules';
$_['text_success']     				= 'Success: You have modified Gallery Pro module!';
$_['text_edit']        				= 'Edit Gallery Pro Module';
$_['text_like']      				= 'Likes';
$_['text_liked']      				= 'Like';
$_['text_like_disliked'] 			= 'Like + Dislike';
$_['text_limite'] 					= 'Quantity list gallery';
$_['text_resizes']					= 'Cropping image';
$_['text_resize']					= 'Resize';
$_['text_cropsize']					= 'Cropsize';
$_['text_img_w']					= 'Width';
$_['text_img_h']					= 'Height';
$_['text_img_info']					= 'Photo info';
$_['text_img_list']					= 'Photo list';
$_['text_prod_image']				= 'Image product';
$_['text_description']				= 'Description';
$_['text_alias'] 					= 'Seo url allias';
$_['text_alias_help'] 				= 'Unique for the entire system';
$_['text_meta_title']          		= 'Meta Tag Title';
$_['text_meta_h1']             		= 'Meta Tag H1';
$_['text_meta_keyword']        		= 'Meta Tag Keywords:';
$_['text_meta_description']    		= 'Meta Tag Description:';

// Entry
$_['entry_gal_stats']				= 'Statistic';
$_['entry_gal_stat_viewed']			= 'Quantity views';
$_['entry_gal_stat_image']			= 'Quantity photo';
$_['entry_gal_stat_video']			= 'Quantity video';
$_['entry_gal_stat_product']		= 'Quantity product';
$_['entry_prod_name']				= 'Product block name';
$_['entry_stat_mod'] 				= 'In modules';
$_['entry_stat_info'] 				= 'In information';
$_['entry_stat_list'] 				= 'In list';
$_['entry_cms'] 					= 'Oc version';
$_['entry_short_name'] 				= 'Name group gallery';
$_['entry_short_description'] 		= 'Description group gallery';
$_['entry_short_description_img'] 	= 'Description photo';
$_['entry_status'] 					= 'Status';


// Error
$_['error_permission'] 				= 'Warning: You do not have permission to modify module!';
$_['error_name']       				= 'Module Name must be between 3 and 64 characters!';
$_['error_width']      				= 'Width required!';
$_['error_height']     				= 'Height required!';