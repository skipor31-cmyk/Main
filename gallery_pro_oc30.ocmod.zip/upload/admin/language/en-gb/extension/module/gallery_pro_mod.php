<?php
// Heading
$_['heading_title']    		= '<b class="text-primary">Gallery Pro</b> - Gallery Module';
$_['heading_titled']   		= 'Gallery Module';
 
// Text
$_['text_success']     		= 'Success: You have modified Gallery Pro module!';
$_['text_edit']        		= 'Edit Gallery Pro Module';
$_['text_module']        	= 'Modules';
$_['text_modules']        	= 'Module';
$_['text_block']        	= 'Block';
$_['text_list']        		= 'List (Left to Right position)';
$_['text_product']        	= 'Product (Related)';

$_['entry_title'] 	   		= 'Headin title';
$_['entry_type'] 	   		= 'Position';
$_['entry_style']	   		= 'Style block';
$_['entry_list']	   		= 'Type';
$_['entry_name']       		= 'Module Name';
$_['entry_limit']      		= 'Limit';
$_['entry_width']      		= 'Width';
$_['entry_height']     		= 'Height';
$_['entry_status']     		= 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module!';
$_['error_name']       = 'Module Name must be between 3 and 64 characters!';
$_['error_width']      = 'Width required!';
$_['error_height']     = 'Height required!';