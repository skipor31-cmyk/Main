<?php
class ModelCatalogGalleryProGroup extends Model {
	public function addGalleryProGroup($data) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_group SET sort_order = '" . (int)$data['sort_order'] . "', type = '" . (int)$data['type'] . "', style = '" . $data['style'] . "', carousel = '" . (int)$data['carousel'] . "', img_width = '" . (int)$data['img_width'] . "', img_height = '" . (int)$data['img_height'] . "', img_width_big = '" . (int)$data['img_width_big'] . "', img_height_big = '" . (int)$data['img_height_big'] . "', status = '" . (int)$data['status'] . "'");

		$gallery_pro_group_id = $this->db->getLastId();

		foreach ($data['gallery_pro_group_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_group_description SET gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '" . $this->db->escape($value['description']) . "'");
		}

		return $gallery_pro_group_id;
	}

	public function editGalleryProGroup($gallery_pro_group_id, $data) {
		$this->db->query("UPDATE " . DB_PREFIX . "gallery_pro_group SET sort_order = '" . (int)$data['sort_order'] . "', type = '" . (int)$data['type'] . "', style = '" . $data['style'] . "', carousel = '" . (int)$data['carousel'] . "', status = '" . (int)$data['status'] . "', img_width = '" . (int)$data['img_width'] . "', img_height = '" . (int)$data['img_height'] . "', img_width_big = '" . (int)$data['img_width_big'] . "', img_height_big = '" . (int)$data['img_height_big'] . "' WHERE gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "'");

		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_group_description WHERE gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "'");

		foreach ($data['gallery_pro_group_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_group_description SET gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '" . $this->db->escape($value['description']) . "'");
		}
	}

	public function deleteGalleryProGroup($gallery_pro_group_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_group WHERE gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_group_description WHERE gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "'");
	}

	public function getGalleryProGroup($gallery_pro_group_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_group WHERE gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "'");

		return $query->row;
	}

	public function getGalleryProGroups($data = array()) {
		$sql = "SELECT * FROM " . DB_PREFIX . "gallery_pro_group gsg LEFT JOIN " . DB_PREFIX . "gallery_pro_group_description gsgd ON (gsg.gallery_pro_group_id = gsgd.gallery_pro_group_id) WHERE gsgd.language_id = '" . (int)$this->config->get('config_language_id') . "'";


		if (!empty($data['filter_name'])) {
			$sql .= " AND gsgd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}
		
      	if (isset($data['filter_type']) && !is_null($data['filter_type'])) {
			$sql .= " AND gsg.type = '" . (int)$data['filter_type'] . "'";
		}
		
		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$sql .= " AND gsg.status = '" . (int)$data['filter_status'] . "'";
		}
		
		$sort_data = array(
			'gsgd.name',
			'gsg.sort_order',
			'gsg.status',
			'gsg.type'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY gsgd.name";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getGalleryProGroupDescriptions($gallery_pro_group_id) {
		$gallery_pro_group_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_group_description WHERE gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "'");

		foreach ($query->rows as $result) {
			$gallery_pro_group_data[$result['language_id']] = array(
				'name' 			=> $result['name'],
				'description' 	=> $result['description'],
			);
		}

		return $gallery_pro_group_data;
	}

	public function getTotalGalleryProGroups($data = array()) {
		$sql = "SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_group gsg LEFT JOIN " . DB_PREFIX . "gallery_pro_group_description gsgd ON (gsg.gallery_pro_group_id = gsgd.gallery_pro_group_id) WHERE gsgd.language_id = '" . (int)$this->config->get('config_language_id') . "' ";

		if (!empty($data['filter_name'])) {
			$sql .= " AND gsgd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}
		
      	if (isset($data['filter_type']) && !is_null($data['filter_type'])) {
			$sql .= " AND gsg.type = '" . (int)$data['filter_type'] . "'";
		}
		
		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$sql .= " AND gsg.status = '" . (int)$data['filter_status'] . "'";
		}


		$query = $this->db->query($sql);

		return $query->row['total'];
	}
	
	public function getTotalGalleryGropDel($gallery_pro_group_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_group_id = '" . (int)$gallery_pro_group_id . "'");

		return $query->row['total'];
	}
	
}