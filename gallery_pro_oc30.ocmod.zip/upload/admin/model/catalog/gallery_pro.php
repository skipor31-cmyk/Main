<?php
class ModelCatalogGalleryPro extends Model {
	public function addGalleryPro($data) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro SET sort_order = '" . (int)$data['sort_order'] . "', image = '" . $data['image'] . "', status_product = '" . (int)$data['status_product'] . "', status = '" . (int)$data['status'] . "', date_added = NOW()");

		$gallery_pro_id = $this->db->getLastId();
		
		if (isset($data['gallery_pro_image'])) {
			foreach ($data['gallery_pro_image'] as $gallery_pro_image) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_image SET gallery_pro_id = '" . (int)$gallery_pro_id . "', text = '" . $this->db->escape(serialize($gallery_pro_image['text'])). "', photo = '" . $this->db->escape($gallery_pro_image['photo']) . "', video = '" . $this->db->escape($gallery_pro_image['video']) . "', gallery_pro_group_id = '" . (int)$gallery_pro_image['gallery_pro_group_id'] . "', likes = '" . (int)$gallery_pro_image['likes'] . "', dislikes = '" . (int)$gallery_pro_image['dislikes'] . "', sort_order = '" . (int)$gallery_pro_image['sort_order'] . "'");
			}
		}
		
		foreach ($data['gallery_pro_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_description SET gallery_pro_id = '" . (int)$gallery_pro_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '" . $this->db->escape($value['description']) . "', image_title = '" . $this->db->escape($value['image_title']) . "', image_alt = '" . $this->db->escape($value['image_alt']) . "', meta_title = '" . $this->db->escape($value['meta_title']) . "', meta_description = '" . $this->db->escape($value['meta_description']) . "', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
		}

		if (isset($data['gallery_pro_store'])) {
			foreach ($data['gallery_pro_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_to_store SET gallery_pro_id = '" . (int)$gallery_pro_id . "', store_id = '" . (int)$store_id . "'");
			}
		}

		if (isset($data['gallery_pro_layout'])) {
			foreach ($data['gallery_pro_layout'] as $store_id => $layout_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_to_layout SET gallery_pro_id = '" . (int)$gallery_pro_id . "', store_id = '" . (int)$store_id . "', layout_id = '" . (int)$layout_id . "'");
			}
		}

		if (isset($data['gallery_product'])) {
			foreach ($data['gallery_product'] as $product_id) {
				$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_product WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "' AND product_id = '" . (int)$product_id . "'");
				$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_product SET gallery_pro_id = '" . (int)$gallery_pro_id . "', product_id = '" . (int)$product_id . "'");
			}
		}
		
		if (isset($data['gallery_pro_seo_url'])) {
			foreach ($data['gallery_pro_seo_url'] as $store_id => $language) {
				foreach ($language as $language_id => $keyword) {
					if (!empty($keyword)) {
						$this->db->query("INSERT INTO " . DB_PREFIX . "seo_url SET store_id = '" . (int)$store_id . "', language_id = '" . (int)$language_id . "', query = 'gallery_pro_id=" . (int)$gallery_pro_id . "', keyword = '" . $this->db->escape($keyword) . "'");
					}
				}
			}
		}

		$this->cache->delete('gallery_pro');

		return $gallery_pro_id;
	}

	public function editGalleryPro($gallery_pro_id, $data) {
		$this->db->query("UPDATE " . DB_PREFIX . "gallery_pro SET sort_order = '" . (int)$data['sort_order'] . "', image = '" . $data['image'] . "', status_product = '" . (int)$data['status_product'] . "', status = '" . (int)$data['status'] . "' WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_description WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		foreach ($data['gallery_pro_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_description SET gallery_pro_id = '" . (int)$gallery_pro_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '" . $this->db->escape($value['description']) . "', image_alt = '" . $this->db->escape($value['image_alt']) . "', image_title = '" . $this->db->escape($value['image_title']) . "', meta_title = '" . $this->db->escape($value['meta_title']) . "', meta_description = '" . $this->db->escape($value['meta_description']) . "', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
		}

		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_to_store WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		if (isset($data['gallery_pro_store'])) {
			foreach ($data['gallery_pro_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_to_store SET gallery_pro_id = '" . (int)$gallery_pro_id . "', store_id = '" . (int)$store_id . "'");
			}
		}
		
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_to_layout WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		if (isset($data['gallery_pro_layout'])) {
			foreach ($data['gallery_pro_layout'] as $store_id => $layout_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_to_layout SET gallery_pro_id = '" . (int)$gallery_pro_id . "', store_id = '" . (int)$store_id . "', layout_id = '" . (int)$layout_id . "'");
			}
		}
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");
		
		if (isset($data['gallery_pro_image'])) {
			foreach ($data['gallery_pro_image'] as $gallery_pro_image) {
				if ($gallery_pro_image['id']) {
					$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_image SET id = '" . (int)$gallery_pro_image['id'] . "', gallery_pro_id = '" . (int)$gallery_pro_id . "', text = '" . $this->db->escape(serialize($gallery_pro_image['text'])). "', photo = '" . $this->db->escape($gallery_pro_image['photo']) . "', video = '" . $this->db->escape($gallery_pro_image['video']) . "', gallery_pro_group_id = '" . (int)$gallery_pro_image['gallery_pro_group_id'] . "', dislikes = '" . (int)$gallery_pro_image['dislikes'] . "', likes = '" . (int)$gallery_pro_image['likes'] . "', sort_order = '" . (int)$gallery_pro_image['sort_order'] . "'");
				} else {
					$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_image SET gallery_pro_id = '" . (int)$gallery_pro_id . "', text = '" . $this->db->escape(serialize($gallery_pro_image['text'])). "', photo = '" . $this->db->escape($gallery_pro_image['photo']) . "', video = '" . $this->db->escape($gallery_pro_image['video']) . "', gallery_pro_group_id = '" . (int)$gallery_pro_image['gallery_pro_group_id'] . "', dislikes = '" . (int)$gallery_pro_image['dislikes'] . "', likes = '" . (int)$gallery_pro_image['likes'] . "', sort_order = '" . (int)$gallery_pro_image['sort_order'] . "'");
				}
			}
		}
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_product WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		if (isset($data['gallery_product'])) {
			foreach ($data['gallery_product'] as $product_id) {
				$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_product WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "' AND product_id = '" . (int)$product_id . "'");
				$this->db->query("INSERT INTO " . DB_PREFIX . "gallery_pro_product SET gallery_pro_id = '" . (int)$gallery_pro_id . "', product_id = '" . (int)$product_id . "'");
			}
		}

		$this->db->query("DELETE FROM `" . DB_PREFIX . "seo_url` WHERE query = 'gallery_pro_id=" . (int)$gallery_pro_id . "'");
		
		if (isset($data['gallery_pro_seo_url'])) {
			foreach ($data['gallery_pro_seo_url'] as $store_id => $language) {
				foreach ($language as $language_id => $keyword) {
					if (!empty($keyword)) {
						$this->db->query("INSERT INTO " . DB_PREFIX . "seo_url SET store_id = '" . (int)$store_id . "', language_id = '" . (int)$language_id . "', query = 'gallery_pro_id=" . (int)$gallery_pro_id . "', keyword = '" . $this->db->escape($keyword) . "'");
					}
				}
			}
		}

		$this->cache->delete('gallery_pro');

	}

	public function deleteGalleryPro($gallery_pro_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_description WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_to_store WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "gallery_pro_to_layout WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "seo_url WHERE query = 'gallery_pro_id=" . (int)$gallery_pro_id . "'");
	}

	public function getGalleryPro($gallery_pro_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "gallery_pro gp LEFT JOIN " . DB_PREFIX . "gallery_pro_description gpd ON (gp.gallery_pro_id = gpd.gallery_pro_id)  WHERE gp.gallery_pro_id = '" . (int)$gallery_pro_id . "' AND gpd.language_id = '" . (int)$this->config->get('config_language_id') . "'");

		return $query->row;
	}
	
	public function getGallerySeoUrls($gallery_pro_id) {
		$gallery_seo_url_data = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "seo_url WHERE query = 'gallery_pro_id=" . (int)$gallery_pro_id . "'");

		foreach ($query->rows as $result) {
			$gallery_seo_url_data[$result['store_id']][$result['language_id']] = $result['keyword'];
		}

		return $gallery_seo_url_data;
	}

	public function getGalleryProduct($gallery_pro_id) {
		$product_related_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_product WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		foreach ($query->rows as $result) {
			$product_related_data[] = $result['product_id'];
		}

		return $product_related_data;
	}
	
	public function getGalleryImg($gallery_pro_id) {
		$gallery_pro_image_data = array();
		
		$gallery_pro_image_query = $this->db->query("SELECT id, gallery_pro_group_id, photo, sort_order, video, text, likes, dislikes FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "' GROUP BY id");

		foreach ($gallery_pro_image_query->rows as $gallery_pro_image) {
			$gallery_pro_image_data[] = array(
				'id'                  	=> $gallery_pro_image['id'],
				'gallery_pro_group_id' 	=> $gallery_pro_image['gallery_pro_group_id'],
				'photo'                	=> $gallery_pro_image['photo'],
				'sort_order'            => $gallery_pro_image['sort_order'],
				'likes'              	=> $gallery_pro_image['likes'],
				'dislikes'              => $gallery_pro_image['dislikes'],
				'video'               	=> $gallery_pro_image['video'],
				'text'                  => unserialize($gallery_pro_image['text']),
			);
		}
		return $gallery_pro_image_data;
	}
				
	public function getGalleryPros($data = array()) {
		if ($data) {
			$sql = "SELECT *,
				(SELECT count(photo) FROM " . DB_PREFIX . "gallery_pro_image gpi where gpi.gallery_pro_id = gp.gallery_pro_id AND (gpi.video <> '' AND gpi.video IS NOT NULL) GROUP BY gpi.gallery_pro_id) as video,
				(SELECT count(product_id) FROM " . DB_PREFIX . "gallery_pro_product gsp where gsp.gallery_pro_id = gp.gallery_pro_id GROUP BY gsp.gallery_pro_id) as product,
				(SELECT count(photo) FROM " . DB_PREFIX . "gallery_pro_image gpi where gpi.gallery_pro_id = gp.gallery_pro_id AND (gpi.photo <> '' AND gpi.photo <> 'no_image.png' AND gpi.photo <> 'no_image.jpg' AND gpi.photo IS NOT NULL) AND (gpi.video = '' OR gpi.video IS NULL) GROUP BY gpi.gallery_pro_id) as photo
				FROM " . DB_PREFIX . "gallery_pro gp 
				LEFT JOIN " . DB_PREFIX . "gallery_pro_description gpd 
				ON (gp.gallery_pro_id = gpd.gallery_pro_id) 
				WHERE gpd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

			if (!empty($data['filter_name'])) {
				$sql .= " AND gpd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
			}
			
			if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
				$sql .= " AND gp.status = '" . (int)$data['filter_status'] . "'";
			}
			
			if (isset($data['filter_image']) ) {
				if ($data['filter_image'] == 1) {
					$sql .= " AND (gp.image <> '' AND gp.image <> 'no_image.png' AND gp.image <> 'no_image.jpg' AND gp.image IS NOT NULL) ";
				} else {
					$sql .= " AND (gp.image = '' OR gp.image = 'no_image.png' OR gp.image = 'no_image.jpg' OR gp.image IS NULL) ";
				}
			}
			
			if (isset($data['filter_status_product']) && !is_null($data['filter_status_product'])) {
				$sql .= " AND gp.status_product = '" . (int)$data['filter_status_product'] . "'";
			}
			
			$sort_data = array(
				'gpd.name',
				'gp.gallery_pro_id',
				'gp.viewed',
				'gp.sort_order',
				'product',
				'video',
				'photo',
				'gp.status_product',
				'gp.status'
			);

			if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
				$sql .= " ORDER BY " . $data['sort'];
			} else {
				$sql .= " ORDER BY gpd.name";
			}

			if (isset($data['order']) && ($data['order'] == 'DESC')) {
				$sql .= " DESC";
			} else {
				$sql .= " ASC";
			}

			if (isset($data['start']) || isset($data['limit'])) {
				if ($data['start'] < 0) {
					$data['start'] = 0;
				}

				if ($data['limit'] < 1) {
					$data['limit'] = 20;
				}

				$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
			}

			$query = $this->db->query($sql);

			return $query->rows;
		} else {
			$gallery_pro_data = $this->cache->get('gallery_pro.' . (int)$this->config->get('config_language_id'));

			if (!$gallery_pro_data) {
				$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro gp LEFT JOIN " . DB_PREFIX . "gallery_pro_description gpd ON (gp.gallery_pro_id = gpd.gallery_pro_id) WHERE gpd.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY gpd.name");

				$gallery_pro_data = $query->rows;

				$this->cache->set('gallery_pro.' . (int)$this->config->get('config_language_id'), $gallery_pro_data);
			}

			return $gallery_pro_data;
		}
	}

	public function getGalleryProDescriptions($gallery_pro_id) {
		$gallery_pro_description_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_description WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		foreach ($query->rows as $result) {
			$gallery_pro_description_data[$result['language_id']] = array(
				'name'            	=> $result['name'],
				'description'      	=> $result['description'],
				'meta_title'      	=> $result['meta_title'],
				'image_title'		=> $result['image_title'],
				'image_alt'			=> $result['image_alt'],
				'meta_description' 	=> $result['meta_description'],
				'meta_keyword'     	=> $result['meta_keyword']
			);
		}

		return $gallery_pro_description_data;
	}

	public function getGalleryProStores($gallery_pro_id) {
		$gallery_pro_store_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_to_store WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		foreach ($query->rows as $result) {
			$gallery_pro_store_data[] = $result['store_id'];
		}

		return $gallery_pro_store_data;
	}

	public function getGalleryProLayouts($gallery_pro_id) {
		$gallery_pro_layout_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_to_layout WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		foreach ($query->rows as $result) {
			$gallery_pro_layout_data[$result['store_id']] = $result['layout_id'];
		}

		return $gallery_pro_layout_data;
	}

	public function getGalleryGroupTo($gallery_pro_id) {
		$gallery_ro_group_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		foreach ($query->rows as $result) {
			$gallery_ro_group_data[] = $result['gallery_pro_group_id'];
		}

		return $gallery_ro_group_data;
	}
	public function getTotalGalleryPros($data = array()) {
		$sql = "SELECT COUNT(DISTINCT gp.gallery_pro_id) AS total FROM " . DB_PREFIX . "gallery_pro gp LEFT JOIN " . DB_PREFIX . "gallery_pro_description gpd ON (gp.gallery_pro_id = gpd.gallery_pro_id) WHERE gpd.language_id = '" . (int)$this->config->get('config_language_id') . "' ";

		if (!empty($data['filter_name'])) {
			$sql .= " AND gpd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}
		
		if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
			$sql .= " AND gp.status = '" . (int)$data['filter_status'] . "'";
		}
		
		if (isset($data['filter_image']) ) {
			if ($data['filter_image'] == 1) {
				$sql .= " AND (gp.image <> '' AND gp.image <> 'no_image.png' AND gp.image <> 'no_image.jpg' AND gp.image IS NOT NULL) ";
			} else {
				$sql .= " AND (gp.image = '' OR gp.image = 'no_image.png' OR gp.image = 'no_image.jpg' OR gp.image IS NULL) ";
			}
		}
		
		if (isset($data['filter_status_product']) && !is_null($data['filter_status_product'])) {
			$sql .= " AND gp.status_product = '" . (int)$data['filter_status_product'] . "'";
		}
		
		$query = $this->db->query($sql);

		return $query->row['total'];
	}

	public function getTotalGalleryProsByLayoutId($layout_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_to_layout WHERE layout_id = '" . (int)$layout_id . "'");

		return $query->row['total'];
	}
	
	public function getGalleryTotalProduct($gallery_pro_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_product WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "'");

		return $query->row['total'];
	}
	
	public function getGalleryTotalImageSelect($gallery_pro_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "' AND (photo <> '' AND photo <> 'no_image.png' AND photo <> 'no_image.jpg' AND photo IS NOT NULL) AND (video = '' OR video IS NULL)");

		return $query->row['total'];
	}
	
	public function getGalleryTotalVideoSelect($gallery_pro_id) {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "gallery_pro_image WHERE gallery_pro_id = '" . (int)$gallery_pro_id . "' AND (video <> '' AND video IS NOT NULL) ");

		return $query->row['total'];
	}
	
	public function InsallGalleryPro() {
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro` (
				`gallery_pro_id` int(11) NOT NULL AUTO_INCREMENT,
				`sort_order` int(3) NOT NULL DEFAULT '0',
				`viewed` int(5) NOT NULL DEFAULT '0',
				`status` tinyint(1) NOT NULL DEFAULT '1',
				`image` varchar(255),
				`date_added` datetime NOT NULL,
				`status_product` tinyint(1) NOT NULL DEFAULT '1',
				PRIMARY KEY (`gallery_pro_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro_description'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro_description` (
				`gallery_pro_id` int(11) NOT NULL,
				`language_id` int(11) NOT NULL,
				`name` varchar(64) NOT NULL,
				`description` text NOT NULL,
				`meta_title` varchar(255) NOT NULL,
				`meta_description` varchar(255) NOT NULL,
				`meta_keyword` varchar(255) NOT NULL,
				`image_alt` varchar(255) NOT NULL,
				`image_title` varchar(255) NOT NULL,
				PRIMARY KEY (`gallery_pro_id`,`language_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro_to_layout'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro_to_layout` (
				`gallery_pro_id` int(11) NOT NULL,
				`store_id` int(11) NOT NULL,
				`layout_id` int(11) NOT NULL,
				PRIMARY KEY (`gallery_pro_id`,`store_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro_to_store'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro_to_store` (
				`gallery_pro_id` int(11) NOT NULL,
				`store_id` int(11) NOT NULL,
				PRIMARY KEY (`gallery_pro_id`,`store_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro_image'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro_image` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`gallery_pro_id` int(11) NOT NULL,
				`photo` varchar(255),
				`gallery_pro_group_id` int(11) NOT NULL,
				`sort_order` int(3) NOT NULL DEFAULT '0',
				`video` varchar(255),
				`text` varchar(255),
				`likes` int(11) NOT NULL DEFAULT '0',
				`dislikes` int(11) NOT NULL DEFAULT '0',
				PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro_product'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro_product` (
				`gallery_pro_id` int(11) NOT NULL,
				`product_id` int(11) NOT NULL
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro_group'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro_group` (
				`gallery_pro_group_id` int(11) NOT NULL AUTO_INCREMENT,
				`sort_order` int(3) NOT NULL,
				`status` int(3) NOT NULL DEFAULT '1',
				`img_width` varchar(255),
				`img_height` varchar(255),
				`img_width_big` varchar(255),
				`img_height_big` varchar(255),
				`style` varchar(255),
				`carousel` int(1) NOT NULL,
				`type` tinyint(1) DEFAULT NULL,
				PRIMARY KEY (`gallery_pro_group_id`)
				) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro_group_description'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro_group_description` (
				`gallery_pro_group_id` int(11) NOT NULL,
				`language_id` int(11) NOT NULL,
				`name` varchar(64) NOT NULL,
				`description` text NOT NULL,
				PRIMARY KEY (`gallery_pro_group_id`,`language_id`)
				) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
		$sql = "SHOW TABLES LIKE '" . DB_PREFIX . "gallery_pro_guard'";
		if (count($this->db->query($sql)->rows) == 0) {
			$sql = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gallery_pro_guard` (
				`id` int(11) NOT NULL,
				`ip` varchar(40)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
			$this->db->query($sql);
		}
		
	}
}