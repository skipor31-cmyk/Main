<?php
/**
 * diag_cachewebp3.php — финальная комплексная диагностика (OpenCart 3 / Простор / cachewebp).
 * Ключ в $_GET['key']. ПОСЛЕ ИСПОЛЬЗОВАНИЯ УДАЛИТЬ ФАЙЛ С СЕРВЕРА.
 */
$KEY = 'SECRET123';
if (!isset($_GET['key']) || $_GET['key'] !== $KEY) { http_response_code(404); exit; }
header('Content-Type: text/plain; charset=utf-8');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
set_time_limit(300);
echo "=== DIAG3 " . date('Y-m-d H:i:s') . " ===\n";
echo "doc root: " . __DIR__ . "\n";
echo "php: " . PHP_VERSION . "\n";
echo "imagecreatefromwebp: " . (function_exists('imagecreatefromwebp') ? 'YES' : 'NO') . "\n";
echo "imagewebp: " . (function_exists('imagewebp') ? 'YES' : 'NO') . "\n";
if (function_exists('gd_info')) { $g = gd_info(); echo "GD WebP Support: " . (!empty($g['WebP Support']) ? 'enabled' : 'DISABLED') . "\n"; }
echo "\n";

// ---------- 1. Загрузочная цепочка: vqmod / modification в index.php и startup ----------
echo "== 1. BOOT CHAIN (vqmod/modification mentions) ==\n";
foreach (array('index.php', 'admin/index.php', 'system/startup.php', 'system/framework.php', 'system/config.php') as $f) {
    if (!is_file($f)) { echo "--- $f (absent)\n"; continue; }
    $lines = file($f);
    $out = array();
    foreach ($lines as $i => $l) {
        if (stripos($l, 'vqmod') !== false || stripos($l, 'modification') !== false || stripos($l, 'DIR_MODIFICATION') !== false) {
            $out[] = '  L' . ($i + 1) . ': ' . rtrim(substr($l, 0, 150));
        }
    }
    echo "--- $f\n" . ($out ? implode("\n", array_slice($out, 0, 15)) . "\n" : "  (none)\n");
}
echo "\n";

// ---------- 2. Тотальный поиск 'webp' по всем кодовым папкам ----------
echo "== 2. FILES WITH 'webp' (php/twig/xml/tpl) ==\n";
$dirs = array('catalog', 'system', 'admin', 'vqmod', 'cli-php');
$hits = array();
foreach ($dirs as $d) {
    if (!is_dir($d)) { echo "  (dir missing: $d)\n"; continue; }
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile() && in_array(strtolower($f->getExtension()), array('php', 'twig', 'xml', 'tpl'))) {
            $c = @file_get_contents($f->getPathname());
            if ($c === false) continue;
            $n = preg_match_all('~webp~i', $c);
            if ($n) $hits[$f->getPathname()] = $n;
        }
    }
}
foreach (glob('*.php') as $f) {
    $c = @file_get_contents($f);
    $n = preg_match_all('~webp~i', $c);
    if ($n) $hits[$f] = $n;
}
arsort($hits);
echo "  total files: " . count($hits) . "\n";
$k = 0;
foreach ($hits as $p => $n) { echo "  $n  $p\n"; if (++$k >= 60) { echo "  ...(truncated)\n"; break; } }
echo "\n";

// ---------- 3. Строки-генераторы: cachewebp / конкатенация / константы / HTTP_ACCEPT ----------
echo "== 3. GENERATOR LINES (cachewebp / concat / const / accept) ==\n";
$any = false;
foreach ($hits as $p => $n) {
    $lines = @file($p);
    if (!$lines) continue;
    $out = array();
    foreach ($lines as $i => $l) {
        if (stripos($l, 'cachewebp') !== false
            || preg_match("~['\"]cache['\"]?\s*\.\s*\\$?['\"]?w?webp~i", $l)
            || preg_match("~DIR_[A-Z_]*WEBP~i", $l)
            || preg_match("~HTTP_ACCEPT.*webp|webp.*HTTP_ACCEPT~i", $l)) {
            $out[] = '  L' . ($i + 1) . ': ' . rtrim(substr($l, 0, 150));
            $any = true;
        }
    }
    if ($out) echo "--- $p\n" . implode("\n", array_slice($out, 0, 25)) . "\n";
}
if (!$any) echo "  (not found)\n";
echo "\n";

// ---------- 4. config.php: константы ----------
echo "== 4. ROOT config.php CONSTANTS ==\n";
if (is_file('config.php')) {
    foreach (file('config.php') as $i => $l) {
        if (stripos($l, 'define') !== false && (stripos($l, 'webp') !== false || stripos($l, 'image') !== false || stripos($l, 'cache') !== false || stripos($l, 'modification') !== false || stripos($l, 'storage') !== false)) {
            echo '  L' . ($i + 1) . ': ' . rtrim($l) . "\n";
        }
    }
} else echo "  (absent)\n";
echo "\n";

// ---------- 5. vqmod ----------
echo "== 5. VQMOD ==\n";
echo '  vqmod/vqmod.php: ' . (is_file('vqmod/vqmod.php') ? 'exists' : 'absent') . "\n";
echo '  vqmod/index.php: ' . (is_file('vqmod/index.php') ? 'exists' : 'absent') . "\n";
$xmls = glob('vqmod/xml/*.xml');
echo "  vqmod/xml (" . count($xmls) . "):\n";
foreach ($xmls as $x) echo '    ' . basename($x) . "\n";
$vc = glob('vqmod/vqcache/*');
echo '  vqmod/vqcache files: ' . count($vc) . "\n";
foreach (array_slice($vc, 0, 25) as $x) echo '    ' . basename($x) . "\n";
if (is_file('vqmod/vqmod.log')) {
    $l = @file('vqmod/vqmod.log');
    echo "  vqmod.log lines: " . ($l ? count($l) : 0) . " (last 10):\n";
    echo '    ' . implode("\n    ", array_slice(array_map('rtrim', $l ? $l : array()), -10)) . "\n";
}
echo "\n";

// ---------- 6. system/storage/modification: что реально лежит ----------
echo "== 6. system/storage/modification CONTENTS ==\n";
if (is_dir('system/storage/modification')) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator('system/storage/modification', FilesystemIterator::SKIP_DOTS));
    $k = 0;
    foreach ($it as $f) {
        if ($f->isFile()) { echo '  ' . $f->getPathname() . "\n"; if (++$k >= 60) { echo "  ...(truncated)\n"; break; } }
    }
    if (!$k) echo "  (empty)\n";
} else echo "  (dir absent)\n";
echo "\n";

// ---------- 7. БД: XML модификаторов (ищем генератор внутри патчей!) + settings + events ----------
echo "== 7. DB: MODIFICATION XML / SETTINGS / EVENTS ==\n";
require('config.php');
$link = @mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($link) {
    mysqli_set_charset($link, 'utf8');
    $q = mysqli_query($link, 'SELECT modification_id, name, code, status, xml FROM `' . DB_PREFIX . 'modification` ORDER BY modification_id');
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $xml = (string)$r['xml'];
            $cw = stripos($xml, 'cachewebp') !== false;
            $w  = stripos($xml, 'webp') !== false;
            $im = (stripos($xml, 'tool/image') !== false || stripos($xml, 'library/image') !== false);
            echo '  #' . $r['modification_id'] . ' | ' . $r['code'] . ' | status=' . $r['status'] . ' | xml=' . strlen($xml) . 'B'
               . ' | cachewebp=' . ($cw ? 'YES' : 'no') . ' webp=' . ($w ? 'YES' : 'no') . ' image.php=' . ($im ? 'YES' : 'no') . "\n";
            // какие файлы патчит этот модификатор
            if ($cw || $w || $im) {
                preg_match_all('~<file[^>]*>(.*?)</file>~s', $xml, $fm);
                foreach ($fm[1] as $fp) echo '      patches file: ' . trim($fp) . "\n";
                // сниппеты вокруг 'cachewebp'
                $off = 0; $shown = 0;
                while ($shown < 6 && ($pos = stripos($xml, 'cachewebp', $off)) !== false) {
                    echo '      ...' . str_replace(array("\n", "\r", "\t"), ' ', substr($xml, max(0, $pos - 100), 260)) . "...\n";
                    $off = $pos + 9; $shown++;
                }
            }
        }
    } else echo '  err: ' . mysqli_error($link) . "\n";
    echo "  -- settings (webp) --\n";
    $q = mysqli_query($link, 'SELECT `key`, LEFT(`value`, 120) v FROM `' . DB_PREFIX . 'setting` WHERE `key` LIKE "%webp%" OR `value` LIKE "%webp%" LIMIT 30');
    if ($q) { $n = 0; while ($r = mysqli_fetch_assoc($q)) { echo '  ' . $r['key'] . ' = ' . $r['v'] . "\n"; $n++; } if (!$n) echo "  (none)\n"; }
    echo "  -- ALL events --\n";
    $q = mysqli_query($link, 'SELECT code, `trigger`, action, status FROM `' . DB_PREFIX . 'event` LIMIT 40');
    if ($q) { $n = 0; while ($r = mysqli_fetch_assoc($q)) { echo '  ' . $r['code'] . ' | ' . $r['trigger'] . ' | ' . $r['action'] . ' | st=' . $r['status'] . "\n"; $n++; } if (!$n) echo "  (none)\n"; }
    mysqli_close($link);
} else echo "  DB connect failed\n";
echo "\n";

// ---------- 8. Кто кидает 'unknown image format' ----------
echo "== 8. 'unknown image format' SOURCES ==\n";
$any = false;
foreach (array('catalog', 'system', 'admin', 'vqmod') as $d) {
    if (!is_dir($d)) continue;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile() && in_array(strtolower($f->getExtension()), array('php', 'twig'))) {
            $c = @file_get_contents($f->getPathname());
            if ($c && stripos($c, 'unknown image format') !== false) {
                echo '  ' . $f->getPathname() . "\n";
                $any = true;
                $lines = file($f->getPathname());
                foreach ($lines as $i => $l) {
                    if (stripos($l, 'unknown image format') !== false) {
                        for ($j = max(0, $i - 6); $j <= min(count($lines) - 1, $i + 2); $j++) {
                            echo '    L' . ($j + 1) . ': ' . rtrim(substr($lines[$j], 0, 150)) . "\n";
                        }
                    }
                }
            }
        }
    }
}
if (!$any) echo "  (not found)\n";
echo "\n";

// ---------- 9. .htaccess: контекст вокруг L71 ([F]-правило) ----------
echo "== 9. .htaccess L55-90 (context of the [F] rule) ==\n";
if (is_file('.htaccess')) {
    $lines = file('.htaccess');
    for ($i = 54; $i < min(90, count($lines)); $i++) {
        echo '  L' . ($i + 1) . ': ' . rtrim($lines[$i]) . "\n";
    }
} else echo "  (absent)\n";
echo "\n=== END ===\n";
