<?php
/**
 * diag_cachewebp.php — разовая диагностика генератора WebP (image/cachewebp) для OpenCart 3 / Простор.
 *
 * КАК ИСПОЛЬЗОВАТЬ:
 * 1) Замените SECRET123 на свой случайный ключ.
 * 2) Загрузите файл в корень сайта (где лежит index.php).
 * 3) Откройте: https://ВАШ-ДОМЕН/diag_cachewebp.php?key=ВАШ_КЛЮЧ
 * 4) Скопируйте вывод, пришлите помощнику.
 * 5) СРОЗНО УДАЛИТЕ ФАЙЛ С СЕРВЕРА.
 */
$KEY = 'SECRET123';
if (!isset($_GET['key']) || $_GET['key'] !== $KEY) { http_response_code(404); exit; }
header('Content-Type: text/plain; charset=utf-8');
error_reporting(E_ALL);
set_time_limit(120);

echo "=== DIAG " . date('Y-m-d H:i:s') . " ===\n";
echo "doc root: " . __DIR__ . "\n";
echo "php: " . PHP_VERSION . "\n\n";

// ---------- 1. Где в коде встречается cachewebp ----------
echo "== 1. FILES CONTAINING 'cachewebp' (catalog/, system/) ==\n";
$found = array();
$dirs = array('catalog', 'system');
foreach ($dirs as $d) {
    if (!is_dir($d)) continue;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($d, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile() && in_array(strtolower($f->getExtension()), array('php', 'twig'))) {
            $c = @file_get_contents($f->getPathname());
            if ($c !== false && stripos($c, 'cachewebp') !== false) {
                $found[] = $f->getPathname();
            }
        }
    }
}
echo $found ? implode("\n", $found) : '(NOT FOUND — код генератора отсутствует!)';
echo "\n\n";

// ---------- 2. Папки кеша: права, владелец, записываемость ----------
echo "== 2. CACHE DIRS ==\n";
foreach (array('image/cache', 'image/cachewebp') as $p) {
    if (is_dir($p)) {
        $perms = substr(sprintf('%o', fileperms($p)), -4);
        $owner = function_exists('posix_getpwuid') ? posix_getpwuid(fileowner($p))['name'] : fileowner($p);
        echo sprintf("%s: perms=%s owner=%s %s\n", $p, $perms, $owner, is_writable($p) ? 'WRITABLE' : 'NOT WRITABLE');
    } else {
        echo $p . ": MISSING\n";
    }
}
echo "php process user: " . get_current_user();
if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
    $u = posix_getpwuid(posix_geteuid());
    echo " (" . $u['name'] . ")";
}
echo "\n\n";

// ---------- 3. Копии файлов в modification-кеше ocmod ----------
echo "== 3. OCMOD MODIFICATION COPIES ==\n";
$m = 'system/storage/modification';
echo $m . ' dir: ' . (is_dir($m) ? 'exists' : 'MISSING') . "\n";
foreach (array('catalog/model/tool/image.php', 'admin/model/tool/image.php', 'system/library/image.php') as $rel) {
    echo '  ' . $rel . ': ' . (is_file($m . '/' . $rel) ? 'EXISTS' : 'absent') . "\n";
}
echo "\n";

// ---------- 4. БД: модификаторы и события ----------
echo "== 4. DB: modification & event ==\n";
if (is_file('config/config.php')) {
    require('config/config.php');
    $link = @mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($link) {
        mysqli_set_charset($link, 'utf8');
        $q = mysqli_query($link, 'SELECT modification_id, name, status FROM `' . DB_PREFIX . 'modification` ORDER BY modification_id');
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                echo '  mod #' . $r['modification_id'] . ' | ' . $r['name'] . ' | status=' . $r['status'] . "\n";
            }
        } else {
            echo "  modification table error: " . mysqli_error($link) . "\n";
        }
        $q = mysqli_query($link, 'SELECT code, `trigger`, action FROM `' . DB_PREFIX . 'event` WHERE code LIKE "%prostore%" OR code LIKE "%webp%" OR `trigger` LIKE "%image%" OR `trigger` LIKE "%webp%"');
        if ($q) {
            echo "  -- events --\n";
            $n = 0;
            while ($r = mysqli_fetch_assoc($q)) {
                echo '  ' . $r['code'] . ' | ' . $r['trigger'] . ' | ' . $r['action'] . "\n";
                $n++;
            }
            if (!$n) echo "  (no prostore/webp/image events)\n";
        }
        mysqli_close($link);
    } else {
        echo "  DB connect failed\n";
    }
} else {
    echo "  config/config.php not found\n";
}
echo "\n";

// ---------- 5. Хвосты логов ----------
echo "== 5. LAST LOG LINES ==\n";
$logs = glob('system/storage/logs/*.log');
if ($logs) {
    foreach ($logs as $l) {
        $lines = @file($l);
        if (!$lines) continue;
        echo "--- " . $l . " (last 20 lines) ---\n";
        echo implode('', array_slice($lines, -20)) . "\n";
    }
} else {
    echo "(no log files)\n";
}
echo "\n=== END ===\n";
