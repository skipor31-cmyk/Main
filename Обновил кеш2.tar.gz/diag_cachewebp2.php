<?php
/**
 * diag_cachewebp2.php — диагностика №2 (OpenCart 3 / Простор / cachewebp).
 * Ключ в $_GET['key']. ПОСЛЕ ИСПОЛЬЗОВАНИЯ УДАЛИТЬ ФАЙЛ С СЕРВЕРА.
 */
$KEY = 'SECRET123';
if (!isset($_GET['key']) || $_GET['key'] !== $KEY) { http_response_code(404); exit; }
header('Content-Type: text/plain; charset=utf-8');
set_time_limit(180);

echo "=== DIAG2 " . date('Y-m-d H:i:s') . " ===\n";

// ---------- 0. Структура корня ----------
echo "== 0. ROOT ==\n";
foreach (scandir(__DIR__) as $e) {
    if ($e === '.' || $e === '..') continue;
    echo '  ' . (is_dir($e) ? '[dir]  ' : '[file] ') . $e . "\n";
}
echo "\n";

// ---------- 1. БД: модификаторы и события (корневой config.php!) ----------
echo "== 1. DB modification & event ==\n";
if (is_file('config.php')) {
    require('config.php');
    $link = @mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($link) {
        mysqli_set_charset($link, 'utf8');
        $q = mysqli_query($link, 'SELECT modification_id, name, code, status FROM `' . DB_PREFIX . 'modification` ORDER BY modification_id');
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                echo '  #' . $r['modification_id'] . ' | ' . $r['name'] . ' | code=' . $r['code'] . ' | status=' . $r['status'] . "\n";
            }
        } else echo '  err: ' . mysqli_error($link) . "\n";
        $q = mysqli_query($link, 'SELECT code, `trigger`, action FROM `' . DB_PREFIX . 'event` WHERE code LIKE "%prostore%" OR code LIKE "%webp%" OR code LIKE "%image%" OR `trigger` LIKE "%image%" OR `trigger` LIKE "%webp%"');
        if ($q) {
            echo "  -- events --\n";
            $n = 0;
            while ($r = mysqli_fetch_assoc($q)) { echo '  ' . $r['code'] . ' | ' . $r['trigger'] . ' | ' . $r['action'] . "\n"; $n++; }
            if (!$n) echo "  (none)\n";
        }
        mysqli_close($link);
    } else echo "  DB connect failed\n";
} else echo "  config.php NOT FOUND in root!\n";
echo "\n";

// ---------- 2. .htaccess: webp-правила ----------
echo "== 2. ROOT .htaccess (webp-related lines) ==\n";
if (is_file('.htaccess')) {
    $lines = file('.htaccess');
    $hit = false;
    foreach ($lines as $i => $l) {
        if (stripos($l, 'webp') !== false || stripos($l, 'substitute') !== false || stripos($l, 'cachewebp') !== false) {
            echo '  L' . ($i + 1) . ': ' . rtrim($l) . "\n";
            $hit = true;
        }
    }
    if (!$hit) echo "  (no webp/substitute rules; total lines: " . count($lines) . ")\n";
} else echo "  .htaccess NOT FOUND\n";
echo "\n";

// ---------- 3. Ключевые файлы: строки с webp ----------
echo "== 3. KEY FILES: lines containing 'webp' ==\n";
$files = array(
    'catalog/model/tool/image.php',
    'admin/model/tool/image.php',
    'system/library/image.php',
    'index.php',
);
foreach ($files as $f) {
    echo "--- $f\n";
    if (!is_file($f)) { echo "  (absent)\n"; continue; }
    $lines = file($f);
    $n = 0;
    foreach ($lines as $i => $l) {
        if (stripos($l, 'webp') !== false) {
            echo '  L' . ($i + 1) . ': ' . rtrim(substr($l, 0, 160)) . "\n";
            if (++$n > 40) break;
        }
    }
    if (!$n) echo "  (no 'webp' lines)\n";
}
echo "\n";

// ---------- 4. modification.xml: какие модификаторы применены ----------
echo "== 4. system/storage/modification/modification.xml ==\n";
$mx = 'system/storage/modification/modification.xml';
if (is_file($mx)) {
    $c = file_get_contents($mx);
    preg_match_all('~<name>(.*?)</name>~s', $c, $mm);
    echo "  applied modifications:\n";
    foreach ($mm[1] as $nm) echo '   - ' . trim($nm) . "\n";
    echo '  contains "webp": ' . (stripos($c, 'webp') !== false ? 'YES' : 'no') . "\n";
    echo '  contains "prostore": ' . (stripos($c, 'prostore') !== false ? 'YES' : 'no') . "\n";
} else echo "  (absent)\n";
echo "\n";

// ---------- 5. Поиск 'cachewebp' и 'cache'.'webp' вне catalog/system ----------
echo "== 5. ROOT-LEVEL PHP & THEME: cachewebp / cache+webp concat ==\n";
$cands = glob('*.php');
$cands = array_merge($cands, glob('catalog/view/theme/prostore/*.php'), glob('system/library/themes899/*.php'));
$hit = false;
foreach ($cands as $f) {
    $c = @file_get_contents($f);
    if ($c === false) continue;
    if (stripos($c, 'cachewebp') !== false || preg_match("~cache['\"]?\s*\.\s*['\"]?webp~i", $c)) {
        echo "  FOUND in: $f\n";
        $hit = true;
    }
}
if (!$hit) echo "  (not found in root php & theme php)\n";
echo "\n=== END ===\n";
