<?php
/**
 * diag_cachewebp4.php — диагностика №4: НАСТОЯЩАЯ папка модификаций (storage/modification),
 * изменённые копии image.php, ocmod.log и полные XML-блоки патчей image-файлов.
 * Ключ в $_GET['key']. ПОСЛЕ ИСПОЛЬЗОВАНИЯ УДАЛИТЬ ФАЙЛ С СЕРВЕРА.
 */
$KEY = 'SECRET123';
if (!isset($_GET['key']) || $_GET['key'] !== $KEY) { http_response_code(404); exit; }
header('Content-Type: text/plain; charset=utf-8');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
set_time_limit(300);
ini_set('display_errors', '0');
echo "=== DIAG4 " . date('Y-m-d H:i:s') . " ===\n";
echo "memory_limit: " . ini_get('memory_limit') . " | max_execution_time: " . ini_get('max_execution_time') . "\n\n";

require('config.php');

// ---------- 1. Каталог storage и НАСТОЯЩАЯ папка модификаций ----------
echo "== 1. DIR_STORAGE / DIR_MODIFICATION ==\n";
echo "  DIR_STORAGE     = " . DIR_STORAGE . "\n";
echo "  DIR_MODIFICATION= " . DIR_MODIFICATION . "\n";
echo "  DIR_LOGS        = " . DIR_LOGS . "\n";
foreach (array(DIR_STORAGE, DIR_MODIFICATION) as $d) {
    if (is_dir($d)) {
        echo '  ' . $d . ' : exists, ' . (is_writable($d) ? 'WRITABLE' : 'NOT WRITABLE') . ", perms=" . substr(sprintf('%o', fileperms($d)), -4) . "\n";
    } else echo '  ' . $d . " : ABSENT\n";
}
echo "  -- contents of DIR_MODIFICATION (files, mtime) --\n";
if (is_dir(DIR_MODIFICATION)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(DIR_MODIFICATION, FilesystemIterator::SKIP_DOTS));
    $k = 0;
    foreach ($it as $f) {
        if ($f->isFile()) {
            echo '   ' . str_replace(DIR_MODIFICATION, '', $f->getPathname()) . '  [' . $f->getSize() . 'B, ' . date('Y-m-d H:i', $f->getMTime()) . "]\n";
            if (++$k >= 100) { echo "   ...(truncated)\n"; break; }
        }
    }
    if (!$k) echo "   (EMPTY!)\n";
}
echo "\n";

// ---------- 2. Изменённые копии image-файлов: что в них реально есть ----------
echo "== 2. MODIFIED COPIES: key markers ==\n";
$markers = array('cachewebp', 'save_webp', 'cropsize', 'WebP Images', 'str_replace', 'HTTP_ACCEPT', 'unknown', 'GLOB_BRACE');
foreach (array('catalog/model/tool/image.php', 'admin/model/tool/image.php', 'system/library/image.php') as $rel) {
    $p = DIR_MODIFICATION . $rel;
    echo "--- MOD: $rel\n";
    if (!is_file($p)) { echo "   (absent — патчи к файлу НЕ ПРИМЕНИЛИСЬ)\n"; continue; }
    echo '   size=' . filesize($p) . 'B mtime=' . date('Y-m-d H:i:s', filemtime($p)) . "\n";
    $lines = file($p);
    foreach ($markers as $mk) {
        $out = array();
        foreach ($lines as $i => $l) {
            if (stripos($l, $mk) !== false) $out[] = '     L' . ($i + 1) . ': ' . rtrim(substr($l, 0, 140));
        }
        echo '   [' . $mk . '] ' . count($out) . " hits\n" . implode("\n", array_slice($out, 0, 12)) . (count($out) > 12 ? "\n     ..." : "") . "\n";
    }
}
echo "\n";

// ---------- 3. ИСХОДНЫЕ файлы (public_html) ----------
echo "== 3. SOURCE FILES ==\n";
echo "--- catalog/model/tool/image.php (FULL DUMP) ---\n";
if (is_file('catalog/model/tool/image.php')) {
    $lines = file('catalog/model/tool/image.php');
    echo "   (total " . count($lines) . " lines, mtime=" . date('Y-m-d H:i', filemtime('catalog/model/tool/image.php')) . ")\n";
    foreach (array_slice($lines, 0, 160) as $i => $l) echo sprintf("%4d| %s\n", $i + 1, rtrim(substr($l, 0, 150)));
    if (count($lines) > 160) echo "   ...(truncated)\n";
} else echo "   (absent)\n";
echo "--- system/library/image.php: anchors ---\n";
if (is_file('system/library/image.php')) {
    $lines = file('system/library/image.php');
    echo "   (total " . count($lines) . " lines, mtime=" . date('Y-m-d H:i', filemtime('system/library/image.php')) . ")\n";
    foreach ($lines as $i => $l) {
        if (preg_match('~public function (save|crop|resize|create)|str_replace|imagecreatefrom|imagewebp|throw~', $l)) {
            echo '     L' . ($i + 1) . ': ' . rtrim(substr($l, 0, 140)) . "\n";
        }
    }
}
echo "--- admin/model/tool/image.php: anchors ---\n";
if (is_file('admin/model/tool/image.php')) {
    $lines = file('admin/model/tool/image.php');
    foreach ($lines as $i => $l) {
        if (preg_match('~public function|str_replace|throw|webp~i', $l)) echo '     L' . ($i + 1) . ': ' . rtrim(substr($l, 0, 140)) . "\n";
    }
}
echo "\n";

// ---------- 4. Логи: ocmod.log и error.log ----------
echo "== 4. LOGS ==\n";
if (is_dir(DIR_LOGS)) {
    foreach (glob(rtrim(DIR_LOGS, '/') . '/*') as $lf) {
        if (!is_file($lf)) continue;
        echo '--- ' . basename($lf) . ' [' . filesize($lf) . 'B, ' . date('Y-m-d H:i', filemtime($lf)) . "]\n";
        if (preg_match('~ocmod|modification~i', basename($lf)) || preg_match('~error~i', basename($lf))) {
            $lines = @file($lf);
            if ($lines) echo '     ' . implode("\n     ", array_slice(array_map(function($x){return rtrim(substr($x,0,200));}, $lines), -60)) . "\n";
        }
    }
} else echo "  DIR_LOGS absent\n";
echo "\n";

// ---------- 5. Полные XML-блоки патчей image-файлов из БД ----------
echo "== 5. DB XML: <file> blocks touching image ==\n";
$link = @mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($link) {
    mysqli_set_charset($link, 'utf8');
    $q = mysqli_query($link, 'SELECT code, xml FROM `' . DB_PREFIX . 'modification` WHERE code IN ("theme_prostore", "gallery_pro")');
    while ($r = mysqli_fetch_assoc($q)) {
        echo "#### modification: " . $r['code'] . "\n";
        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        if (!$doc->loadXML($r['xml'])) { echo "   XML PARSE FAILED!\n"; continue; }
        $files = $doc->getElementsByTagName('file');
        foreach ($files as $node) {
            $path = $node->getAttribute('path');
            $err  = $node->getAttribute('error');
            $ops  = $node->getElementsByTagName('operation')->length;
            echo '   <file path="' . $path . '"' . ($err ? ' error="' . $err . '"' : '') . "> ops=$ops\n";
            if (stripos($path, 'image') !== false) {
                $xmlblock = $doc->saveXML($node);
                echo "   ---- FULL BLOCK ----\n";
                echo substr($xmlblock, 0, 30000) . (strlen($xmlblock) > 30000 ? "\n...(truncated)" : "") . "\n";
                echo "   ---- END BLOCK ----\n";
            }
        }
    }
    mysqli_close($link);
} else echo "  DB connect failed\n";
echo "\n=== END ===\n";
