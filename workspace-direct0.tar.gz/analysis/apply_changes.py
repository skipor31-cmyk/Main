#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Мастер-план изменений кампании 40732207 «[ПОИСК] Доставка Раменское».

Режимы:
    python3 apply_changes.py            # DRY-RUN: показать план, ничего не менять
    python3 apply_changes.py --apply    # применить (только после подтверждения!)
    python3 apply_changes.py --rollback # откатить применённое (по apply_state.json)

Все данные читаются из analysis/ (устойчивые артефакты аудита).
Каждый шаг логируется в analysis/apply_state.json — откат возможен всегда.
"""
import json, os, re, sys, datetime

ROOT = os.path.dirname(os.path.abspath(__file__))          # .../analysis
WS   = os.path.dirname(ROOT)                                # workspace root
SCRIPTS = os.path.join(WS, 'skills_repo', 'extracted1',
                       'skill_for_claude_code_yandex_direct-main', 'scripts')
sys.path.insert(0, SCRIPTS)
os.chdir(SCRIPTS)  # чтобы load_config нашёл config.json

from direct_api import DirectClient, load_config, collect_add_results, DirectError

CAMPAIGN_ID = 40732207
STATE_PATH = os.path.join(ROOT, 'apply_state.json')

# ---------------------------------------------------------------- регионы
CITY      = 10750      # Раменское
ZHUK      = 20571      # Жуковский
VILLAGES  = [10718, 117802, 118482, 119749, 105573, 120351, 133110,
             161506, 161512, 161520, 161524, 161526, 161536, 161541, 161548]
ZONE17    = [CITY, ZHUK] + VILLAGES        # город + Жуковский + 15 поселений
BRAND_GEO = [1]                             # Москва и область

# ---------------------------------------------------------------- расширения (шаблон с живых объявлений)
SITELINKS = 1384724168
BUSINESS  = 103128457869
TRACKPHONE= 6247510023894529225
CALLOUTS  = [36689089, 36689093, 36689312, 36689333, 36689334, 36689336,
             36689428, 36689429, 36689431, 7103330, 7103334, 9309894]

UTM  = '?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}&utm_content={ad_id}&utm_term={keyword}'
HOME = 'https://flowerpoetry.ru/' + UTM
KAT  = 'https://flowerpoetry.ru/katalog/' + UTM
DOST = 'https://flowerpoetry.ru/informaciya-o-dostavke' + UTM

BID_MICRO = 450 * 1_000_000

AT_CATEGORIES = [{"Category":"EXACT","Value":"YES"},{"Category":"ALTERNATIVE","Value":"NO"},
                 {"Category":"COMPETITOR","Value":"NO"},{"Category":"BROADER","Value":"NO"},
                 {"Category":"ACCESSORY","Value":"NO"}]
AT_BRANDS = [{"Option":"WITHOUT_BRANDS","Value":"YES"},{"Option":"WITH_ADVERTISER_BRAND","Value":"YES"}]
AT_CATEGORIES_OLD = [{"Category":"EXACT","Value":"YES"},{"Category":"ALTERNATIVE","Value":"NO"},
                 {"Category":"COMPETITOR","Value":"YES"},{"Category":"BROADER","Value":"NO"},
                 {"Category":"ACCESSORY","Value":"NO"}]

# ---------------------------------------------------------------- живые группы (11) и их новые объявления
LIVE_GROUPS = [3688099772, 4166852642, 4166852644, 4166852655, 4166852705, 4166852706,
               4166852729, 4166852738, 4166852753, 4166852847, 4166852849]
MONSTER = 4166852738

ADS_FOR_LIVE = {
 3688099772: ("Заказ цветов с доставкой в Раменском","За 2 часа. От 2000 руб.",
   "Авторские букеты из свежих цветов. Открытка в подарок. Оплата картой. Закажите!", KAT, "Каталог-букетов"),
 4166852642: ("Доставка цветов в Раменском от 2000 руб.","Фото букета перед доставкой",
   "150+ стильных букетов в наличии. Быстрая доставка по городу. Открытка в подарок!", HOME, "Доставка-цветов"),
 4166852644: ("Заказать цветы с доставкой в Раменском","Привезём за 2 часа или к сроку",
   "Свежие цветы ежедневно. Удобная оплата онлайн. Открытка к букету в подарок!", KAT, "Каталог-букетов"),
 4166852655: ("Доставка цветов на дом в Раменском","Курьером за 2 часа",
   "Букеты из свежих цветов с доставкой на дом. Открытка в подарок. Оплата картой!", HOME, "Доставка-цветов"),
 4166852705: ("Цветы с доставкой на дом в Раменском","Доставка от 1 часа по городу",
   "Авторские букеты от 2000 руб. Привезём бережно и вовремя. Фото перед отправкой!", HOME, "Доставка-цветов"),
 4166852706: ("Доставка цветов по Раменскому району","Доставим по всему району",
   "Доставка букетов по Раменскому району. От 2000 руб. Открытка в подарок!", DOST, "Доставка-цветов"),
 4166852729: ("Доставка цветов курьером в Раменском","Курьер приедет за 2 часа",
   "Бережная доставка букетов курьером. Фото перед отправкой. Открытка в подарок!", HOME, "Доставка-цветов"),
 4166852738: ("Купить цветы с доставкой в Раменском","150+ букетов в наличии",
   "Каталог авторских букетов от 2000 руб. Доставка за 2 часа. Открытка в подарок!", KAT, "Каталог-букетов"),
 4166852753: ("Доставка цветов в область из Раменского","Привезём за 2 часа и дальше",
   "Доставка букетов по району и области. От 2000 руб. Открытка в подарок к заказу!", HOME, "Доставка-цветов"),
 4166852847: ("Букеты с доставкой в Раменском от 2000 руб.","Свежие цветы каждый день",
   "Авторские букеты с доставкой за 2 часа. Бесплатно по городу. Открытка в подарок!", HOME, "Доставка-цветов"),
 4166852849: ("Доставка цветов по Раменскому и району","За 2 часа. Оплата картой",
   "Свежие букеты от 2000 руб. с быстрой доставкой. Открытка в подарок к заказу!", HOME, "Доставка-цветов"),
}

MONSTER_NEW_KEYS = ["купить цветы раменское","заказать букет раменское","доставка букетов раменское",
 "цветы с доставкой раменское","букет цветов раменское","заказ цветов раменское",
 "доставка цветов раменское недорого","доставка цветов раменское срочно","доставка цветов раменское сегодня",
 "цветы на дом раменское","букет с доставкой раменское","доставка цветов раменское цена",
 "цветы курьером раменское","букет на заказ раменское","цветы в подарок раменское","заказать цветы раменское"]

# ---------------------------------------------------------------- 7 новых групп: гео, минус-слова, ключи, объявление
NEW_GROUPS = [
 {"name": "Д3. Доставка — район и деревни", "regions": ZONE17, "negatives": [],
  "keys": ["доставка цветов","доставка букетов","заказать цветы","купить цветы +с доставкой",
           "доставка цветов недорого","срочная доставка цветов","доставка цветов сегодня",
           "сервис доставки цветов","доставка цветов поселок","доставка цветов кратово",
           "доставка цветов удельная","доставка цветов быково","доставка цветов ильинский",
           "доставка цветов гжель"],
  "ad": ("Доставка цветов по району и деревням","Быково, Кратово, Удельная",
         "Привезём букет в любой посёлок района за 2 часа. От 2000 руб. Открытка в подарок!", DOST, "Доставка-цветов")},

 {"name": "Д5. Доставка — Жуковский", "regions": [ZHUK],
  "negatives": ["раменское","раменском","раменского","раменскому"],
  "keys": ["жуковский доставка цветов","жуковский доставка букетов",
           "жуковский заказать цветы +с доставкой","жуковский заказ цветов","жуковский купить цветы",
           "жуковский доставка цветов +на дом","жуковский магазин цветов","жуковский цветы",
           "доставка цветов жуковский недорого","купить букет жуковский"],
  "ad": ("Доставка цветов в Жуковском за 2 часа","От 2000 ₽. Открытка в подарок",
         "Авторские букеты с доставкой по Жуковскому за 2 часа. Оплата картой!", HOME, "Доставка-цветов")},

 {"name": "К2. Купить-заказать (общие)", "regions": ZONE17, "negatives": [],
  "keys": ["цветы на дом","доставить букет","доставить цветы","заказать цветы +на дом",
           "купить цветы +на дом","купить букет цветов","заказать букет цветов","цветы +на заказ",
           "букеты +на заказ","белые букеты купить","купить готовые букеты","готовые букеты цветов",
           "купить живые цветы","цветы срезанные купить","букет цветов цена","живые цветы цена",
           "букет цветов","большой букет цветов","купить большой букет"] + MONSTER_NEW_KEYS,
  "ad": ("Купить букет цветов в Раменском","От 2000 руб. Доставка 2 часа",
         "Свежие букеты в наличии и на заказ. Соберём по вашему бюджету. Оплата картой!", KAT, "Каталог-букетов")},

 {"name": "М1. Магазин и витрина", "regions": ZONE17, "negatives": [],
  "keys": ["магазин цветов раменское","цветочный магазин раменское","цветы раменское",
           "цветочный раменское","цветы в раменском","магазин цветов","магазин цветов адреса",
           "цветочная студия","цветы онлайн магазин","купить цветы онлайн","цветочный магазин онлайн",
           "цветочный онлайн","букет онлайн","бутик цветов","мастерская букетов","мастерская флористики",
           "магазин продажи букетов","сайт магазина цветов","магазин красивых цветов"],
  "ad": ("Цветочный магазин в Раменском","Северное шоссе, 14. Самовывоз",
         "150+ букетов в наличии. Самовывоз и доставка за 2 часа. Открытка в подарок!", HOME, "Цветочный-магазин")},

 {"name": "М2. По видам цветов", "regions": ZONE17, "negatives": [],
  "keys": ["букет из хризантем","купить букет хризантем","цветы хризантемы купить",
           "букет цветов из хризантем","букет из белых хризантем","букет из кустовых хризантем",
           "букет из одноголовых хризантем","букет хризантем цена","букеты цветов гортензия",
           "купить цветы эустома","купить букет эустомы","гвоздика цветы купить","цветы гвоздики купить",
           "купить цветы альстромерия","экзотические цветы купить","доставка роз раменское",
           "купить пионы раменское"],
  "ad": ("Букеты из свежих цветов в Раменском","Хризантемы, пионы, гортензии",
         "Розы, пионы, хризантемы, гортензии в наличии. Доставка за 2 часа. От 2000 руб.", KAT, "Каталог-букетов")},

 {"name": "М3. По поводам", "regions": ZONE17, "negatives": [],
  "keys": ["оригинальные букеты цветов","букет в подарок","букет цветов в подарок","стильные букеты цветов",
           "изысканный букет цветов","авторские букеты из цветов","необычные букеты цветов",
           "шикарные букет с днем","шикарный букет цветов с днем","букеты из живых цветов",
           "красивые букеты из живых цветов","модные букеты цветов","дизайнерские букеты цветов",
           "букет цветов для девочки","цветы для подруги","нежный букет цветов","букет для любимой",
           "роскошный букет цветов","букет цветов сердцем","свадебные букеты раменское","букет невесты раменское"],
  "ad": ("Оригинальные букеты в Раменском","Авторская сборка. Фото букета",
         "Букеты на любой повод: день рождения, свадьба, просто так. Соберём по бюджету!", KAT, "Каталог-букетов")},

 {"name": "Б1. Бренд", "regions": BRAND_GEO, "negatives": [],
  "keys": ["цветочная поэзия","цветочная поэзия раменское","цветочная поэзия доставка цветов",
           "цветочная поэзия северное шоссе","flowerpoetry"],
  "ad": ("Цветочная поэзия — доставка в Раменском","За 2 часа. От 2000 руб.",
         "Ваш цветочный магазин на Северном шоссе, 14. Доставка и самовывоз. Ждём вас!", HOME, "Цветочная-поэзия")},
]


# ---------------------------------------------------------------- helpers
def load_artifacts():
    cmd = json.load(open(os.path.join(ROOT, 'commander_40732207.json')))
    phrases = []   # (kw_id, phrase_text) живых фраз (без автотаргетинга и '+'-строк)
    autotarget_ids = []
    for d in cmd:
        if d.get('Доп. объявление группы') == '+': continue
        ph, pid = d.get('Фраза (с минус-словами)'), d.get('ID фразы')
        if not ph or not pid: continue
        if ph == '---autotargeting':
            autotarget_ids.append(int(pid)); continue
        phrases.append((int(pid), ph))
    import csv
    dead_ids = []
    with open(os.path.join(ROOT, 'остановленные_фразы_4166852738.csv')) as f:
        for row in csv.DictReader(f, delimiter=';'):
            dead_ids.append(int(row['ID фразы']))
    negs_clean = json.load(open(os.path.join(ROOT, 'campaign_negatives_clean.json')))
    negs_orig  = json.load(open(os.path.join(ROOT, 'campaign_negatives_original.json')))
    return phrases, autotarget_ids, dead_ids, negs_clean, negs_orig

BANG_RE = re.compile(r'\s*-!(?:в|до|и|на|по|с)(?=\s|$)')
def clean_phrase(p):
    return re.sub(r'\s{2,}', ' ', BANG_RE.sub('', p).strip())

def validate_ads():
    errs = []
    allads = list(ADS_FOR_LIVE.values()) + [g["ad"] for g in NEW_GROUPS]
    for t1, t2, tx, href, disp in allads:
        if len(t1) > 56: errs.append(f"T1 {len(t1)}: {t1}")
        if len(t2) > 30: errs.append(f"T2 {len(t2)}: {t2}")
        if len(tx) > 81: errs.append(f"TX {len(tx)}: {tx}")
        if len(disp) > 20: errs.append(f"DISP {len(disp)}: {disp}")
        for s in (t1, t2, tx):
            if s.count('!') > 1: errs.append(f">1 '!': {s}")
    return errs

def ad_payload(t1, t2, tx, href, disp):
    return {"TextAd": {
        "Title": t1, "Title2": t2, "Text": tx, "Href": href,
        "Mobile": "NO",
        "SitelinkSetId": SITELINKS, "AdExtensionIds": CALLOUTS,
        "BusinessId": BUSINESS, "TrackingPhoneId": TRACKPHONE,
        "DisplayUrlPath": disp}}

# ---------------------------------------------------------------- шаги
def build_steps():
    phrases, at_ids, dead_ids, negs_clean, negs_orig = load_artifacts()
    kw_updates = [{"Id": pid, "Keyword": clean_phrase(ph), "Bid": BID_MICRO} for pid, ph in phrases]
    n_cleaned = sum(1 for pid, ph in phrases if clean_phrase(ph) != ph)

    steps = [
      {"id": "0_goals", "desc": "Приоритетные цели: УБРАТЬ шумовую «Кол-во просмотров»(27796104) и битые 49487668/71/74; "
                               "звонок 400→2500 ₽; клику по телефону 400→600 ₽; корзина 3700→300 ₽; выбор оплаты 3700→400 ₽; "
                               "ДОБАВИТЬ мессенджер 1500 ₽, форму 1200 ₽, контакты 1200 ₽; заказ/1клик/шаги — 5500 ₽ (без изменений)",
       "svc": "campaigns", "method": "update",
       "params": {"Campaigns": [{"Id": CAMPAIGN_ID, "TextCampaign": {"PriorityGoals": {"Items": [
            {"GoalId": 36895733,  "Value": 5500_000000, "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 49487656,  "Value": 5500_000000, "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 168348169, "Value": 5500_000000, "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 136163740, "Value": 2500_000000, "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 168348397, "Value": 1500_000000, "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 197752867, "Value": 1200_000000, "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 339702220, "Value": 1200_000000, "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 168348274, "Value": 600_000000,  "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 49487221,  "Value": 400_000000,  "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
            {"GoalId": 36895973,  "Value": 300_000000,  "Operation": "SET", "IsMetrikaSourceOfValue": "NO"},
       ]}}}]},
       "rollback": {"svc":"campaigns","method":"update",
                    "params":{"Campaigns":[{"Id":CAMPAIGN_ID,"TextCampaign":{"PriorityGoals":{"Items":[
            {"GoalId":168348169,"Value":5500_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":36895733,"Value":5500_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":36895973,"Value":3700_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":49487221,"Value":3700_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":49487656,"Value":5500_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":49487668,"Value":3700_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":49487671,"Value":3700_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":49487674,"Value":5500_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":136163740,"Value":400_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":27796104,"Value":360_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"},
            {"GoalId":168348274,"Value":400_000000,"Operation":"SET","IsMetrikaSourceOfValue":"NO"}]}}}]}}},

      {"id": "1_negatives", "desc": f"Минус-слова кампании: 886 → {len(negs_clean)} (убрать «Жуковский», «быково»)",
       "svc": "campaigns", "method": "update",
       "params": {"Campaigns": [{"Id": CAMPAIGN_ID, "NegativeKeywords": {"Items": negs_clean}}]},
       "rollback": {"svc":"campaigns","method":"update",
                    "params":{"Campaigns":[{"Id":CAMPAIGN_ID,"NegativeKeywords":{"Items":negs_orig}}]}}},

      {"id": "2_geo", "desc": f"Гео {len(LIVE_GROUPS)} живых групп: Раменское → 17 регионов (город + Жуковский + 15 поселений)",
       "svc": "adgroups", "method": "update",
       "params": {"AdGroups": [{"Id": g, "RegionIds": ZONE17} for g in LIVE_GROUPS]},
       "rollback": {"svc":"adgroups","method":"update",
                    "params":{"AdGroups":[{"Id":g,"RegionIds":[CITY]} for g in LIVE_GROUPS]}}},

      {"id": "3a_kw_text", "desc": f"{len(kw_updates)} живых фраз: сняты -!предлоги ({n_cleaned} шт.). Ставки не меняем: автостратегия их игнорирует (warning 10160)",
       "svc": "keywords", "method": "update",
       "params": {"Keywords": [{"Id": u["Id"], "Keyword": u["Keyword"]} for u in kw_updates]}},

      {"id": "4_kw_suspend", "desc": f"{len(dead_ids)} мёртвых фраз монстр-группы → пауза",
       "svc": "keywords", "method": "suspend", "params": {"SelectionCriteria": {"Ids": dead_ids}},
       "rollback": {"svc":"keywords","method":"resume","params":{"SelectionCriteria":{"Ids":dead_ids}}}},

      {"id": "5_autotarget", "desc": f"Автотаргетинг {len(at_ids)} живых групп: ВЫКЛ «бренды конкурентов» (целевые/свой бренд/без бренда — вкл)",
       "svc": "keywords", "method": "update",
       "params": {"Keywords": [{"Id": i, "AutotargetingCategories": AT_CATEGORIES,
                                "AutotargetingBrandOptions": AT_BRANDS} for i in at_ids]},
       "rollback": {"svc":"keywords","method":"update",
                    "params":{"Keywords":[{"Id":i,"AutotargetingCategories":AT_CATEGORIES_OLD,
                                           "AutotargetingBrandOptions":AT_BRANDS} for i in at_ids]}}},


      {"id": "7_groups_add", "desc": f"Создать {len(NEW_GROUPS)} новых групп: " + ", ".join(g['name'] for g in NEW_GROUPS),
       "svc": "adgroups", "method": "add",
       "params": {"AdGroups": [{"CampaignId": CAMPAIGN_ID, "Name": g["name"], "RegionIds": g["regions"],
                                **({"NegativeKeywords": {"Items": g["negatives"]}} if g["negatives"] else {})}
                               for g in NEW_GROUPS]},
       "creates_groups": [g["name"] for g in NEW_GROUPS]},
    ]
    return steps, phrases, at_ids, dead_ids, negs_orig

def post_group_steps(client, group_ids_by_name, state):
    """Шаги, зависящие от ID новых групп (после 7_groups_add)."""
    steps = []
    kw_items, ad_items, at_items = [], [], []
    for g in NEW_GROUPS:
        gid = group_ids_by_name[g["name"]]
        for k in g["keys"]:
            kw_items.append({"Keyword": k, "AdGroupId": gid})
        t1, t2, tx, href, disp = g["ad"]
        p = ad_payload(t1, t2, tx, href, disp); p["AdGroupId"] = gid
        ad_items.append(p)
        at_items.append({"Keyword": "---autotargeting", "AdGroupId": gid,
                         "AutotargetingCategories": AT_CATEGORIES, "AutotargetingBrandOptions": AT_BRANDS})
    steps.append({"id": "8_keys_new_groups", "desc": f"{len(kw_items)} ключей в 7 новых групп",
                  "svc":"keywords","method":"add","params":{"Keywords": kw_items}})
    steps.append({"id": "9_autotarget_new", "desc": "Автотаргетинг (целевые+свой бренд+без бренда) в 7 новых групп — best effort",
                  "svc":"keywords","method":"add","params":{"Keywords": at_items}, "best_effort": True})
    # объявления: 11 в живые группы + 7 в новые
    ads_live = []
    for gid, (t1,t2,tx,href,disp) in ADS_FOR_LIVE.items():
        p = ad_payload(t1,t2,tx,href,disp); p["AdGroupId"] = gid
        ads_live.append(p)
    steps.append({"id": "10_ads_live", "desc": f"{len(ads_live)} новых объявлений в 11 живых групп (T2 заполнен, A/B)",
                  "svc":"ads","method":"add","params":{"Ads": ads_live}})
    steps.append({"id": "11_ads_new", "desc": f"{len(ad_items)} объявлений в 7 новых групп (с быстрыми ссылками, уточнениями, визиткой)",
                  "svc":"ads","method":"add","params":{"Ads": ad_items}})
    return steps

# ---------------------------------------------------------------- execute
def main():
    mode = 'dry'
    if '--apply' in sys.argv: mode = 'apply'
    if '--rollback' in sys.argv: mode = 'rollback'

    errs = validate_ads()
    if errs:
        print("ОШИБКА лимитов объявлений:"); [print("  ", e) for e in errs]; sys.exit(1)

    cfg = load_config(); client = DirectClient(cfg)
    steps, phrases, at_ids, dead_ids, negs_orig = build_steps()

    if mode == 'dry':
        print("="*95)
        print(f"DRY-RUN — ПЛАН ИЗМЕНЕНИЙ кампании {CAMPAIGN_ID} «[ПОИСК] Доставка Раменское»")
        print("="*95)
        tot_kw_new = len(MONSTER_NEW_KEYS) + sum(len(g["keys"]) for g in NEW_GROUPS)
        for s in steps:
            print(f"\n[{s['id']}] {s['desc']}")
        print(f"\n[8_keys_new_groups] {tot_kw_new - len(MONSTER_NEW_KEYS)} ключей в 7 новых групп")
        print(f"[9_autotarget_new] автотаргетинг (целевые/свой бренд/без бренда; конкуренты ВЫКЛ) в 7 новых групп")
        print(f"[10_ads_live] {len(ADS_FOR_LIVE)} новых объявлений в живые группы")
        print(f"[11_ads_new] 7 объявлений в новые группы")
        print("\n" + "-"*95)
        print(f"ИТОГО: минус-слова −2 | гео 11 групп → 17 регионов | фраз обновлено {len(phrases)} "
              f"(снято -!операторов, ставка 450) | пауза {len(dead_ids)} мёртвых фраз | "
              f"автотаргетинг: конкуренты ВЫКЛ в {len(at_ids)} группах | +7 групп | "
              f"+{tot_kw_new} ключей | +{len(ADS_FOR_LIVE)+len(NEW_GROUPS)} объявлений")
        print("\nНовые группы и ключи:")
        for g in NEW_GROUPS:
            geo = 'Жуковский' if g['regions']==[ZHUK] else ('Москва и область' if g['regions']==BRAND_GEO else '17 регионов зоны')
            print(f"  • {g['name']:36} | гео: {geo:16} | ключей: {len(g['keys']):>2} | T1: «{g['ad'][0]}»")
        print(f"\nЗапуск: python3 apply_changes.py --apply   |   Откат: --rollback")
        return

    if mode == 'rollback':
        if not os.path.exists(STATE_PATH):
            print("Нет apply_state.json — откатывать нечего"); return
        state = json.load(open(STATE_PATH))
        print("ОТКАТ...")
        for entry in reversed(state.get('applied', [])):
            rb = entry.get('rollback')
            if not rb:
                print(f"  [{entry['id']}] нет авто-отката (созданные объекты) — приостанавливаем")
                for svc, ids in (('ads', entry.get('created_ad_ids', [])),
                                 ('keywords', entry.get('created_kw_ids', []))):
                    if ids:
                        try: client.call(svc, 'suspend', {"SelectionCriteria": {"Ids": ids}}); print(f"    suspend {svc}: {len(ids)}")
                        except DirectError as e: print(f"    ERR suspend {svc}: {e}")
                continue
            try:
                client.call(rb['svc'], rb['method'], rb['params'])
                print(f"  [{entry['id']}] откачено")
            except DirectError as e:
                print(f"  [{entry['id']}] ОШИБКА отката: {e}")
        print("Откат завершён (новые группы приостановлены, обновления восстановлены).")
        return

    # ---- APPLY ----
    print("ПРИМЕНЕНИЕ ИЗМЕНЕНИЙ (production)...")
    if os.path.exists(STATE_PATH):
        state = json.load(open(STATE_PATH))
        done = {e["id"] for e in state.get("applied", [])}
        if done: print(f"Возобновление: уже применено {sorted(done)} — пропускаю их")
    else:
        done = set()
        state = {"started": datetime.datetime.now().isoformat(), "applied": []}
    def save():
        with open(STATE_PATH, 'w') as f: json.dump(state, f, ensure_ascii=False, indent=1)

    group_ids_by_name = state.get("group_ids_by_name", {})
    all_steps = list(steps)
    i = 0
    while i < len(all_steps):
        s = all_steps[i]
        if s["id"] in done:
            print(f"\n[{s['id']}] ПРОПУЩЕН (уже применён)")
            if s["id"] == "7_groups_add" and not any(x["id"] == "8_keys_new_groups" for x in all_steps):
                all_steps.extend(post_group_steps(client, group_ids_by_name, state))
            i += 1
            continue
        print(f"\n[{s['id']}] {s['desc']}")
        try:
            res = client.call(s['svc'], s['method'], s['params'])
        except DirectError as e:
            if s.get('best_effort'):
                print(f"  best-effort пропущен: {str(e)[:200]}"); i += 1; continue
            print(f"  ОШИБКА: {e}\nСТОП. Выполнен откат? Нет — состояние сохранено, можно --rollback.")
            save(); sys.exit(2)
        entry = {"id": s['id'], "rollback": s.get('rollback'), "ts": datetime.datetime.now().isoformat()}
        if s['method'] == 'add':
            ids, errors, warnings = collect_add_results(res, 'add')
            created = [x for x in ids if x is not None]
            if s.get('creates_groups'):
                for nm, gid in zip(s['creates_groups'], ids):
                    if gid: group_ids_by_name[nm] = gid
                entry['created_group_ids'] = created
                entry['group_ids_by_name'] = group_ids_by_name
                state['group_ids_by_name'] = group_ids_by_name
                # подставляем остальные шаги после создания групп
                if not any(x['id'] == '8_keys_new_groups' for x in all_steps):
                    all_steps.extend(post_group_steps(client, group_ids_by_name, state))
            if s['svc'] == 'keywords': entry['created_kw_ids'] = created
            if s['svc'] == 'ads': entry['created_ad_ids'] = created
            print(f"  создано: {len(created)}", end="")
            if errors: print(f" | ОШИБКИ: {errors[:5]}", end="")
            if warnings: print(f" | warn: {len(warnings)}", end="")
            print()
        else:
            upd = res.get('UpdateResults') or []
            n_err = sum(len(r.get('Errors') or []) for r in upd)
            print(f"  обновлено объектов: {len(upd) if upd else 'ok'}" + (f" | ошибок: {n_err}" if n_err else ""))
        state['applied'].append(entry); save()
        i += 1

    state['finished'] = datetime.datetime.now().isoformat()
    save()
    print("\n✅ ГОТОВО. Созданные группы:", json.dumps(group_ids_by_name, ensure_ascii=False))
    print("Состояние/откат: analysis/apply_state.json (--rollback)")

if __name__ == '__main__':
    main()
