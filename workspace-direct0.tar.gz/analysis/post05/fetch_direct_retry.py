#!/usr/bin/env python3
"""Повторный сбор данных из Яндекс.Директа для анализа периода 05.10–10.10.2026.

16.10.2026 API Директа был недоступен (любой запрос -> пустой HTTP 204,
включая GET без токена; Метрика при этом работала — значит, дело не в токене).
Скрипт сначала ПРОБЕЕТ API и, если он ожил, добирает:
  1. Состояния/статусы/бюджеты 5 кампаний
  2. Статусы 11 изменённых ключей Раунда 3 (9 закавыченных + 2 близнеца)
  3. Отчёт по кампаниям ежедневно 29.09–15.10
  4. Критерии (ключи) кампании 40732207: окна BEFORE/AFTER
  5. Поисковые запросы 40732207: окна BEFORE/AFTER

Запуск (из /home/user, фоном — поллинг отчётов может быть долгим):
  nohup python3 analysis/post05/fetch_direct_retry.py > analysis/post05/retry.log 2>&1 &
  tail -f analysis/post05/retry.log
Скрипт идемпотентен: уже скачанные .tsv пропускаются.
"""
import json, os, sys, time, urllib.request, urllib.error

sys.path.insert(0, os.path.join("skills_repo", "extracted1", "skill_for_claude_code_yandex_direct-main", "scripts"))
from direct_api import DirectClient, load_config

cfg = load_config(os.path.join("skills_repo", "extracted1", "skill_for_claude_code_yandex_direct-main", "scripts", "config.json"))
client = DirectClient(cfg)
OUT = os.path.join("analysis", "post05")
os.makedirs(OUT, exist_ok=True)

BEFORE = ("2026-09-29", "2026-10-04")
AFTER = ("2026-10-05", "2026-10-10")
FULL = ("2026-09-29", "2026-10-15")
CAMP = 40732207
CAMPS = [40732207, 704504054, 704507321, 76065880, 52821021]
KW_IDS = [58167571703, 58167571705, 58167571704, 58168345594, 58167571673,
          58167571672, 58167571679, 58167571645, 58168248834,   # 9 закавыченных
          58207392998, 58207392999]                              # 2 близнеца

# ---------- 0. ПРОБЕ: жив ли API ----------
def probe():
    url = client.base + "campaigns"
    body = json.dumps({"method": "get", "params": {"SelectionCriteria": {}, "FieldNames": ["Id"], "Page": {"Limit": 1}}}).encode()
    req = urllib.request.Request(url, data=body, headers=client._headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            code, text = r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        code, text = e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        print(f"[PROBE] network error: {e}", flush=True)
        return False
    if code == 200 and text.strip():
        print(f"[PROBE] API жив (200, units {client.last_units})", flush=True)
        return True
    print(f"[PROBE] API НЕ отвечает (HTTP {code}, {len(text)} байт). Не трогать отчёты, повторить позже.", flush=True)
    return False

if not probe():
    sys.exit(1)

# ---------- 1. Состояния кампаний ----------
try:
    r = client.call("campaigns", "get", {
        "SelectionCriteria": {"Ids": CAMPS},
        "FieldNames": ["Id", "Name", "State", "Status", "StatusPayment", "DailyBudget", "StartDate", "FundsData"]})
    json.dump(r, open(os.path.join(OUT, "campaigns_state.json"), "w"), ensure_ascii=False, indent=1)
    print(f"[OK] campaigns_state: {len(r.get('Campaigns', []))} кампаний", flush=True)
except Exception as e:
    print(f"[FAIL] campaigns.get: {e}", flush=True)

# ---------- 2. Статусы изменённых ключей ----------
try:
    r = client.call("keywords", "get", {
        "SelectionCriteria": {"Ids": KW_IDS},
        "FieldNames": ["Id", "Keyword", "State", "Status", "Bid", "AdGroupId", "CampaignId"]})
    json.dump(r, open(os.path.join(OUT, "keywords_round3_state.json"), "w"), ensure_ascii=False, indent=1)
    print(f"[OK] keywords_round3_state: {len(r.get('Keywords', []))} ключей", flush=True)
except Exception as e:
    print(f"[FAIL] keywords.get: {e}", flush=True)

# ---------- 2b. URL объявлений (Href) — сверка с новым сайтом (переезд 12.10) ----------
try:
    r = client.call("ads", "get", {
        "SelectionCriteria": {"CampaignIds": [40732207, 704504054, 704507321]},
        "FieldNames": ["Id", "CampaignId", "AdGroupId", "State", "Status", "Type", "TextAd"]})
    json.dump(r, open(os.path.join(OUT, "ads_hrefs.json"), "w"), ensure_ascii=False, indent=1)
    ads = r.get("Ads", [])
    hrefs = sorted(set(a.get("TextAd", {}).get("Href", "") for a in ads if a.get("TextAd")))
    print(f"[OK] ads_hrefs: {len(ads)} объявлений, уникальных Href: {len(hrefs)}", flush=True)
    for h in hrefs:
        print("     ", h, flush=True)
except Exception as e:
    print(f"[FAIL] ads.get: {e}", flush=True)

# ---------- 2c. Набор быстрых ссылок 1384724168 (их URL не видны локально) ----------
try:
    r = client.call("adextensions", "get", {
        "SelectionCriteria": {"Ids": [1384724168]},
        "FieldNames": ["Sitelinks"]})
    json.dump(r, open(os.path.join(OUT, "sitelinks_1384724168.json"), "w"), ensure_ascii=False, indent=1)
    print(f"[OK] sitelinks: {json.dumps(r, ensure_ascii=False)[:500]}", flush=True)
except Exception as e:
    print(f"[FAIL] adextensions.get: {e}", flush=True)

# ---------- 3. Отчёты (терпеливый поллинг, два варианта формата) ----------
def report_patient(name, rtype_variants, fields, dates, camp_filter=None, max_wait=900):
    path = os.path.join(OUT, name + ".tsv")
    if os.path.exists(path):
        print(f"[SKIP] {name}", flush=True)
        return path
    variants = []
    for rt in rtype_variants:
        d = {"ReportName": f"{name}_{rt}", "ReportType": rt, "DateRangeType": "CUSTOM_DATE",
             "DateFrom": dates[0], "DateTo": dates[1], "FieldNames": fields,
             "Format": "TSV", "IncludeVAT": "NO", "IncludeDiscount": "NO"}
        if camp_filter:
            d["SelectionCriteria"] = {"Filter": [{"Field": "CampaignId", "Operator": "EQUALS", "Values": [str(camp_filter)]}]}
            d["Filter"] = {"Field": "CampaignId", "Operator": "EQUALS", "Value": str(camp_filter)}  # старый формат как fallback-поле
        variants.append(d)
    extra = {"processingMode": "auto", "returnMoneyInMicros": "false",
             "skipReportHeader": "true", "skipColumnHeader": "true", "skipReportSummary": "true"}
    t0, attempt = time.time(), 0
    while time.time() - t0 < max_wait:
        for d in variants:
            attempt += 1
            body = json.dumps({"params": d}, ensure_ascii=False).encode()
            req = urllib.request.Request(client.reports_url, data=body, headers=client._headers(extra), method="POST")
            try:
                with urllib.request.urlopen(req, timeout=120) as resp:
                    if resp.getcode() == 200:
                        text = resp.read().decode()
                        open(path, "w", encoding="utf-8").write("\t".join(fields) + "\n" + text)
                        n = len([l for l in text.splitlines() if l.strip()])
                        print(f"[OK] {name}: {n} строк ({attempt} попыток, units {client.last_units})", flush=True)
                        return path
            except urllib.error.HTTPError as e:
                if e.code in (201, 202):
                    retry = int(e.headers.get("retryIn", 10) or 10)
                    time.sleep(min(max(retry, 3), 30))
                    break  # ждать — повторить внешний цикл
                if e.code == 400 and d is variants[0] and len(variants) > 1:
                    print(f"[WARN] {name}: формат {d['ReportType']} отклонён (400), пробую следующий", flush=True)
                    variants.remove(d)
                    break
                det = e.read().decode("utf-8", "replace")[:200]
                print(f"[ERR] {name}: HTTP {e.code} {det}", flush=True)
                return None
            except Exception as e:
                print(f"[ERR] {name}: {e}", flush=True)
                time.sleep(5)
        else:
            time.sleep(3)
    print(f"[TIMEOUT] {name} после {attempt} попыток", flush=True)
    return None

F_CAMP_DAILY = sorted(["Date", "CampaignId", "CampaignName", "Impressions", "Clicks", "Ctr", "Cost", "AvgCpc", "Conversions", "CostPerConversion"])
F_CRIT = sorted(["CampaignId", "AdGroupId", "AdGroupName", "CriterionId", "Criterion", "CriterionType",
                 "Impressions", "Clicks", "Ctr", "Cost", "AvgCpc", "Conversions", "CostPerConversion"])
F_SQ = sorted(["CampaignId", "AdGroupId", "AdGroupName", "CriterionId", "Criterion", "Query",
               "Impressions", "Clicks", "Cost", "Conversions"])

jobs = [
    ("camps_daily_0929_1015", ["CAMPAIGN_PERFORMANCE_REPORT", "CAMPAIGN_PERFORMANCE"], F_CAMP_DAILY, FULL, None),
    ("crit_40732207_before", ["CRITERIA_PERFORMANCE_REPORT", "CRITERIA_PERFORMANCE"], F_CRIT, BEFORE, CAMP),
    ("crit_40732207_after", ["CRITERIA_PERFORMANCE_REPORT", "CRITERIA_PERFORMANCE"], F_CRIT, AFTER, CAMP),
    ("sq_40732207_before", ["SEARCH_QUERY_PERFORMANCE_REPORT", "SEARCH_QUERY_PERFORMANCE"], F_SQ, BEFORE, CAMP),
    ("sq_40732207_after", ["SEARCH_QUERY_PERFORMANCE_REPORT", "SEARCH_QUERY_PERFORMANCE"], F_SQ, AFTER, CAMP),
]
for name, rts, fields, window, cf in jobs:
    report_patient(name, rts, fields, window, cf)

print("DONE", flush=True)
