#!/usr/bin/env python3
"""Дозагрузка: отчёты с терпеливым поллингом + Метрика с ym:ad: метриками."""
import json, os, sys, time, urllib.request, urllib.parse, urllib.error

sys.path.insert(0, os.path.join("skills_repo", "extracted1", "skill_for_claude_code_yandex_direct-main", "scripts"))
from direct_api import DirectClient, load_config

cfg = load_config(os.path.join("skills_repo", "extracted1", "skill_for_claude_code_yandex_direct-main", "scripts", "config.json"))
client = DirectClient(cfg)
OUT = os.path.join("analysis", "post05")
os.makedirs(OUT, exist_ok=True)

BEFORE = ("2026-09-29", "2026-10-04")
AFTER = ("2026-10-05", "2026-10-10")
FULL = ("2026-09-29", "2026-10-15")
CAMP = 40732207

def report_patient(name, rtype, fields, dates, flt=None, max_wait=900):
    d = {"ReportName": name, "ReportType": rtype, "DateRangeType": "CUSTOM_DATE",
         "DateFrom": dates[0], "DateTo": dates[1], "FieldNames": fields,
         "IncludeVAT": "NO", "IncludeDiscount": "NO"}
    if flt: d["Filter"] = flt
    body = json.dumps({"params": d}, ensure_ascii=False).encode()
    headers = client._headers({"processingMode": "auto", "returnMoneyInMicros": "false",
                               "skipReportHeader": "true", "skipColumnHeader": "true",
                               "skipReportSummary": "true"})
    t0 = time.time(); attempt = 0
    while time.time() - t0 < max_wait:
        attempt += 1
        req = urllib.request.Request(client.reports_url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                if resp.getcode() == 200:
                    text = resp.read().decode()
                    u = resp.headers.get("Units");
                    if u: client.last_units = u
                    path = os.path.join(OUT, name + ".tsv")
                    open(path, "w", encoding="utf-8").write("\t".join(fields) + "\n" + text)
                    n = len([l for l in text.splitlines() if l.strip()])
                    print(f"[OK] {name}: {n} rows, {attempt} attempts, units {client.last_units}", flush=True)
                    return path
                time.sleep(3)
        except urllib.error.HTTPError as e:
            if e.code in (201, 202):
                retry = int(e.headers.get("retryIn", 10) or 10)
                time.sleep(min(max(retry, 3), 30))
                continue
            det = e.read().decode("utf-8", "replace")[:300]
            print(f"[ERR] {name}: HTTP {e.code} {det}", flush=True)
            return None
        except Exception as e:
            print(f"[ERR] {name}: {e}", flush=True); time.sleep(5)
    print(f"[TIMEOUT] {name} after {attempt} attempts", flush=True)
    return None

flt_camp = {"Field": "CampaignId", "Operator": "EQUALS", "Value": str(CAMP)}
jobs = [
    ("camps_daily_0929_1015", "CAMPAIGN_PERFORMANCE",
     ["Date","CampaignId","CampaignName","Impressions","Clicks","Ctr","Cost","AvgCpc","Conversions"], FULL, None),
    ("crit_40732207_before", "CRITERIA_PERFORMANCE",
     ["CampaignId","AdGroupId","AdGroupName","CriterionId","Criterion","CriterionType","Impressions","Clicks","Ctr","Cost","AvgCpc","Conversions"], BEFORE, flt_camp),
    ("crit_40732207_after", "CRITERIA_PERFORMANCE",
     ["CampaignId","AdGroupId","AdGroupName","CriterionId","Criterion","CriterionType","Impressions","Clicks","Ctr","Cost","AvgCpc","Conversions"], AFTER, flt_camp),
    ("sq_40732207_before", "SEARCH_QUERY_PERFORMANCE",
     ["AdGroupId","AdGroupName","CriterionId","Criterion","CriterionType","Impressions","Clicks","Cost","Conversions"], BEFORE, flt_camp),
    ("sq_40732207_after", "SEARCH_QUERY_PERFORMANCE",
     ["AdGroupId","AdGroupName","CriterionId","Criterion","CriterionType","Impressions","Clicks","Cost","Conversions"], AFTER, flt_camp),
]
for name, rt, f, w, flt in jobs:
    if os.path.exists(os.path.join(OUT, name + ".tsv")):
        print(f"[SKIP] {name} already fetched", flush=True)
        continue
    report_patient(name, rt, f, w, flt, max_wait=1500)

# кампании — состояние (retry)
for a in range(3):
    try:
        r = client.call("campaigns", "get", {
            "SelectionCriteria": {"Ids": [40732207, 704504054, 704507321, 76065880, 52821021]},
            "FieldNames": ["Id","Name","State","Status","DailyBudget","StartDate"]})
        json.dump(r, open(os.path.join(OUT,"campaigns_state.json"),"w"), ensure_ascii=False, indent=1)
        print("[OK] campaigns_state", flush=True); break
    except Exception as e:
        print("[retry] campaigns.get:", e, flush=True); time.sleep(4)

# Метрика: цели + totals + by campaign (ym:ad: метрики)
tok = cfg["token"]; counter = cfg["metrica"]["counter_id"]
goals = [cfg["metrica"]["primary_goal_id"]] + cfg["metrica"]["secondary_goal_ids"]
def met_get(path, params):
    url = "https://api-metrika.yandex.net" + path + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Authorization": f"OAuth {tok}",
                                               "direct_client_logins": cfg["client_login"],
                                               "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        print(f"[FAIL] metrica {path}: {e.code} {e.read().decode()[:200]}", flush=True)
        return None

res = {}
g = met_get(f"/management/counters/{counter}/goals", {})
if g:
    res["goals"] = [{"id": x["id"], "name": x["name"]} for x in g.get("goals", [])]
    print("[OK] goals:", len(res["goals"]), flush=True)
m_s = ",".join(f"ym:s:goal{i}reaches" for i in goals)
m_ad = ",".join(f"ym:ad:goal{i}reaches" for i in goals)
for tag, w in (("before", BEFORE), ("after", AFTER)):
    d = met_get("/stat/v1/data", {"id": counter, "metrics": m_s, "date1": w[0], "date2": w[1]})
    if d: res[f"total_{tag}"] = d
    dc = met_get("/stat/v1/data", {"id": counter, "metrics": m_ad,
                                   "dimensions": "ym:ad:DirectOrder,ym:ad:DirectOrderName",
                                   "date1": w[0], "date2": w[1]})
    if dc: res[f"bycamp_{tag}"] = dc
    print(f"[done] metrica {tag}: total={'+' if d else '-'} bycamp={'+' if dc else '-'}", flush=True)
json.dump(res, open(os.path.join(OUT,"metrica_post05.json"),"w"), ensure_ascii=False, indent=1)
print("DONE", flush=True)
