#!/usr/bin/env python3
"""Сбор статистики после Раунда 3 (кавычки + минус-слова, 05.10).
Окна: BEFORE 2026-09-29..2026-10-04, AFTER 2026-10-05..2026-10-10.
Расширенный дневной срез кампаний: 2026-09-29..2026-10-15.
Всё складывает в analysis/post05/.
"""
import json, os, sys, urllib.request, urllib.parse, urllib.error

sys.path.insert(0, os.path.join("skills_repo", "extracted1", "skill_for_claude_code_yandex_direct-main", "scripts"))
from direct_api import DirectClient, load_config

cfg = load_config(os.path.join("skills_repo", "extracted1", "skill_for_claude_code_yandex_direct-main", "scripts", "config.json"))
client = DirectClient(cfg)
OUT = os.path.join("analysis", "post05")
os.makedirs(OUT, exist_ok=True)

BEFORE = ("2026-09-29", "2026-10-04")
AFTER = ("2026-10-05", "2026-10-10")
FULL = ("2026-09-29", "2026-10-15")
CAMP = 40732207

def rep(name, rtype, fields, dates, flt=None):
    d = {"ReportName": name, "ReportType": rtype, "DateRangeType": "CUSTOM_DATE",
         "DateFrom": dates[0], "DateTo": dates[1], "FieldNames": fields,
         "IncludeVAT": "NO", "IncludeDiscount": "NO"}
    if flt:
        d["Filter"] = flt
    try:
        tsv = client.report(d, skip_report_header=True, skip_column_header=True)
    except Exception as e:
        print(f"[FAIL] {name}: {e}")
        return None
    path = os.path.join(OUT, name + ".tsv")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\t".join(fields) + "\n" + tsv)
    n = len([l for l in tsv.splitlines() if l.strip()])
    print(f"[OK] {name}: {n} rows (units {client.last_units})")
    return path

# 1. Кампании, ежедневно (срежем окна локально)
rep("camps_daily_0929_1015", "CAMPAIGN_PERFORMANCE",
    ["Date", "CampaignId", "CampaignName", "Impressions", "Clicks", "Ctr", "Cost", "AvgCpc", "Conversions"],
    FULL)

flt_camp = {"Field": "CampaignId", "Operator": "EQUALS", "Value": str(CAMP)}
# 2. Ключи/критерии кампании — два окна
for tag, w in (("before", BEFORE), ("after", AFTER)):
    rep(f"crit_40732207_{tag}", "CRITERIA_PERFORMANCE",
        ["CampaignId", "AdGroupId", "AdGroupName", "CriterionId", "Criterion", "CriterionType",
         "Impressions", "Clicks", "Ctr", "Cost", "AvgCpc", "Conversions"], w, flt_camp)
# 3. Поисковые запросы — два окна
for tag, w in (("before", BEFORE), ("after", AFTER)):
    ok = rep(f"sq_40732207_{tag}", "SEARCH_QUERY_PERFORMANCE",
             ["AdGroupId", "AdGroupName", "CriterionId", "Criterion", "CriterionType",
              "Impressions", "Clicks", "Cost", "Conversions"], w, flt_camp)
    if ok is None:  # retry без Conversions
        rep(f"sq_40732207_{tag}", "SEARCH_QUERY_PERFORMANCE",
            ["AdGroupId", "AdGroupName", "CriterionId", "Criterion", "CriterionType",
             "Impressions", "Clicks", "Cost"], w, flt_camp)

# 4. Текущие состояния кампаний
try:
    r = client.call("campaigns", "get", {
        "SelectionCriteria": {"Ids": [40732207, 704504054, 704507321, 76065880, 52821021]},
        "FieldNames": ["Id", "Name", "State", "Status", "DailyBudget", "StartDate"]})
    json.dump(r, open(os.path.join(OUT, "campaigns_state.json"), "w"), ensure_ascii=False, indent=1)
    print("[OK] campaigns_state.json", len(r.get("result", {}).get("Campaigns", [])))
except Exception as e:
    print("[FAIL] campaigns.get:", e)

# 5. Метрика: цели + охваты по окнам (весь счётчик и в разрезе кампаний Direct)
tok = cfg["token"]; counter = cfg["metrica"]["counter_id"]
goals = [cfg["metrica"]["primary_goal_id"]] + cfg["metrica"]["secondary_goal_ids"]

def met_get(path, params):
    url = "https://api-metrika.yandex.net" + path + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Authorization": f"OAuth {tok}",
                                               "direct_client_logins": cfg["client_login"]})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        print(f"[FAIL] metrica {path} {params.get('ids','')} {params.get('metrics','')[:60]}: {e.code} {e.read().decode()[:200]}")
        return None

res = {}
try:
    g = met_get(f"/management/counters/{counter}/goals", {})
    res["goals"] = [{"id": x["id"], "name": x["name"]} for x in g.get("goals", [])]
    print("[OK] metrica goals:", len(res["goals"]))
except Exception as e:
    print("[FAIL] goals:", e)

metrics = ",".join(f"ym:s:goal{gid}reaches" for gid in goals)
for tag, w in (("before", BEFORE), ("after", AFTER)):
    d = met_get(f"/stat/v1/data", {"id": counter, "metrics": metrics,
                                   "date1": w[0], "date2": w[1]})
    if d: res[f"total_{tag}"] = d
    # по кампаниям Direct
    dc = met_get(f"/stat/v1/data", {"id": counter, "metrics": metrics,
                                    "dimensions": "ym:ad:DirectOrder,ym:ad:DirectOrderName",
                                    "date1": w[0], "date2": w[1]})
    if dc: res[f"bycamp_{tag}"] = dc
    print(f"[{'OK' if d else 'FAIL'}] metrica {tag}")
json.dump(res, open(os.path.join(OUT, "metrica_post05.json"), "w"), ensure_ascii=False, indent=1)
print("DONE")
