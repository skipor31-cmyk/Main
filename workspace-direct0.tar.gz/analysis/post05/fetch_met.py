#!/usr/bin/env python3
"""Метрика-данные для анализа после Раунда 3 (изменения 05.10.2026).
Окна: BEFORE 2026-09-29..2026-10-04, AFTER 2026-10-05..2026-10-10.
Результат: analysis/post05/metrica_full.json
"""
import json, os, sys, time, urllib.request, urllib.parse, urllib.error

sys.path.insert(0, os.path.join("skills_repo", "extracted1", "skill_for_claude_code_yandex_direct-main", "scripts"))
from direct_api import load_config

cfg = load_config(os.path.join("skills_repo", "extracted1", "skill_for_claude_code_yandex_direct-main", "scripts", "config.json"))
tok = cfg["token"]; counter = cfg["metrica"]["counter_id"]; login = cfg["client_login"]
OUT = os.path.join("analysis", "post05")

BEFORE = ("2026-09-29", "2026-10-04")
AFTER = ("2026-10-05", "2026-10-10")
TREND = ("2026-09-25", "2026-10-15")
MAIN_CAMP = "40732207"

# основные цели (из config) + расширенная воронка
G_CORE = [cfg["metrica"]["primary_goal_id"]] + cfg["metrica"]["secondary_goal_ids"]
G_FUNNEL = [36895973, 49487656, 49487221, 512002319, 568074580, 575272764, 168348274, 201476773]
G_ALL = G_CORE + G_FUNNEL

def met_get(params, tries=3, ad=False):
    url = "https://api-metrika.yandex.net/stat/v1/data?" + urllib.parse.urlencode(params, doseq=True)
    hdr = {"Authorization": f"OAuth {tok}", "Accept": "application/json"}
    if not ad:
        hdr["direct_client_logins"] = login
    for i in range(tries):
        req = urllib.request.Request(url, headers=hdr)
        try:
            with urllib.request.urlopen(req, timeout=90) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")[:300]
            print(f"[FAIL {e.code}] {params.get('metrics','')[:60]}... {body}", flush=True)
            if e.code in (429, 500, 502, 503): time.sleep(3 * (i + 1)); continue
            return {"_error": e.code, "_body": body}
        except Exception as e:
            print(f"[EXC] {e}", flush=True); time.sleep(3)
    return {"_error": "retries"}

res = {}
m_core = ",".join(f"ym:s:goal{i}reaches" for i in G_ALL)
m_ad_core = ",".join(f"ym:ad:goal{i}reaches" for i in G_ALL)

# 1. Totals: сайт целиком (сессии, поведение, все цели) — оба окна
for tag, w in (("before", BEFORE), ("after", AFTER)):
    res[f"site_{tag}"] = met_get({"id": counter,
        "metrics": ",".join(["ym:s:visits", "ym:s:users", "ym:s:pageviews",
                             "ym:s:bounceRate", "ym:s:avgVisitDurationSeconds", m_core]),
        "date1": w[0], "date2": w[1]})
    print(f"[ok] site_{tag}", flush=True)

# 2. Totals: только рекламный трафик Direct (ym:ad:) — оба окна
for tag, w in (("before", BEFORE), ("after", AFTER)):
    res[f"ad_{tag}"] = met_get({"id": counter,
        "metrics": ",".join(["ym:ad:visits", "ym:ad:goal36895733reaches",
                             "ym:ad:goal168348169reaches", "ym:ad:goal136163740reaches",
                             "ym:ad:goal197752867reaches", "ym:ad:goal339702220reaches",
                             "ym:ad:goal168348397reaches", "ym:ad:goal36895973reaches",
                             "ym:ad:goal49487656reaches"]),
        "date1": w[0], "date2": w[1]}, ad=True)
    print(f"[ok] ad_{tag}", flush=True)

# 3. В разрезе кампаний Direct — оба окна
for tag, w in (("before", BEFORE), ("after", AFTER)):
    res[f"bycamp_{tag}"] = met_get({"id": counter,
        "dimensions": "ym:ad:DirectOrder,ym:ad:DirectOrderName",
        "metrics": ",".join(["ym:ad:visits", "ym:ad:goal36895733reaches",
                             "ym:ad:goal168348169reaches", "ym:ad:goal136163740reaches",
                             "ym:ad:goal197752867reaches", "ym:ad:goal339702220reaches",
                             "ym:ad:goal168348397reaches", "ym:ad:goal36895973reaches"]),
        "date1": w[0], "date2": w[1], "limit": 200}, ad=True)
    print(f"[ok] bycamp_{tag}", flush=True)

# 4. Ежедневный тренд: сайт + Direct + ключевые цели
res["daily"] = met_get({"id": counter,
    "dimensions": "ym:s:date",
    "metrics": ",".join(["ym:s:visits",
                         "ym:s:goal36895733reaches", "ym:s:goal168348169reaches",
                         "ym:s:goal136163740reaches", "ym:s:goal197752867reaches",
                         "ym:s:goal339702220reaches", "ym:s:goal168348397reaches"]),
    "date1": TREND[0], "date2": TREND[1], "limit": 100})
# 4b. Ежедневные визиты из Директа (весь аккаунт) — фильтр по lastTrafficSource
res["daily_ad"] = met_get({"id": counter,
    "dimensions": "ym:s:date",
    "metrics": "ym:s:visits",
    "date1": TREND[0], "date2": TREND[1],
    "filters": "ym:s:lastTrafficSource=='ad'", "limit": 100})
print("[ok] daily_ad", flush=True)
print("[ok] daily", flush=True)

# 5. Ежедневные сессии главной кампании 40732207
res["daily_main_camp"] = met_get({"id": counter,
    "dimensions": "ym:s:date",
    "metrics": "ym:s:visits",
    "date1": TREND[0], "date2": TREND[1],
    "filters": f"ym:ad:DirectOrder=='{MAIN_CAMP}'", "limit": 100})
print("[ok] daily_main_camp", flush=True)

# 6. Источники трафика — оба окна (доля платного поиска)
for tag, w in (("before", BEFORE), ("after", AFTER)):
    res[f"src_{tag}"] = met_get({"id": counter,
        "dimensions": "ym:s:lastTrafficSource",
        "metrics": ",".join(["ym:s:visits", "ym:s:goal36895733reaches",
                             "ym:s:goal168348169reaches", "ym:s:goal168348397reaches"]),
        "date1": w[0], "date2": w[1], "limit": 50})
    print(f"[ok] src_{tag}", flush=True)

json.dump(res, open(os.path.join(OUT, "metrica_full.json"), "w"), ensure_ascii=False, indent=1)
print("SAVED metrica_full.json", flush=True)
