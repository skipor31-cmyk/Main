#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Восстановление операторов (кавычки) по схеме владельца из архивных кампаний
+ закрытие дыр покрытия закавыченными близнецами + расширение минус-слов
против паразитных показов. Кампания 40732207.

Основание (проверено 05.10.2026 через API):
  * Фраза «"цветы раменское"» жила в АРХИВНОЙ кампании 43868759 «[ПОИСК] ВЧ - Раменское»
    (в паре с «"цветы в раменском"»). При майнинге в М1 ключ переехал БЕЗ кавычек.
  * «"заказать цветы жуковский"» — архив 51212600, у нас в Д5 без кавычек.
  * «"магазин цветов"», «"заказать букет"», «"заказать букет цветов"»,
    «"купить букет цветов"», «"купить живые цветы"», «"заказать цветы"» —
    были закавычены в архивных ВЧ-кампаниях 42279039 / 41986564 / 114946710.
  * «цветочный раменское» (М1) — без кавычек ловит бренды конкурентов
    («цветочный рай раменское», «цветочный дворик раменское» и т.п.).
  * Минус-слова: на сайте flowerpoetry.ru нет ритуальной категории, не продаются
    шары/цифры/гирлянды/искусственные цветы; сухоцветы — решение владельца не запускать.
    Слова «клумба», «шар», «опт», «сад», «своими», «фото», «рисун», «конфет» и пр. уже есть.

Режимы:
    python3 apply_operators.py            # DRY-RUN: показать план
    python3 apply_operators.py --apply    # применить
    python3 apply_operators.py --rollback # откатить (по apply_state_operators.json)
"""
import json, os, sys, datetime

ROOT = os.path.dirname(os.path.abspath(__file__))          # .../analysis
WS   = os.path.dirname(ROOT)
SCRIPTS = os.path.join(WS, 'skills_repo', 'extracted1',
                       'skill_for_claude_code_yandex_direct-main', 'scripts')
sys.path.insert(0, SCRIPTS)
os.chdir(SCRIPTS)  # чтобы load_config нашёл config.json

from direct_api import DirectClient, load_config, DirectError

CAMPAIGN_ID = 40732207
STATE_PATH  = os.path.join(ROOT, 'apply_state_operators.json')

M1_GID, D5_GID = 5806224426, 5806224424

# (Id ключа, группа, старый текст, новый текст, причина)
UPDATES = [
    (58167571703, 'М1', 'цветы раменское',        '"цветы раменское"',        'фраза владельца из архива 43868759'),
    (58167571705, 'М1', 'магазин цветов',          '"магазин цветов"',          'в архивах 42279039/114946710 была в кавычках'),
    (58167571704, 'М1', 'цветочный раменское',     '"цветочный раменское"',     'ловит бренды конкурентов (цветочный рай/дворик …)'),
    (58168345594, 'К2', 'заказать букет',          '"заказать букет"',          'в архиве 41986564 была в кавычках'),
    (58167571673, 'К2', 'заказать букет цветов',   '"заказать букет цветов"',   'в архиве 41986564 была в кавычках'),
    (58167571672, 'К2', 'купить букет цветов',     '"купить букет цветов"',     'в архиве 41986564 была в кавычках'),
    (58167571679, 'К2', 'купить живые цветы',      '"купить живые цветы"',      'в архиве 41986564 была в кавычках'),
    (58167571645, 'Д3', 'заказать цветы',          '"заказать цветы"',          'в архиве 41986564 была в кавычках'),
    (58168248834, 'Д5', 'заказать цветы жуковский', '"заказать цветы жуковский"', 'в архиве 51212600 была в кавычках'),
]

# близнецы с предлогом «в» — закрывают запросы «… в раменском/в жуковском»,
# которые перестанут ловиться закавыченными основными фразами
# (в архиве 43868759 пара «"цветы раменское"» + «"цветы в раменском"» сосуществовала)
ADDS = [
    (M1_GID, 'М1', '"цветы в раменском"'),
    (D5_GID, 'Д5', '"заказать цветы в жуковском"'),
]

# новые минус-слова кампании (без префикса «-», формат как в campaign_negatives_clean.json)
NEG_ADD = [
    'ритуальный', 'кладбище', 'похороны', 'траур', 'венок', 'памятник', 'гроб',
    'оформление', 'зал', 'гирлянда', 'цифра', 'искусственный', 'сухоцвет',
    'склад', 'огород', 'раскраска',
]


def log(*a):
    print(*a, flush=True)


def fetch_keywords(client, ids):
    out = {}
    for i in range(0, len(ids), 10000):
        r = client.call('keywords', 'get', {
            'SelectionCriteria': {'Ids': ids[i:i+10000]},
            'FieldNames': ['Id', 'Keyword', 'State', 'Status', 'AdGroupId'],
        })
        for k in r.get('Keywords', []):
            out[k['Id']] = k
    return out


def fetch_negatives(client):
    r = client.call('campaigns', 'get', {
        'SelectionCriteria': {'Ids': [CAMPAIGN_ID]},
        'FieldNames': ['Id', 'NegativeKeywords'],
    })
    c = r['Campaigns'][0]
    return [n for n in c.get('NegativeKeywords', {}).get('Items', [])]


def do_apply(client):
    state = {'started': datetime.datetime.now().isoformat(timespec='seconds')}

    # --- 0. пре-проверка: старые тексты совпадают с ожидаемыми
    live = fetch_keywords(client, [u[0] for u in UPDATES])
    problems = []
    for kid, grp, old, new, why in UPDATES:
        cur = (live.get(kid) or {}).get('Keyword')
        if cur != old:
            problems.append(f'Id {kid} [{grp}]: ожидалось {old!r}, по факту {cur!r}')
    if problems:
        log('ПРЕ-ПРОВЕРКА НЕ ПРОЙДЕНА — ничего не применяем:')
        for p in problems:
            log('  ', p)
        sys.exit(1)
    log('Пре-проверка OK: все 9 ключей в ожидаемом виде.')

    # --- 1. кавычки (keywords.update)
    upd = [{'Id': kid, 'Keyword': new} for kid, grp, old, new, why in UPDATES]
    r = client.call('keywords', 'update', {'Keywords': upd})
    res = r.get('UpdateResults', [])
    ok = sum(1 for x in res if x.get('Code') in (0, None) and x.get('Id'))
    log(f'1) Кавычки: отправлено {len(upd)}, успешных результатов {ok}')
    for x in res:
        if x.get('Code') not in (0, None):
            log('   ОШИБКА:', json.dumps(x, ensure_ascii=False))
    state['updates'] = [{'id': kid, 'group': grp, 'old': old, 'new': new, 'why': why}
                        for kid, grp, old, new, why in UPDATES]

    # --- 2. близнецы (keywords.add) — ПОСЛЕ закавычивания основных,
    #        иначе «цветы в раменском» отклоняется как дубль «цветы раменское»
    items = [{'Keyword': kw, 'AdGroupId': gid} for gid, grp, kw in ADDS]
    created = []
    try:
        r = client.call('keywords', 'add', {'Keywords': items})
        for x in r.get('AddResults', []):
            if x.get('Id'):
                created.append(x['Id'])
                log(f'2) Создан ключ Id={x["Id"]}: {items[x.get("Index", len(created)-1)]["Keyword"]!r}')
            else:
                log('2) ОТКЛОНЁН:', json.dumps(x, ensure_ascii=False))
    except DirectError as e:
        log('2) keywords.add ошибка:', e)
    state['created_kw_ids'] = created

    # --- 3. минус-слова кампании
    negs_orig = fetch_negatives(client)
    lowered = {n.lower() for n in negs_orig}
    fresh = [w for w in NEG_ADD if w.lower() not in lowered]
    negs_new = negs_orig + fresh
    if fresh:
        client.call('campaigns', 'update', {
            'Campaigns': [{'Id': CAMPAIGN_ID,
                           'NegativeKeywords': {'Items': negs_new}}]})
        log(f'3) Минус-слова: {len(negs_orig)} -> {len(negs_new)} (добавлено {len(fresh)}): {", ".join(fresh)}')
    else:
        log('3) Минус-слова: все уже присутствуют, изменений нет.')
    state['negs_orig'] = negs_orig
    state['negs_added'] = fresh

    state['finished'] = datetime.datetime.now().isoformat(timespec='seconds')
    with open(STATE_PATH, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=1)
    log('Состояние сохранено:', STATE_PATH)

    # --- 4. пост-верификация
    live2 = fetch_keywords(client, [u[0] for u in UPDATES] + created)
    log('\n=== Пост-верификация ключей ===')
    for kid, grp, old, new, why in UPDATES:
        k = live2.get(kid, {})
        mark = 'OK' if k.get('Keyword') == new else '!!'
        log(f'  {mark} [{grp}] Id={kid}: {k.get("Keyword")!r} State={k.get("State")} Status={k.get("Status")}')
    for kid in created:
        k = live2.get(kid, {})
        log(f'  +  Id={kid}: {k.get("Keyword")!r} State={k.get("State")} Status={k.get("Status")}')
    negs_check = fetch_negatives(client)
    log(f'Минус-слов на кампании: {len(negs_check)} (ожидалось {len(negs_new)})')


def do_rollback(client):
    if not os.path.exists(STATE_PATH):
        log('Нет файла состояния — откатывать нечего.'); return
    state = json.load(open(STATE_PATH, encoding='utf-8'))

    if state.get('updates'):
        upd = [{'Id': u['id'], 'Keyword': u['old']} for u in state['updates']]
        client.call('keywords', 'update', {'Keywords': upd})
        log(f'Откачено текстов ключей: {len(upd)}')
    if state.get('created_kw_ids'):
        client.call('keywords', 'delete',
                    {'SelectionCriteria': {'Ids': state['created_kw_ids']}})
        log(f'Удалено созданных ключей: {len(state["created_kw_ids"])}')
    if state.get('negs_orig') is not None and state.get('negs_added'):
        client.call('campaigns', 'update', {
            'Campaigns': [{'Id': CAMPAIGN_ID,
                           'NegativeKeywords': {'Items': state['negs_orig']}}]})
        log(f'Минус-слова восстановлены: {len(state["negs_orig"])}')
    log('Откат завершён', datetime.datetime.now().isoformat(timespec='seconds'))


def do_dry(client):
    live = fetch_keywords(client, [u[0] for u in UPDATES])
    log('=== DRY-RUN: план применения операторов ===\n')
    log('A) Закавычить (keywords.update), 9 ключей:')
    for kid, grp, old, new, why in UPDATES:
        cur = (live.get(kid) or {}).get('Keyword')
        flag = '' if cur == old else f'  !! ТЕКУЩИЙ ТЕКСТ ОТЛИЧАЕТСЯ: {cur!r}'
        log(f'  [{grp}] Id={kid}: {old!r} -> {new!r}   ({why}){flag}')
    log('\nB) Добавить близнецов (keywords.add), 2 ключа:')
    for gid, grp, kw in ADDS:
        log(f'  [{grp}] группа {gid}: {kw}')
    log('\nC) Минус-слова кампании, +%d:' % len(NEG_ADD))
    negs = fetch_negatives(client)
    lowered = {n.lower() for n in negs}
    fresh = [w for w in NEG_ADD if w.lower() not in lowered]
    log(f'  сейчас {len(negs)}; будут добавлены: {", ".join(fresh)}; уже есть: '
        f'{", ".join(w for w in NEG_ADD if w.lower() in lowered) or "—"}')
    log('\nНичего не изменено. Для применения: python3 apply_operators.py --apply')


def main():
    cfg = load_config()
    client = DirectClient(cfg)
    if '--rollback' in sys.argv:
        do_rollback(client)
    elif '--apply' in sys.argv:
        do_apply(client)
    else:
        do_dry(client)


if __name__ == '__main__':
    main()
