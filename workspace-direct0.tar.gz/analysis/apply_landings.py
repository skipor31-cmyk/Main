#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Точечные посадочные М2/М3 + переименование старых групп (кампания 40732207).

Логика:
  A. Создать 14 подгрупп (7 из М2 «По видам цветов», 7 из М3 «По поводам») —
     каждая со своим объявлением на ТОЧЕЧНУЮ посадочную flowerpoetry.ru.
  B. После ACCEPTED модерации:перенесённых ключей и старых объявлений в М2/М3,
     обновить остаточные объявления М2/М3, переименовать 11 старых групп + М2/М3.

Режимы:
    python3 apply_landings.py            # DRY-RUN
    python3 apply_landings.py --apply    # применить
    python3 apply_landings.py --rollback # откатить
"""
import json, os, sys, time, datetime, csv

ROOT = os.path.dirname(os.path.abspath(__file__))          # .../analysis
WS   = os.path.dirname(ROOT)
SCRIPTS = os.path.join(WS, 'skills_repo', 'extracted1',
                       'skill_for_claude_code_yandex_direct-main', 'scripts')
sys.path.insert(0, SCRIPTS)
os.chdir(SCRIPTS)  # чтобы load_config нашёл config.json

from direct_api import DirectClient, load_config, collect_add_results, DirectError

CAMPAIGN_ID = 40732207
STATE_PATH  = os.path.join(ROOT, 'apply_state_landings.json')
M2, M3 = 5806224427, 5806224428
AD_M2, AD_M3 = 1922742232187391648, 1922742232187391649

CITY, ZHUK = 10750, 20571
VILLAGES = [10718, 117802, 118482, 119749, 105573, 120351, 133110,
            161506, 161512, 161520, 161524, 161526, 161536, 161541, 161548]
ZONE17 = [CITY, ZHUK] + VILLAGES

SITELINKS = 1384724168
BUSINESS  = 103128457869
TRACKPHONE= 6247510023894529225
CALLOUTS  = [36689089, 36689093, 36689312, 36689333, 36689334, 36689336,
             36689428, 36689429, 36689431, 7103330, 7103334, 9309894]

UTM  = '?utm_source=yandex&utm_medium=cpc&utm_campaign={campaign_id}&utm_content={ad_id}&utm_term={keyword}'
def URL(path): return 'https://flowerpoetry.ru' + path + UTM
KAT  = URL('/katalog/')

AT_CATEGORIES = [{"Category":"EXACT","Value":"YES"},{"Category":"ALTERNATIVE","Value":"NO"},
                 {"Category":"COMPETITOR","Value":"NO"},{"Category":"BROADER","Value":"NO"},
                 {"Category":"ACCESSORY","Value":"NO"}]
AT_BRANDS = [{"Option":"WITHOUT_BRANDS","Value":"YES"},{"Option":"WITH_ADVERTISER_BRAND","Value":"YES"}]

# ------------------------------------------------------------------ подгруппы
# (имя, посадочная, ключи, T1, T2, TEXT, DisplayUrlPath)
SUBGROUPS = [
 ("М2.1 Розы", '/po_cvetam/bukety-s-rozami/',
  ["букет роз","купить букет роз","букет роз раменское","букет роз цена","51 роза",
   "большой букет роз","красивый букет роз","цветы розы цена","букет красных роз раменское",
   "букет желтых роз раменское","букет розовых роз раменское","51 роза раменское",
   "цветы 101 роза раменское","букет из 25 роз раменское","букет из кустовых роз раменское",
   "букет из роз в форме сердца","букет розовых роз","шикарный букет белых роз","букет 151 роза",
   "букет темных роз","доставка цветов 51 роза","доставка роз раменское"],
  "Букеты роз в Раменском — доставка за 2 часа",
  "От 2000 руб. Открытка в дар",
  "Розы всех оттенков в наличии. Соберём букет по вашему бюджету. Доставка 2 часа!",
  "Букеты-роз"),

 ("М2.2 Тюльпаны", '/po_cvetam/bukety-s-tyulpanami/',
  ["купить букет тюльпанов","заказать букет тюльпанов","большой букет тюльпанов",
   "букет белых тюльпанов","букет красных тюльпанов"],
  "Букеты тюльпанов в Раменском",
  "Свежие тюльпаны. Доставка 2 ч",
  "Букеты тюльпанов от 2000 руб. Бережная доставка за 2 часа. Открытка в подарок!",
  "Букеты-тюльпанов"),

 ("М2.3 Хризантемы", '/po_cvetam/bukety-s-hrizantemoj/',
  ["букет из хризантем","купить букет хризантем","цветы хризантемы купить",
   "букет цветов из хризантем","букет из белых хризантем","букет из кустовых хризантем",
   "букет из одноголовых хризантем","букет хризантем цена"],
  "Букеты хризантем в Раменском",
  "Одноголовые и кустовые. Свежие",
  "Свежие хризантемы в наличии. Сборка букета за 2 часа. Открытка в подарок!",
  "Букеты-хризантем"),

 ("М2.4 Пионы и гортензии", '/po_cvetam/bukety-s-pionami/',
  ["букет пионов","купить пионы раменское","букеты цветов гортензия"],
  "Букеты пионов и гортензий в Раменском",
  "Свежие цветы. Доставка 2 часа",
  "Пионы и гортензии в наличии и под заказ. Букет от 2000 руб. Открытка в подарок!",
  "Пионы-гортензии"),

 ("М2.5 Гипсофила и эустома", '/po_cvetam/bukety-s-ehustomoj/',
  ["купить букет эустомы","купить цветы эустома","купить букет гипсофилы раменское",
   "букет облако из гипсофилы","гипсофила радужная букет"],
  "Букеты из эустомы и гипсофилы",
  "Нежные букеты. Доставка 2 часа",
  "Эустома и гипсофила — нежные букеты от 2000 руб. Доставка за 2 часа!",
  "Эустома-гипсофила"),

 ("М2.6 Гвоздики", '/po_cvetam/bukety-s-gvozdikoj/',
  ["гвоздика цветы купить","букет белых гвоздик раменское"],
  "Букеты гвоздик в Раменском",
  "Свежие гвоздики. От 2000 руб.",
  "Гвоздики всех оттенков в наличии. Доставка за 2 часа. Открытка в подарок!",
  "Букеты-гвоздик"),

 ("М3.1 День рождения", '/povod/den-rozhdeniya/',
  ["доставка цветов на день рождения","букет на день рождения","цветы на день рождения купить",
   "букет девочке на день рождения","шикарные букет с днем","шикарный букет цветов с днем"],
  "Букеты на день рождения в Раменском",
  "Доставка за 2 часа. Открытка",
  "Букет имениннику от 2000 руб. Привезём за 2 часа, открытка в подарок!",
  "На-день-рождения"),

 ("М3.2 Рождение ребёнка", '/povod/rozhdenie_rebenka/',
  ["букет для новорожденного","цветы на выписку из роддома"],
  "Цветы на выписку и новорождённому",
  "Нежные букеты. Доставка 2 часа",
  "Букеты на рождение ребёнка и выписку из роддома. От 2000 руб. Доставим за 2 часа!",
  "Рождение-ребенка"),

 ("М3.3 Свадебные букеты", '/povod/svadba/',
  ["свадебные букеты раменское","букет невесты раменское","свадебный букет купить",
   "букет невесты купить","букет невесты раменское купить"],
  "Букет невесты в Раменском",
  "Авторская сборка к вашему дню",
  "Свадебные букеты от 2000 руб. Соберём по фото или индивидуально!",
  "Букет-невесты"),

 ("М3.4 Маме", '/komu/mame/',
  ["цветы маме в подарок"],
  "Цветы маме в подарок — Раменское",
  "Доставка 2 часа. От 2000 руб.",
  "Букет для мамы из свежих цветов. Привезём за 2 часа. Открытка в подарок!",
  "Цветы-маме"),

 ("М3.5 Подруге и сестре", '/komu/podruge/',
  ["букет подруге","цветы для подруги","цветы сестре в подарок"],
  "Букет подруге или сестре",
  "Стильные букеты от 2000 руб.",
  "Стильный букет подруге или сестре. Доставка за 2 часа. Открытка в подарок!",
  "Букет-подруге"),

 ("М3.6 Любимой", '/komu/lubimoy/',
  ["букет для любимой","доставка цветов любимой"],
  "Букет для любимой в Раменском",
  "Доставка за 2 часа. Открытка",
  "Романтичные букеты для любимой от 2000 руб. Привезём за 2 часа!",
  "Букет-любимой"),

 ("М3.7 Девушке", '/komu/devushke/',
  ["букет цветов для девочки"],
  "Букет девушке в Раменском",
  "От 2000 руб. Доставка 2 часа",
  "Красивый букет девушке из свежих цветов. Доставка за 2 часа. Открытка в подарок!",
  "Букет-девушке"),
]

# остаточные объявления М2/М3 (после переноса ключей)
RESIDUAL_ADS = {
 AD_M2: ("Букеты лилий, орхидей, альстромерий", URL('/katalog/'),
         "Экзотические и редкие цветы в наличии. Доставка 2 часа. От 2000 руб."),
 AD_M3: ("Оригинальные букеты в Раменском", KAT,
         "Авторские букеты на любой повод. Соберём по вашему бюджету. Открытка в подарок!"),
}
RESIDUAL_PREV = {   # текущие значения — для отката
 AD_M2: {"Title": "Букеты из свежих цветов в Раменском", "Href": KAT,
         "Text": "Розы, пионы, хризантемы, гортензии в наличии. Доставка 2 часа. От 2000 руб."},
 AD_M3: {"Title": "Оригинальные букеты в Раменском", "Href": KAT,
         "Text": "Букеты на любой повод: день рождения, свадьба, просто так. Соберём по бюджету!"},
}

# переименование: 11 старых групп + М2/М3
RENAMES = {
 3688099772: "К1. Заказ +с доставкой",
 4166852642: "Д1. Доставка — город",
 4166852644: "К1.2 Заказать +с доставкой",
 4166852655: "Д2. На дом +с доставкой",
 4166852705: "Д2.2 На дом",
 4166852706: "Д4. Область",
 4166852729: "Д2.3 Курьером",
 4166852738: "К1.3 Купить-заказать (188 фраз)",
 4166852753: "Д4.2 В область",
 4166852847: "Д1.2 Доставка — город",
 4166852849: "Д1.3 Доставка — город и район",
 M2: "М2. По видам — остаток",
 M3: "М3. По поводам — остаток",
}

def ad_payload(t1, t2, tx, href, disp):
    return {"TextAd": {"Title": t1, "Title2": t2, "Text": tx, "Href": href,
                       "Mobile": "NO",
                       "SitelinkSetId": SITELINKS, "AdExtensionIds": CALLOUTS,
                       "BusinessId": BUSINESS, "TrackingPhoneId": TRACKPHONE,
                       "DisplayUrlPath": disp}}

def validate():
    errs = []
    for g in SUBGROUPS:
        name, path, keys, t1, t2, tx, disp = g
        if len(t1) > 56: errs.append(f"[{name}] T1 {len(t1)}: {t1}")
        if len(t2) > 30: errs.append(f"[{name}] T2 {len(t2)}: {t2}")
        if len(tx) > 81: errs.append(f"[{name}] TX {len(tx)}: {tx}")
        if len(disp) > 20: errs.append(f"[{name}] DISP {len(disp)}: {disp}")
        for s in (t1, t2, tx):
            if s.count('!') > 1: errs.append(f"[{name}] >1 '!': {s}")
        if len(set(keys)) != len(keys): errs.append(f"[{name}] дубли ключей")
    for aid, (t1, href, tx) in RESIDUAL_ADS.items():
        if len(t1) > 56: errs.append(f"[resid {aid}] T1 {len(t1)}")
        if len(tx) > 81: errs.append(f"[resid {aid}] TX {len(tx)}")
    allkeys = [k for g in SUBGROUPS for k in g[2]]
    if len(set(allkeys)) != len(allkeys): errs.append("дубли ключей между подгруппами")
    return errs

def fetch_current_keys(client):
    r = client.call('keywords', 'get', {
        'SelectionCriteria': {'AdGroupIds': [M2, M3]},
        'FieldNames': ['Id', 'Keyword', 'AdGroupId', 'Status']})
    by_text = {}
    for k in r.get('Keywords', []):
        by_text[k['Keyword'].strip().lower()] = k
    return by_text

def build_plan(client):
    by_text = fetch_current_keys(client)
    moved, move_rows, problems = [], [], []
    for name, path, keys, *_ in SUBGROUPS:
        for kw in keys:
            rec = by_text.get(kw.strip().lower())
            if not rec:
                problems.append(f"[{name}] ключ не найден в М2/М3: {kw}")
                continue
            moved.append(rec['Id'])
            move_rows.append({'old_id': rec['Id'], 'old_group': rec['AdGroupId'],
                              'keyword': rec['Keyword'], 'new_group': name, 'landing': path})
    # остаток = все живые ключи М2/М3, не вошедшие в перенос (включая ---autotargeting)
    residual = [k for t, k in by_text.items() if k['Id'] not in set(moved)]
    return moved, move_rows, residual, problems

def main():
    mode = 'dry'
    if '--apply' in sys.argv: mode = 'apply'
    if '--rollback' in sys.argv: mode = 'rollback'

    errs = validate()
    if errs:
        print("ОШИБКА лимитов/дублей:"); [print("  ", e) for e in errs]; sys.exit(1)

    cfg = load_config(); client = DirectClient(cfg)
    moved, move_rows, residual, problems = build_plan(client)

    if problems:
        print("ПРОБЛЕМЫ сопоставления ключей:"); [print("  ", p) for p in problems]
        if mode == 'apply': sys.exit(1)

    n_keys = len(move_rows)
    print("=" * 95)
    print(f"ПЛАН: точечные посадочные М2/М3 + переименование групп (кампания {CAMPAIGN_ID})")
    print("=" * 95)
    print(f"\n[A1] Создать {len(SUBGROUPS)} подгрупп (гео: 17 регионов зоны доставки)")
    print(f"[A2] {n_keys} ключей перенести в подгруппы (копированием; старые → пауза на шаге B1)")
    print(f"[A3] {len(SUBGROUPS)} автотаргетинг-ключей (конкуренты ВЫКЛ)")
    print(f"[A4] {len(SUBGROUPS)} объявлений + модерация; ждать ACCEPTED")
    print(f"[B1] Пауза {n_keys} старых ключей в М2/М3")
    print(f"[B2] Пауза 2 старых объявлений М2/М3")
    print(f"[B3] Обновить остаточные объявления М2/М3 (Title/Text/Href)")
    print(f"[C1] Переименовать {len(RENAMES)} групп")
    print(f"\nОстаток в М2/М3 после переноса: {len(residual)} ключей (вкл. автотаргетинг)")
    print("\nПодгруппы:")
    for name, path, keys, t1, t2, tx, disp in SUBGROUPS:
        print(f"  • {name:26} {len(keys):>2} кл. → flowerpoetry.ru{path}")
        print(f"      T1 «{t1}» ({len(t1)})")
    print("\nПереименования:")
    for gid, nm in RENAMES.items():
        print(f"  • {gid} → {nm}")
    if mode == 'dry':
        print("\nЗапуск: python3 apply_landings.py --apply   |   Откат: --rollback")
        return

    # ------------------------------------------------------------ APPLY
    if os.path.exists(STATE_PATH):
        state = json.load(open(STATE_PATH))
        done = {e['id'] for e in state.get('applied', [])}
    else:
        done = set()
        state = {'started': datetime.datetime.now().isoformat(), 'applied': []}
    def save():
        with open(STATE_PATH, 'w') as f: json.dump(state, f, ensure_ascii=False, indent=1)
    def step(sid, desc, svc, method, params, rollback=None, best_effort=False, **extra):
        if sid in done:
            print(f"\n[{sid}] ПРОПУЩЕН (уже применён)"); 
            return state
        print(f"\n[{sid}] {desc}")
        try:
            res = client.call(svc, method, params)
        except DirectError as e:
            if best_effort:
                print(f"  best-effort пропущен: {str(e)[:200]}"); return res
            print(f"  ОШИБКА: {e}\nСТОП. Состояние сохранено — можно --rollback."); save(); sys.exit(2)
        entry = {'id': sid, 'desc': desc, 'rollback': rollback,
                 'ts': datetime.datetime.now().isoformat()}
        entry.update(extra)
        if method == 'add':
            ids, errors, warnings = collect_add_results(res, 'add')
            created = [x for x in ids if x is not None]
            entry['created_ids'] = created
            print(f"  создано: {len(created)}" + (f" | ОШИБКИ: {errors[:5]}" if errors else "") +
                  (f" | warn: {len(warnings)}" if warnings else ""))
            state.setdefault('created', {})[sid] = created
        else:
            upd = res.get('UpdateResults') or []
            n_err = sum(len(r.get('Errors') or []) for r in upd) if upd else 0
            print(f"  ok" + (f" | ошибок: {n_err}" if n_err else ""))
        state['applied'].append(entry); save()
        return res

    if mode == 'rollback':
        print("ОТКАТ...")
        for entry in reversed(state.get('applied', [])):
            rb = entry.get('rollback')
            if not rb:
                print(f"  [{entry['id']}] нет авто-отката — приостанавливаем созданное")
                ids = entry.get('created_ids') or []
                svc = 'ads' if entry['id'].startswith('A4') else 'keywords'
                if ids:
                    try: client.call(svc, 'suspend', {'SelectionCriteria': {'Ids': ids}})
                    except DirectError as e: print(f"    ERR: {e}")
                continue
            try:
                client.call(rb['svc'], rb['method'], rb['params'])
                print(f"  [{entry['id']}] откачено")
            except DirectError as e:
                print(f"  [{entry['id']}] ОШИБКА отката: {e}")
        print("Откат завершён.")
        return

    # A1 — группы
    res = step('A1_groups', f"Создать {len(SUBGROUPS)} подгрупп", 'adgroups', 'add',
               {'AdGroups': [{'CampaignId': CAMPAIGN_ID, 'Name': g[0], 'RegionIds': ZONE17}
                             for g in SUBGROUPS]},
               creates_groups=[g[0] for g in SUBGROUPS])
    gids = state.get('created', {}).get('A1_groups') or []
    if 'A1_groups' in done:
        e = next(x for x in state['applied'] if x['id'] == 'A1_groups')
        gids = e.get('created_ids') or gids
    gid_by_name = {}
    for nm, gid in zip([g[0] for g in SUBGROUPS], gids):
        if gid: gid_by_name[nm] = gid
    state['gid_by_name'] = gid_by_name; save()
    if len(gid_by_name) != len(SUBGROUPS):
        print("НЕ ВСЕ группы созданы:", gid_by_name); save(); sys.exit(2)
    print("  ID групп:", json.dumps(gid_by_name, ensure_ascii=False))

    # A2 — ключи
    kw_items = []
    for name, path, keys, *_ in SUBGROUPS:
        gid = gid_by_name[name]
        for kw in keys:
            kw_items.append({'Keyword': kw, 'AdGroupId': gid})
    step('A2_keys', f"{len(kw_items)} ключей в подгруппы", 'keywords', 'add',
         {'Keywords': kw_items},
         rollback={'svc': 'keywords', 'method': 'suspend',
                   'params': {'SelectionCriteria': {'Ids': [i for i in
                       (state.get('created', {}).get('A2_keys') or [])]}}})

    # A3 — автотаргетинг
    at_items = [{'Keyword': '---autotargeting', 'AdGroupId': gid_by_name[g[0]],
                 'AutotargetingCategories': AT_CATEGORIES,
                 'AutotargetingBrandOptions': AT_BRANDS} for g in SUBGROUPS]
    step('A3_autotarget', f"{len(at_items)} автотаргетинг-ключей", 'keywords', 'add',
         {'Keywords': at_items}, best_effort=True)

    # A4 — объявления + модерация
    ad_items = []
    for name, path, keys, t1, t2, tx, disp in SUBGROUPS:
        p = ad_payload(t1, t2, tx, URL(path), disp)
        p['AdGroupId'] = gid_by_name[name]
        ad_items.append(p)
    step('A4_ads', f"{len(ad_items)} объявлений в подгруппы", 'ads', 'add', {'Ads': ad_items})
    new_ad_ids = state.get('created', {}).get('A4_ads') or []

    if 'A5_moderate' not in done and new_ad_ids:
        print(f"\n[A5_moderate] Отправка {len(new_ad_ids)} объявлений в модерацию")
        try:
            client.call('ads', 'moderate', {'SelectionCriteria': {'Ids': new_ad_ids}})
        except DirectError as e:
            print("  ERR moderate:", str(e)[:200])
        state['applied'].append({'id': 'A5_moderate', 'ts': datetime.datetime.now().isoformat(),
                                 'rollback': None}); save()

    # ждать ACCEPTED (до ~7 мин)
    accepted = []
    if new_ad_ids:
        for attempt in range(14):
            r = client.call('ads', 'get', {'SelectionCriteria': {'Ids': new_ad_ids},
                                           'FieldNames': ['Id', 'Status']})
            st = {a['Id']: a.get('Status') for a in r.get('Ads', [])}
            accepted = [i for i, s in st.items() if s == 'ACCEPTED']
            rejected = [i for i, s in st.items() if s == 'REJECTED']
            print(f"  модерация: ACCEPTED {len(accepted)}/{len(new_ad_ids)}"
                  + (f", REJECTED {len(rejected)}" if rejected else ""))
            if len(accepted) + len(rejected) == len(new_ad_ids): break
            time.sleep(30)
    state['ads_accepted_before_switch'] = len(accepted); save()

    # B1/B2 — переключение ТОЛЬКО если все новые объявления прошли
    if len(accepted) == len(new_ad_ids) and new_ad_ids:
        step('B1_suspend_old_keys', f"Пауза {len(moved)} перенесённых ключей в М2/М3",
             'keywords', 'suspend', {'SelectionCriteria': {'Ids': moved}},
             rollback={'svc': 'keywords', 'method': 'resume',
                       'params': {'SelectionCriteria': {'Ids': moved}}})
        step('B2_suspend_old_ads', "Пауза старых объявлений М2/М3",
             'ads', 'suspend', {'SelectionCriteria': {'Ids': [AD_M2, AD_M3]}},
             rollback={'svc': 'ads', 'method': 'resume',
                       'params': {'SelectionCriteria': {'Ids': [AD_M2, AD_M3]}}})
        # B3 — остаточные объявления
        upd = [{'Id': aid, 'TextAd': {'Title': t1, 'Text': tx, 'Href': href}}
               for aid, (t1, href, tx) in RESIDUAL_ADS.items()]
        step('B3_residual_ads', "Обновить остаточные объявления М2/М3",
             'ads', 'update', {'Ads': upd},
             rollback={'svc': 'ads', 'method': 'update',
                       'params': {'Ads': [{'Id': aid, 'TextAd': dict(v)}
                                          for aid, v in RESIDUAL_PREV.items()]}})
        if 'B4_moderate_residual' not in done:
            print("\n[B4_moderate_residual] Модерация обновлённых объявлений")
            try: client.call('ads', 'moderate', {'SelectionCriteria': {'Ids': [AD_M2, AD_M3]}})
            except DirectError as e: print("  ERR:", str(e)[:200])
            state['applied'].append({'id': 'B4_moderate_residual', 'rollback': None,
                                     'ts': datetime.datetime.now().isoformat()}); save()
    else:
        print("\n⚠️ НЕ все новые объявления ACCEPTED — старые ключи/объявления НЕ трогаем "
              "(продолжают работать). Перезапустите --apply после модерации.")

    # C1 — переименования (не зависят от модерации)
    rb_renames = None
    try:
        r = client.call('adgroups', 'get', {'SelectionCriteria': {'Ids': list(RENAMES.keys())},
                                            'FieldNames': ['Id', 'Name']})
        rb_renames = {'svc': 'adgroups', 'method': 'update',
                      'params': {'AdGroups': [{'Id': g['Id'], 'Name': g['Name']}
                                              for g in r.get('AdGroups', [])]}}
    except DirectError as e:
        print("  не удалось снять старые имена для отката:", e)
    step('C1_renames', f"Переименовать {len(RENAMES)} групп", 'adgroups', 'update',
         {'AdGroups': [{'Id': gid, 'Name': nm} for gid, nm in RENAMES.items()]},
         rollback=rb_renames)

    # лог переноса
    with open(os.path.join(ROOT, 'перенос_ключей_М2_М3.csv'), 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['old_id', 'old_group', 'keyword', 'new_group', 'landing'],
                           delimiter=';')
        w.writeheader(); w.writerows(move_rows)

    state['finished'] = datetime.datetime.now().isoformat(); save()
    print("\n✅ ГОТОВО. Состояние/откат: analysis/apply_state_landings.json")

if __name__ == '__main__':
    main()
