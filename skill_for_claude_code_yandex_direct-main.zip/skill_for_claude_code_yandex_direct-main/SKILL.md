---
name: yandex-direct
description: Run and grow Yandex.Direct ad campaigns end-to-end via the Direct API v5 and Metrica. Create campaigns, ad groups, keywords and ads; generate ad copy (titles/texts/sitelinks); track leads; and optimize bids/budgets toward a target CPA/ROI. Use when the user asks to set up, manage, audit, scale, or optimize Yandex.Direct (Яндекс Директ) advertising, generate ad creatives/texts, lower CPA, find wasted spend, or report on campaign performance.
---

# Yandex.Direct — autonomous campaign management

Manage a user's Yandex.Direct account: build campaigns, write the copy, track
leads through Metrica, and optimize spend toward a target cost-per-lead (CPA)
and positive ROI.

## First: mandatory onboarding
Before any API action, the agent must collect and confirm two access blocks:
1. **Yandex.Direct access**:
   - OAuth token for Direct/Metrica
   - sandbox vs production mode
   - Metrica counter id + primary goal id
2. **Creative production access** for photos/banners:
   - provider type: `api` or `mcp`
   - provider/service name
   - auth token / API key / connector access details
   - base URL or MCP tool name if non-default
   - expected asset types: lifestyle photo, product visual, banner, RSYA image set

If any of these are missing, stop and ask the user for them first. Do not
invent credentials, do not silently skip the creative provider, and do not
start campaign creation before access is clarified.

For any agent using this skill, the opening intake should always ask:
- "Пришлите OAuth-токен Яндекс.Директа/Метрики, режим sandbox/prod, counter_id и goal_id."
- "Пришлите токен/ключ и API или MCP-сервис для генерации рекламных фото/баннеров."
- "Если MCP уже подключен, укажите каким инструментом генерировать креативы."

## Then: check setup
Before any Direct API action, ensure `scripts/config.json` exists and the token works:
```bash
cd scripts && python direct_api.py ping
```
- If config is missing or token is invalid → walk the user through
  `references/setup-guide.md` (OAuth token, Metrica counter+goal, fill config).
- `sandbox: true` (default) is safe — no real money. Only switch to `false`
  after confirming with the user.

**Money is real in production.** Confirm with the user before: switching
`sandbox` to `false`, raising budgets/bids in production, or applying bulk
changes (`optimize.py --apply`) on a live account.

## Scripts (run from `scripts/`, Python stdlib only)
| Script | Purpose |
|--------|---------|
| `direct_api.py` | Core client. `ping`, raw `call`. Batch-error parsing + cost guard |
| `build.py` | **Orchestrator**: whole campaign from one blueprint, idempotent, dry-run |
| `state.py` | Local id-map (no duplicate creates) + audit log (`changelog.jsonl`) |
| `campaigns.py` | create / list / suspend / resume / set-budget / strategy |
| `adgroups.py` | groups, keywords, minus-words |
| `ads.py` | validate + create text ads (char limits) + callouts |
| `extensions.py` | callouts (AdExtensions) |
| `keywords.py` | bids, **auction** bids, mine wasteful + winning queries |
| `research.py` | expand seeds → phrases, `hasSearchVolume` demand filter |
| `adjustments.py` | bid modifiers: mobile, demographics, dayparting |
| `negatives.py` | shared negative-keyword sets across campaigns |
| `image_ads.py` | РСЯ image ads: upload image, create image ad |
| `generate_creatives.py` | generate image/banner assets via external API or MCP manifest |
| `creative_provider.py` | provider bridge for creative generation (`api` / `mcp`) |
| `creative_to_image_manifest.py` | convert generated/uploaded creatives into bulk image-ad manifest |
| `reports.py` | performance stats (campaigns/adgroups/keywords/ads) |
| `metrica.py` | leads/conversions by goal |
| `crm_upload.py` | **offline conversions** (CRM sales → real ROI signal) |
| `optimize.py` | rules engine: bid/budget/pause/minus (dry-run default) |
| `abtest.py` | A/B creatives, z-test winner, pause losers |
| `anomalies.py` | spend-spike / conversion-drop / CPA-blowout alerts |
| `autopilot.py` | weekly loop: mine → optimize → anomalies → report |
| `rollback.py` | undo session creates (suspend) via audit log |

All scripts have `--help` and print JSON/TSV you can read back.
Write actions are **dry-run by default**; `--apply` enacts. State + audit make
re-runs safe (no duplicates) and reversible (`rollback.py`).

## Workflows

### A. Launch a new campaign (fast path: blueprint)
1. Fill the brief (`assets/creative_brief_template.md`): product, USP, geo,
   landing, budget, target CPA, intents, plus creative-provider access.
2. Research keywords: `research.py expand --seed ... --mod ...` →
   `research.py demand --region <id> --only-live` to drop dead phrases.
3. Write a blueprint JSON (see `assets/campaign_blueprint.example.json`):
   campaign + ad groups + keywords + minus-words + ads.
4. `build.py --blueprint campaign.json` (dry-run) → review → `--apply`.
   build.py is idempotent (state.json) and validates ad copy before upload.
5. `ads.py moderate --group <id>` to submit. Add bid adjustments
   (`adjustments.py`) and a shared negatives set (`negatives.py`) as needed.
6. Always put UTM tags on every `href` so Metrica attributes leads.

(Manual path still works: `campaigns.py` → `adgroups.py` → `ads.py` step by step.)

### B. Generate ad copy (creatives/texts)
The model writes the copy; scripts only validate + upload.
1. Read `references/ad-copy-rules.md` (limits + the selling formula).
2. Produce 2–3 variants per ad group as the `ads.json` array.
3. Always `ads.py validate --file ads.json` before uploading — it's the hard gate.

### B2. Generate images, banners, and RSYA creatives
This skill must support paired work with a creative generator so text + visuals
are produced together.
1. Confirm which creative backend is available:
   - direct API integration to an external image/banner generation service, or
   - any MCP connector/tool the current agent can call for content production.
2. Ask the user for the backend token/key and endpoint/tool name if they were
   not already provided during onboarding.
3. Generate visuals that match the brief:
   - square and landscape banners for RSYA,
   - product/lifestyle images,
   - image variants for A/B tests,
   - headline/copy overlays only if the provider supports them cleanly.
4. Keep text/copy generation and visual generation synchronized:
   - same offer,
   - same audience,
   - same CTA,
   - same geo and landing URL.
5. If the current runtime has an MCP creative tool available, prefer using it.
   If not, collect the external API details and prepare assets for upload via
   `image_ads.py` or other upload flow.
6. If no creative provider is connected yet, do not pretend image generation is
   available. Ask for the provider credentials or MCP connection explicitly.
7. Concrete runtime:
   - `generate_creatives.py --brief brief.json` for generation,
   - `image_ads.py upload-dir --dir <folder>` for image upload,
   - `creative_to_image_manifest.py` + `image_ads.py create-bulk` for batch ad creation.

### C. Track leads
- `metrica.py goals` — list goals. `metrica.py conversions --days 14` — leads by
  Direct campaign. `metrica.py summary` — visits/leads/CR.
- Conversions also come through Direct reports when `Goals` are passed
  (`reports.py ... --goals <id>`).

### D. Optimize (lower CPA, cut waste, scale winners)
1. `reports.py campaigns --days 7` and `keywords --campaign <id>` for the picture.
2. `keywords.py mine-queries --campaign <id>` → pick junk → `adgroups.py minus`.
3. `optimize.py --campaign <id>` (dry-run) → review the plan with the user →
   `optimize.py --campaign <id> --apply`.
4. Rewrite weak ads (low CTR), scale profitable groups (more budget/bid).
Full logic + thresholds: `references/optimization-playbook.md`.

### E. Report
Pull `reports.py` + `metrica.py`, compute CTR/CR/CPA/ROI, compare to target_cpa
from config, and summarize: what spent, what converted, what changed, next steps.

### F. Real ROI from CRM (not just leads)
Optimizing on form-fills chases cheap junk. Feed back actual sales:
1. Export CRM sales as CSV: `Yclid,Target,DateTime,Price,Currency`.
2. `crm_upload.py --file sales.csv --key yclid` → Metrica gets real revenue.
3. Switch campaigns to `auto_roi`/`auto_cpa` strategy on the goal, or let the
   optimizer weigh revenue. This is what turns "leads" into "money in plus".

### G. A/B creatives
`abtest.py eval --group <id> --days 14` → z-test winner once volume is enough →
`--apply` pauses losers. Refresh copy of losers using `keywords.py mine-winners`.
When image/banner generation is available, refresh both copy and visuals as one
creative pack instead of changing text alone.

### H. Weekly autopilot (hands-off)
`autopilot.py --campaign <id>` runs the whole loop (mine waste/winners →
optimize → anomalies → report). Dry-run by default; `--apply` enacts. Pair with
`/schedule` for a recurring weekly cloud run. `anomalies.py` can run daily as a
cheap guard.

### Safety / recovery
- `state.py show` — what this skill created. `state.py log` — audit trail.
- `rollback.py undo --last 1 --apply` — suspend objects from the last build if
  something went wrong (suspend, not delete — reversible).
- Cost guard: in production, budget changes above `kpi.max_daily_total` are blocked.

## Reference files (read when relevant)
- `references/setup-guide.md` — token, Metrica, config (onboarding).
- `references/api-v5-reference.md` — services, fields, limits, error codes, money units.
- `references/ad-copy-rules.md` — char limits, moderation, copy formula.
- `references/optimization-playbook.md` — CPA/ROI math, rules, auto-strategies, weekly loop.

## Conventions
- Money to the API is in micros (×1 000 000); scripts handle it. Reports are in plain units.
- Each API call burns units (quota); batch and prefer reports over polling.
- Default to dry-run; never apply bulk changes to a production account without confirmation.
- This skill is agent-agnostic: any agent may use it, but it must preserve the same
  onboarding order and must request creative-provider access before promising
  banner/photo generation.
