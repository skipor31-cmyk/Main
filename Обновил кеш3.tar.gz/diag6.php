<?php
// diag6.php — положить в public_html, открыть https://flowerpoetry.ru/diag6.php,
// прислать вывод, затем УДАЛИТЬ с сервера!
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/plain; charset=utf-8');
set_time_limit(600);
$root = __DIR__;
$NEEDLE = 'unknown image format';

echo "=== DIAG6 " . date('Y-m-d H:i:s') . " ===\n";

// ---------- 0. Константы из обоих config.php ----------
echo "== 0. CONFIGS ==\n";
$configs = array();
foreach (array('config.php', 'admin/config.php') as $c) {
	echo "-- $c --\n";
	if (!is_file($root . '/' . $c)) { echo "  (absent)\n"; continue; }
	foreach (file($root . '/' . $c) as $line) {
		if (preg_match("/define\(\s*'(DIR_STORAGE|DIR_MODIFICATION|DIR_IMAGE|DIR_CACHE|HTTP_SERVER|HTTPS_SERVER)'\s*,\s*([^)]+)\)/", $line, $m)) {
			echo '  ' . trim($line) . "\n";
			$configs[$c][$m[1]] = trim($m[2], " \t'\";");
		}
	}
}
echo "\n";

// ---------- 1. Прямой тест класса Image из MOD-копии ----------
echo "== 1. DIRECT Image CLASS TEST ==\n";
$cands = array();
if (isset($configs['admin/config.php']['DIR_MODIFICATION'])) $cands[] = rtrim($configs['admin/config.php']['DIR_MODIFICATION'], '/') . '/system/library/image.php';
if (isset($configs['config.php']['DIR_MODIFICATION'])) $cands[] = rtrim($configs['config.php']['DIR_MODIFICATION'], '/') . '/system/library/image.php';
$cands[] = $root . '/storage/modification/system/library/image.php';
$cands[] = $root . '/system/library/image.php';
$used = '';
foreach ($cands as $p) { if (is_file($p)) { $used = $p; break; } }
echo "  loading: $used\n";
$bad = $root . '/image/catalog/1papka/katalog/Лого-и-фирменное-написане-_1_-_1_-_1_.webp';
require_once($used);
$img = new Image($bad);
echo "  new Image(webp) => width=" . var_export($img->getWidth(), true) . " height=" . var_export($img->getHeight(), true) . " mime=" . var_export($img->getMime(), true) . "  (если дошли до этой строки — exit'а НЕТ)\n";
$img->resize(100, 20);
$tmp = tempnam(sys_get_temp_dir(), 'w') . '.webp';
$img->save($tmp);
echo "  resize+save webp: " . (is_file($tmp) && filesize($tmp) > 0 ? 'OK ' . filesize($tmp) . 'B' : 'FAIL') . "\n\n";

// ---------- 2. Полнодисковый поиск строки ----------
echo "== 2. DISK SEARCH: '$NEEDLE' ==\n";
$hits = 0;
$binExt = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'ico', 'svg', 'woff', 'woff2', 'ttf', 'eot', 'zip', 'gz', 'tar', 'rar', 'pdf', 'mp4', 'mp3');
function scan($dir, $root, $binExt, &$hits, $allExt = false) {
	global $NEEDLE;
	$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
	foreach ($it as $f) {
		if (!$f->isFile()) continue;
		$p = $f->getPathname();
		if ($f->getSize() > 3000000) continue;
		$ext = strtolower($f->getExtension());
		if (!$allExt && !in_array($ext, array('php', 'twig', 'tpl', 'html', 'htm', 'txt', 'log', 'xml', 'json', 'js', 'css', 'cache', ''))) continue;
		if (in_array($ext, $binExt)) continue;
		$c = @file_get_contents($p);
		if ($c && stripos($c, $NEEDLE) !== false) {
			$hits++;
			echo "  HIT: $p [" . $f->getSize() . "B, mtime " . date('Y-m-d H:i:s', $f->getMTime()) . "]\n";
			if ($hits >= 25) { echo "  (stopped at 25 hits)\n"; return true; }
		}
	}
	return false;
}
scan($root, $root, $binExt, $hits);
$storage = isset($configs['config.php']['DIR_STORAGE']) ? rtrim($configs['config.php']['DIR_STORAGE'], '/') : dirname($root) . '/storage';
if (is_dir($storage)) scan($storage, $root, $binExt, $hits, true); // в storage смотрим ВСЕ файлы (кеш!)
echo "  total hits: $hits\n\n";

// ---------- 3. Поиск в БД (oc_setting, oc_modification, oc_layout, oc_translation) ----------
echo "== 3. DB SEARCH ==\n";
$cfg = @parse_ini_string(preg_replace(array('/^<\?php/', '/define\(/m', '/\);/m'), array('', '', '='), file_get_contents($root . '/config.php'));
function cfgval($src, $name) {
	if (preg_match("/define\(\s*'" . $name . "'\s*,\s*'([^']*)'/", $src, $m)) return $m[1];
	return '';
}
$cs = file_get_contents($root . '/config.php');
$host = cfgval($cs, 'DB_HOSTNAME'); $user = cfgval($cs, 'DB_USERNAME'); $pass = cfgval($cs, 'DB_PASSWORD'); $db = cfgval($cs, 'DB_DATABASE'); $pref = cfgval($cs, 'DB_PREFIX');
$port = cfgval($cs, 'DB_PORT') ?: 3306;
echo "  db: $user@$host:$port/$db prefix=$pref\n";
$mi = @new mysqli($host, $user, $pass, $db, $port);
if ($mi && !$mi->connect_error) {
	$mi->set_charset('utf8mb4');
	foreach (array('setting', 'modification', 'layout_route', 'translation', 'category_description', 'product_description', 'information_description') as $t) {
		$table = $pref . $t;
		$cols = array();
		$r = $mi->query("SHOW COLUMNS FROM `$table`");
		if (!$r) continue;
		while ($row = $r->fetch_assoc()) if (in_array($row['Type'], array('text', 'mediumtext', 'longtext')) || strpos($row['Type'], 'varchar') === 0) $cols[] = $row['Field'];
		foreach ($cols as $col) {
			$r = $mi->query("SELECT COUNT(*) c FROM `$table` WHERE `$col` LIKE '%" . $mi->real_escape_string($NEEDLE) . "%'");
			if ($r && ($row = $r->fetch_assoc()) && $row['c'] > 0) {
				echo "  HIT: table $table column $col rows=" . $row['c'] . "\n";
				$r2 = $mi->query("SELECT * FROM `$table` WHERE `$col` LIKE '%" . $mi->real_escape_string($NEEDLE) . "%' LIMIT 3");
				while ($row2 = $r2->fetch_assoc()) {
					foreach ($row2 as $k => $v) if (stripos((string)$v, $NEEDLE) !== false) echo "    $k => " . substr(str_replace("\n", ' ', $v), 0, 300) . "\n";
				}
			}
		}
	}
	echo "  db search done\n";
} else {
	echo "  db connect failed\n";
}
echo "\n";

// ---------- 4. HTTP-кеш: запросы С САМОГО СЕРВЕРА (мимо CDN/браузера) ----------
echo "== 4. SELF-REQUESTS (bypass browser/CDN) ==\n";
$urls = array(
	'home' => 'https://flowerpoetry.ru/',
	'admin' => 'https://flowerpoetry.ru/admin/',
	'logo_webp' => 'https://flowerpoetry.ru/image/catalog/1papka/katalog/' . rawurlencode('Лого-и-фирменное-написане-_1_-_1_-_1_') . '.webp',
);
foreach ($urls as $name => $u) {
	$ch = curl_init($u);
	curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_HEADER => 1, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_TIMEOUT => 30, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_USERAGENT => 'diag6'));
	$resp = curl_exec($ch);
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
	curl_close($ch);
	$hdr = substr($resp, 0, $hsize);
	$body = substr($resp, $hsize);
	echo "-- $name $u => HTTP $code, body " . strlen($body) . "B\n";
	foreach (explode("\n", $hdr) as $h) {
		if (preg_match('/^(server|age|x-cache|x-cache-status|cf-ray|cf-cache-status|via|x-powered|expires|last-modified|content-type):/i', trim($h))) echo '   ' . trim($h) . "\n";
	}
	echo '   contains "' . $NEEDLE . '": ' . (stripos($body, $NEEDLE) !== false ? 'YES !!!' : 'no') . "\n";
}
echo "\n";

// ---------- 5. OPcache: что реально в памяти ----------
echo "== 5. OPCACHE ==\n";
if (function_exists('opcache_get_status')) {
	$st = opcache_get_status(true);
	if ($st) {
		echo "  enabled: " . var_export($st['opcache_enabled'], true) . " | restarts: " . (isset($st['opcache_statistics_hook']) ? '?' : (isset($st['restarts']) ? json_encode($st['restarts']) : '?')) . "\n";
		$ini = array('opcache.validate_timestamps' => ini_get('opcache.validate_timestamps'), 'opcache.revalidate_freq' => ini_get('opcache.revalidate_freq'));
		echo "  " . json_encode($ini) . "\n";
		if (!empty($st['scripts'])) {
			foreach ($st['scripts'] as $path => $s) {
				if (stripos($path, 'image.php') !== false) {
					echo "  cached: $path | last_used_timestamp=" . date('Y-m-d H:i:s', $s['last_used_timestamp']) . " | timestamp=" . date('Y-m-d H:i:s', $s['timestamp']) . "\n";
				}
			}
		}
	} else echo "  status unavailable\n";
} else echo "  opcache extension absent\n";
echo "=== END DIAG6 ===\n";
