<?php
// diag5.php — загрузить в public_html, открыть https://flowerpoetry.ru/diag5.php,
// прислать вывод. ПОСЛЕ ИСПОЛЬЗОВАНИЯ УДАЛИТЬ С СЕРВЕРА!
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/plain; charset=utf-8');

$root = __DIR__; // public_html

// определяем DIR_STORAGE из config.php
$storage = '';
foreach (array($root . '/config.php', $root . '/admin/config.php') as $cfg) {
	if (is_file($cfg)) {
		foreach (file($cfg) as $line) {
			if (preg_match("/define\(\s*'DIR_STORAGE'\s*,\s*'([^']+)'/", $line, $m)) { $storage = rtrim($m[1], '/'); break 2; }
		}
	}
}
if (!$storage) $storage = dirname($root) . '/storage';

echo "=== DIAG5 " . date('Y-m-d H:i:s') . " ===\n";
echo "PHP: " . PHP_VERSION . "\n";
$gd = function_exists('gd_info') ? gd_info() : array();
echo "GD: " . (isset($gd['GD Version']) ? $gd['GD Version'] : '?') . " | WebP Support: " . var_export(isset($gd['WebP Support']) ? $gd['WebP Support'] : null, true) . "\n";
echo "imagecreatefromwebp exists: " . var_export(function_exists('imagecreatefromwebp'), true) . "\n";
echo "DIR_STORAGE guess: $storage\n\n";

$targets = array(
	'SOURCE system/library/image.php' => $root . '/system/library/image.php',
	'MOD    system/library/image.php' => $storage . '/modification/system/library/image.php',
);

foreach ($targets as $label => $f) {
	echo "---- $label ----\n";
	echo "  path: $f\n  exists: " . var_export(is_file($f), true);
	if (is_file($f)) {
		echo "  size: " . filesize($f) . "B  mtime: " . date('Y-m-d H:i:s', filemtime($f)) . "\n";
		$lines = file($f);
		echo "  total lines: " . count($lines) . "\n";
		// конструктор целиком
		$start = null;
		foreach ($lines as $i => $l) { if (preg_match('/function\s+__construct/', $l)) { $start = $i; break; } }
		if ($start !== null) {
			$end = min($start + 45, count($lines) - 1);
			echo "  -- constructor L" . ($start + 1) . "-L" . ($end + 1) . " --\n";
			for ($i = $start; $i <= $end; $i++) printf("  %4d| %s", $i + 1, rtrim($lines[$i]) . "\n");
		} else {
			echo "  (constructor not found!)\n";
		}
		// все «белые списки» расширений/типов в файле
		echo "  -- whitelist lines --\n";
		foreach ($lines as $i => $l) {
			if (stripos($l, 'in_array') !== false && (stripos($l, "'gif'") !== false || stripos($l, 'IMAGETYPE') !== false || stripos($l, 'webp') !== false)) {
				printf("  L%d: %s\n", $i + 1, trim($l));
			}
		}
	} else {
		echo "\n";
	}
	echo "\n";
}

// проблемный файл
$bad = $root . '/image/catalog/1papka/katalog/Лого-и-фирменное-написане-_1_-_1_-_1_.webp';
echo "---- BAD FILE ----\n  $bad\n";
echo "  exists: " . var_export(is_file($bad), true);
if (is_file($bad)) {
	echo "  size: " . filesize($bad) . "B\n";
	$h = fopen($bad, 'rb'); $head = fread($h, 16); fclose($h);
	echo "  first16 hex: " . bin2hex($head) . "\n";
	$magic = 'UNKNOWN/CORRUPT';
	if (substr($head, 0, 4) === 'RIFF' && substr($head, 8, 4) === 'WEBP') $magic = 'REAL WEBP';
	elseif (substr($head, 0, 8) === "\x89PNG\r\n\x1a\n") $magic = 'PNG renamed to .webp!';
	elseif (substr($head, 0, 2) === "\xFF\xD8") $magic = 'JPEG renamed to .webp!';
	echo "  magic: $magic\n";
	$gi = @getimagesize($bad);
	echo "  getimagesize: " . ($gi ? "{$gi[0]}x{$gi[1]} type={$gi[2]} mime={$gi['mime']}" : 'FAIL') . "\n";
	if (function_exists('imagecreatefromwebp')) {
		$im = @imagecreatefromwebp($bad);
		echo "  imagecreatefromwebp: " . ($im ? 'OK ' . imagesx($im) . 'x' . imagesy($im) : 'FAIL (false)') . "\n";
	}
} else {
	echo "\n";
}

// сколько ещё webp-исходников (вне кеша)
echo "\n---- webp sources under image/ (excluding cache & cachewebp) ----\n";
$n = 0;
try {
	$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/image', FilesystemIterator::SKIP_DOTS));
	foreach ($it as $file) {
		$p = str_replace('\\', '/', $file->getPathname());
		if (strpos($p, '/image/cache/') !== false || strpos($p, '/image/cachewebp/') !== false) continue;
		if (strtolower($file->getExtension()) === 'webp') {
			$n++;
			if ($n <= 30) echo "  $p [" . $file->getSize() . "B]\n";
		}
	}
} catch (Exception $e) { echo "  scan error: " . $e->getMessage() . "\n"; }
echo "  total webp sources: $n\n";
echo "=== END DIAG5 ===\n";
